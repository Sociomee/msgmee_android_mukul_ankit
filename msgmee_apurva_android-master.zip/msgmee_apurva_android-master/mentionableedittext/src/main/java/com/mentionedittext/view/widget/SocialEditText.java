package com.mentionedittext.view.widget;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.widget.EditText;

import androidx.appcompat.widget.AppCompatEditText;

import com.mentionedittext.model.MentionModel;
import com.mentionedittext.tokenization.Tokenizer;
import com.mentionedittext.view.MainView;

import java.util.ArrayList;

/**
 * @author FarshidAbz
 * @version 1.0
 * @since 9/9/2016
 */
public class SocialEditText extends androidx.appcompat.widget.AppCompatEditText implements TextWatcher {
    ArrayList<MentionModel> inputList;
    Tokenizer tokenizer;

    public int currentCursorPosition;
    private MainView mainView;
    private String currentText;

    public SocialEditText(Context context) {
        super(context);
    }

    public SocialEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SocialEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public SocialEditText(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleRes);
    }

    public void setInputList(ArrayList<MentionModel> inputList) {
        this.inputList = inputList;
    }

    public void setMainView(MainView mainView) {
        this.mainView = mainView;
    }

    public String getCurrentWord() {
        return tokenizer.getCurrentWord(getText(), currentCursorPosition);
    }

    @Override
    protected void onSelectionChanged(int selStart, int selEnd) {
        super.onSelectionChanged(selStart, selEnd);

        if (selStart == 0 || selStart != selEnd || inputList == null || inputList.size() <= 0 || mainView == null)
            return;

        if (tokenizer == null) {
            tokenizer = new Tokenizer(inputList, mainView);
        }
        currentCursorPosition = selStart;
        tokenizer.findTokens(currentText, currentCursorPosition);
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
    }

    @Override
    public void afterTextChanged(Editable editable) {
    }

    @Override
    public void onTextChanged(CharSequence text, int var2, int var3, int var4) {
        currentText = text.toString();
    }
}