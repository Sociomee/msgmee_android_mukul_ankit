package com.mentionedittext.view;

/**
 * @author FarshidAbz
 * @version 1.0
 * @since 9/9/2016
 */
public interface OnRecyclerViewClickListener {
    void onItemClickListener(String text);
}
