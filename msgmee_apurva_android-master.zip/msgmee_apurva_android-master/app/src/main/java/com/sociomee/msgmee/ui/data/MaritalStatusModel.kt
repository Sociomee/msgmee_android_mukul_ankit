package com.sociomee.msgmee.ui.data

import com.google.gson.annotations.SerializedName

data class MaritalStatusModel(
        @SerializedName("data")
    val maritalStatusData: MaritalStatusData,
        @SerializedName("error")
    val error: Boolean,
        @SerializedName("success")
    val success: Boolean
    )
{
    data class MaritalStatusData(
        @SerializedName("successResult")
        val successResult: List<MaritalStatusList>
    )
     data class MaritalStatusList(
            @SerializedName("id")
            val id: String,
            @SerializedName("name")
            val name: String,
            var isSelected:Boolean=false
        )
}