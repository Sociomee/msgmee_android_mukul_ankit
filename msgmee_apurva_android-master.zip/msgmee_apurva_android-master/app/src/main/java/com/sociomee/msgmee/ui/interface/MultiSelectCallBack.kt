package com.sociomee.msgmee.ui.`interface`

interface MultiSelectCallBack {

    fun multiSelectChange(isMultiSelectOpen : Boolean, selectCount : Int)
    fun notifyMultiSelectItemChange(isMultiSelectOpen : Boolean, selectCount : Int, selectedMessageList : ArrayList<Int>)

}