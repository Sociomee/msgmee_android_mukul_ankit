package com.sociomee.msgmee.ui.model


import com.google.gson.annotations.SerializedName

data class AddUserHobbiesModel(
        @SerializedName("data")
    val addHobbiesData: AddHobbiesData,
        @SerializedName("error")
    val error: Boolean,
        @SerializedName("success")
    val success: Boolean
) {
    data class AddHobbiesData(
        @SerializedName("successResult")
        val successResult: List<String>
    )
}