package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.global.`interface`.GlobalApiCall
import com.sociomee.msgmee.global.model.MediaUploadModel
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import okhttp3.RequestBody
import retrofit2.Response

class MediaUploadRepo {

    fun uploadMedia(body: RequestBody) : MutableLiveData<MyResponse<MediaUploadModel>> {
        val data = MutableLiveData<MyResponse<MediaUploadModel>>()
        val retrofitService = MyRetrofit.getRetrofitService(GlobalApiCall::class.java)
        val call = retrofitService.uploadMedia(body)

        call.enqueue(object: MyCallback<MediaUploadModel> {
            override fun success(response: Response<MediaUploadModel>) {
                data.postValue(MyResponse.success(response.body()))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }
        })
        return data
    }

}