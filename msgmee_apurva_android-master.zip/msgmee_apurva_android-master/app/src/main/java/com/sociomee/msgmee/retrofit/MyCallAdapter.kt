package com.sociomee.msgmee.retrofit

import android.util.Log
import com.sociomee.msgmee.MsgMee
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MyCallAdapter<T>(private val call : Call<T>) : MyCall<T> {

    override fun enqueue(callback: MyCallback<T>) {
        if(!MsgMee.isInternetAvailable) {
            callback.networkError()
            return
        }

        call.enqueue(object : Callback<T> {
            override fun onResponse(call: Call<T>, response: Response<T>) {
                try {
                    when {
                        response.code() == 200 -> {
                            callback.success(response)
                        }
                        response.code() == 403 -> {
                            Log.v("harshAPI", "${response.errorBody()!!}")
                            callback.authError()
                        }
                        else -> {
                            Log.v("harshAPI", "${response.errorBody()!!.byteString()}")
                            callback.serverError()
                        }
                    }
                } catch (e: Exception) {
                    Log.v("harshAPI", "api exception ${e.message}")
                    callback.serverError()
                }
            }

            override fun onFailure(call: Call<T>, t: Throwable) {
                Log.v("harshAPI", "api failure ${t.message}")
                callback.serverError()
            }
        })
    }

    override fun cancel() {
        call.cancel()
    }
}