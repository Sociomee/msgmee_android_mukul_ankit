package com.sociomee.msgmee.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomIconView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.model.CallHistoryData
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.TimeAgo
import java.util.*
import kotlin.collections.ArrayList

class CallInfoAdapter(val list : ArrayList<CallHistoryData>) : RecyclerView.Adapter<CallInfoAdapter.CallInfoHolder>() {

      override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = CallInfoHolder(
              LayoutInflater.from(
                      parent.context).inflate(R.layout.call_info_child, parent, false)
      )

    override fun getItemCount() = list.size

    override fun onBindViewHolder(holder: CallInfoHolder, position: Int) {
        val model = list[position]

        holder.txt_call_status.text = model.callText
        holder.txt_call_time.text = TimeAgo.getTimeAgo(model.startTime)
        holder.txt_call_duration.visibility = if(model.callState != "missed") {
            holder.txt_call_duration.text = if(model.callDuration > 0) {
                val seconds = model.callDuration % 60
                val minutes = model.callDuration / 60
                val stringTime = String.format(Locale.ENGLISH, "%02d:%02d", minutes, seconds)
                stringTime
            } else {
                "00:00"
            }
            View.VISIBLE
        } else {
            View.GONE
        }


        when(model.callType) {
            Constants.CallType.MISSED_VIDEO -> {
                Glide.with(holder.itemView.context).load(R.drawable.ic_call_missed_video).into(holder.img_call_status)
            }
            Constants.CallType.MISSED_AUDIO -> {
                Glide.with(holder.itemView.context).load(R.drawable.ic_call_missed_audio).into(holder.img_call_status)
            }
            Constants.CallType.OUTGOING_VIDEO -> {
                Glide.with(holder.itemView.context).load(R.drawable.ic_call_outgoing_video).into(holder.img_call_status)
            }
            Constants.CallType.OUTGOING_AUDIO -> {
                Glide.with(holder.itemView.context).load(R.drawable.ic_call_outgoing_audio).into(holder.img_call_status)
            }
            Constants.CallType.INCOMING_VIDEO -> {
                Glide.with(holder.itemView.context).load(R.drawable.ic_call_incoming_video).into(holder.img_call_status)
            }
            Constants.CallType.INCOMING_AUDIO -> {
                Glide.with(holder.itemView.context).load(R.drawable.ic_call_incoming_audio).into(holder.img_call_status)
            }
        }
    }

    class CallInfoHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val img_call_status = itemView.findViewById<CustomIconView>(R.id.img_call_status)
        val txt_call_status = itemView.findViewById<CustomTextView>(R.id.txt_outgoing_call_status)
        val txt_call_time = itemView.findViewById<CustomTextView>(R.id.txt_call_time)
        val txt_call_duration = itemView.findViewById<CustomTextView>(R.id.txt_call_duration)
    }
}