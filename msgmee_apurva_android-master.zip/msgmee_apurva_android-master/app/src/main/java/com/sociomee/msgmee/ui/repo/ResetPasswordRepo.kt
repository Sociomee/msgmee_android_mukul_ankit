package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.LoginApiCall
import com.sociomee.msgmee.ui.model.MessageResponse
import retrofit2.Response

class ResetPasswordRepo {

    fun resetPassword(body: HashMap<String, Any>): MutableLiveData<MyResponse<MessageResponse>> {
        val data = MutableLiveData<MyResponse<MessageResponse>>()
        val retrofitService = MyRetrofit.getRetrofitService(LoginApiCall::class.java)
        val call = retrofitService.resetPassword(body)

        call.enqueue(object: MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                data.postValue(MyResponse.success(response.body()))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError("success"))
            }

        })
        return data
    }

}