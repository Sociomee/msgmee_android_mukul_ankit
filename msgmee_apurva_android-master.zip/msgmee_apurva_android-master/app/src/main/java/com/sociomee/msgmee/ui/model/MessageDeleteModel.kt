package com.sociomee.msgmee.ui.model

data class MessageDeleteModel(
    val isSuccess: Boolean,
    val messageIndexList: ArrayList<Int>?,
    val messageIdsList: ArrayList<String>? = null,
    val chatHeadId: String = ""
)