package com.sociomee.msgmee.utils

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.provider.ContactsContract
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.google.gson.Gson
import com.sociomee.msgmee.R
import com.sociomee.msgmee.global.model.SavedLocationModel
import com.sociomee.msgmee.ui.activity.CallActivity
import com.sociomee.msgmee.ui.model.StartCallModel
import com.sociomee.msgmee.ui.model.UserInfoModel
import java.io.File
import java.io.IOException
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random


class Constants {

    enum class LastMessageType {
        MESSAGE,
        GROUP_MESSAGE,
        TYPING,
        GROUP_TYPING,
        MISSED_AUDIO_CALL,
        MISSED_VIDEO_CALL,
        IMAGE,
        VIDEO,
        AUDIO,
        CONTACT,
        LEFT_GROUP,
        BROADCAST
    }

    enum class ChatFetchType {
        NEW_MESSAGE,
        OLD_MESSAGE,
        SEARCH_MESSAGE,
        REPLY_MESSAGE_CLICK
    }

    enum class FolderType {
        IMAGE_FOLDER,
        VIDEO_FOLDER,
        AUDIO_FOLDER,
        DOCUMENT_FOLDER,
        RECORD_AUDIO
    }

    enum class MessageProgressChange {
        HIDE_BOTH,
        HIDE_OLD,
        HIDE_NEW,
        SHOW_OLD,
        SHOW_NEW
    }

    enum class CallType {
        MISSED_VIDEO,
        MISSED_AUDIO,
        OUTGOING_VIDEO,
        OUTGOING_AUDIO,
        INCOMING_VIDEO,
        INCOMING_AUDIO
    }

    enum class PeopleSelectType {
        SINGLE,
        GROUP,
        GROUP_ADD_PEOPLE,
        BROADCAST,
        CALL
    }

    enum class SelectedMediaType(type: String) {
        IMAGE("image"),
        VIDEO("video"),
        AUDIO("audio"),
        CONTACT("contact"),
        DOC("document")
    }

    enum class MessageType {
        MY_MESSAGE,
        OTHER_MESSAGE,
        MY_MESSAGE_REPLY,
        OTHER_MESSAGE_REPLY,
        MY_IMAGE,
        OTHER_IMAGE,
        MY_IMAGE_REPLY,
        OTHER_IMAGE_REPLY,
        MY_IMAGE_MESSAGE,
        OTHER_IMAGE_MESSAGE,
        MY_CONTACT,
        OTHER_CONTACT,
        MY_CONTACT_REPLY,
        OTHER_CONTACT_REPLY,
        MY_AUDIO,
        OTHER_AUDIO,
        MY_AUDIO_REPLY,
        OTHER_AUDIO_REPLY,
        MY_DOC,
        OTHER_DOC,
        MY_DOC_REPLY,
        OTHER_DOC_REPLY,
        MY_VIDEO,
        OTHER_VIDEO,
        MY_VIDEO_REPLY,
        OTHER_VIDEO_REPLY,
        MY_VIDEO_MESSAGE,
        OTHER_VIDEO_MESSAGE,
        MY_GIF,
        OTHER_GIF,
        MY_GIF_REPLY,
        OTHER_GIF_REPLY,
        CHAT_BUBBLE,
        UNREAD_BUBBLE,
        MESSAGE_TYPE_ERROR
    }

    companion object {
        const val INTENT_USER_ID = "INTENT_USER_ID"
        const val INTENT_STORY_ID = "INTENT_STORY_ID"
        const val INTENT_IMAGE_PATH = "INTENT_IMAGE_PATH"
        const val INTENT_SCREEN_HEADER = "INTENT_SCREEN_HEADER"
        const val INTENT_SIGNED_IMAGE_PATH = "INTENT_SIGNED_IMAGE_PATH"
        fun getCurrencySign(context: Context): String {
            return context.getString(R.string.currency_logo)
        }

        fun getVM(parent: ViewGroup, layout: Int): View {
            return LayoutInflater.from(parent.context).inflate(layout, parent, false)
        }

        // shared preferences keys
        const val userDataKey = "currentUserData"
        private const val locationDataKey = "locationData"
        const val appleLoginCallbackUrl = "https://sociomee-social.firebaseapp.com/__/auth/handler"

        // user data
        var userInfo: UserInfoModel? = null
        const val languageId = "languageId"

        // boolean for hiding second phase design
        var hideSecondPhase = true

        // global search delay
        const val searchDelay: Long = 600 // 600 ms

        const val globalPageSize = 10
        var radius: Long = 15000
        var LATITUDE = ""
        var LONGITUDE = ""




        // user data


        // boolean for hiding second phase design


        // upload type of media
        const val messageMediaUploadKey = "messageAttachment"

        val myGson = Gson()

        fun saveLocation(context: Context, savedLocationModel: SavedLocationModel) {
            MyPreferences.saveStringInPreference(
                context, locationDataKey, Gson().toJson(
                    savedLocationModel
                )
            )
        }

        fun getSavedLocation(context: Context): SavedLocationModel {
            val locData = MyPreferences.getFromPreferences(context, locationDataKey)

            if (locData == null || locData.isEmpty()) {
                return SavedLocationModel(0.0, 0.0, "India", "India", "India")
            }
            return Gson().fromJson(locData, SavedLocationModel::class.java)
        }

        fun getBitmapFromUrl(url: String): Bitmap? {
            return try {
                BitmapFactory.decodeStream(URL(url).openConnection().getInputStream())
            } catch (e: IOException) {
                null
            }
        }

        fun getRandomString(context: Context): String {
            return when (Random.nextInt(0, 4)) {
                0 -> {
                    context.getString(R.string.foobar)
                }
                1 -> {
                    context.getString(R.string.long_foobar)
                }
                2 -> {
                    context.getString(R.string.longest_foobar)
                }
                3 -> {
                    "https://www.youtube.com/"
                }
                else -> {
                    context.getString(R.string.foobar)
                }
            }
        }

        fun isPermissionGranted(context: Context, permissions: Array<String>): Boolean {
            for (permission in permissions) {
                if (ContextCompat.checkSelfPermission(
                        context,
                        permission
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    return false
                }
            }
            return true
        }

        fun createNewFilePath(context: Context, extension: String): String {
            val timeStamp: String =
                SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())

            return context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!.path + "/MessageMEE_${timeStamp}_.${extension}"
        }

        fun isCurrentUser(userId: String) = userInfo!!.id == userId

        fun getUsername(context: Context, username: String) =
            if (userInfo!!.username == username) context.getString(R.string.you) else username

        fun saveContact(
            context: Context,
            contactName: String,
            contactNumber: String,
            imageBitmap: Bitmap?
        ) {
            val contactSave = Intent(Intent.ACTION_INSERT_OR_EDIT).apply {
                type = ContactsContract.Contacts.CONTENT_ITEM_TYPE
                putExtra(
                    ContactsContract.Intents.Insert.NAME,
                    contactName
                )
                putExtra(
                    ContactsContract.Intents.Insert.PHONE,
                    contactNumber
                )
                if (imageBitmap != null) {
                    val row = ContentValues().apply {
                        put(
                            ContactsContract.CommonDataKinds.Photo.PHOTO,
                            imageBitmap.toByteArray()
                        )
                        put(
                            ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE
                        )
                    }
                    val data = arrayListOf(row)
                    putParcelableArrayListExtra(
                        ContactsContract.Intents.Insert.DATA, data
                    )
                }
            }
            context.startActivity(contactSave)
        }

        fun getAudioDuration(context: Context, mediaUri: Uri): Int {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, mediaUri)
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            return duration!!.toInt()
        }

        fun createFile(context: Context): File? {
            return try {
                val timeStamp: String =
                    SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val storageDir: File? = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                File.createTempFile(
                    "JPEG_${timeStamp}_",
                    ".jpg",
                    storageDir
                )
            } catch (e: Exception) {
                null
            }
        }

        fun getFolderPath(context: Context, folderType: FolderType): String {
            val rootDir: File? = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
            if (rootDir == null || !rootDir.exists()) {
                rootDir!!.mkdir()
            }

            val endPath = when (folderType) {
                FolderType.IMAGE_FOLDER -> {
                    "/Images/"
                }
                FolderType.VIDEO_FOLDER -> {
                    "/Videos/"
                }
                FolderType.AUDIO_FOLDER -> {
                    "/Audios/"
                }
                FolderType.DOCUMENT_FOLDER -> {
                    "/Documents/"
                }
                FolderType.RECORD_AUDIO -> {
                    "/AudioRecordings/"
                }
            }
            val folderPath = rootDir.path.plus(endPath)
            val folder = File(folderPath)
            if (!folder.exists()) {
                folder.mkdir()
            }
            return folderPath
        }

        fun startCall(context: Context, isVideoCall: Boolean, startCallModel: StartCallModel) {
            val intent = Intent(context, CallActivity::class.java)
            intent.putExtra("isVideoCall", isVideoCall)
            intent.putExtra("isOwner", true)
            intent.putExtra(
                "callToData", Constants.myGson.toJson(
                    startCallModel
                )
            )
            context.startActivity(intent)
        }
    }

}