package com.sociomee.msgmee.ui.fragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.sociomee.msgmee.ui.data.InterestModel
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.`interface`.AddItemCallback
import com.sociomee.msgmee.ui.activity.MessengerActivity
import com.sociomee.msgmee.ui.activity.SignUpActivity
import com.sociomee.msgmee.ui.activity.WelcomeActivity
import com.sociomee.msgmee.ui.adapter.InterestAdapter
import com.sociomee.msgmee.ui.viewmodel.InterestViewModel
import com.sociomee.msgmee.ui.viewmodel.UserInterestViewModel
import com.xiaofeng.flowlayoutmanager.Alignment
import com.xiaofeng.flowlayoutmanager.FlowLayoutManager
import kotlinx.android.synthetic.main.choose_intrest_fragment.*
import kotlinx.android.synthetic.main.choose_intrest_fragment.img_toolbar_back


class ChooseInterestFragment : Fragment(R.layout.choose_intrest_fragment), AddItemCallback {

    lateinit var interestViewModel: InterestViewModel
    var interestList = ArrayList<InterestModel.InterestList>()
    lateinit var interestAdaptor: InterestAdapter
    lateinit var userInterestViewModel: UserInterestViewModel

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        img_toolbar_back.setOnClickListener {
            (activity as SignUpActivity).onBackPress()
        }

        initData()
        observeData()
        setViewsClick()
    }

    private fun setViewsClick() {
        btn_continue.setOnClickListener {
            val selectedInterestList = ArrayList<String>()
            interestList.forEach {
                if(it.isSelected) {
                    selectedInterestList.add(it.id)
                }
            }
            if(selectedInterestList.size < 3) {
                (activity as CustomAppCompatActivity).showToast("Select at least 3 interest to continue")
            } else {
               // interestViewModel.addInterestToUser(hashMapOf("interestIds" to selectedInterestList))
                userInterestViewModel.userAddInterest(hashMapOf("interestIds" to selectedInterestList))
            }
        }
    }

    private fun observeData() {
        interestViewModel.observeLoading().observe(this, Observer {
            (activity as CustomAppCompatActivity).changeLoadingStatus(it)
        })
        interestViewModel.observeInterestList().observe(this, Observer {
            interestList.addAll(it)
            interestAdaptor.notifyDataSetChanged()
        })
        userInterestViewModel.observeUserAddInterests().observe(this, Observer {
            if(it.success) {
                val intent = Intent(context, MessengerActivity::class.java)
                intent.putExtra("type", "profileOwn")
                activity!!.startActivity(intent)
                activity!!.finish()



            } else {
                (activity as CustomAppCompatActivity).showToast(getString(R.string.something_went_wrong_))
            }
        })

        // observing errors
        observeError()
    }

    private fun observeError() {
        interestViewModel.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    Toast.makeText(context, "Internet not available", Toast.LENGTH_LONG).show()
                }
                ResponseStatus.AUTH_ERROR -> {
                    Toast.makeText(context, "Auth Error", Toast.LENGTH_LONG).show()
                }
                ResponseStatus.SERVER_ERROR -> {
                    Toast.makeText(context, "ggghghgh", Toast.LENGTH_LONG).show()
                }
                else -> {
                }
            }
        })
    }

    private fun initData() {
        interestViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
                InterestViewModel::class.java)

        interestViewModel.getInterestList()
        interestList = ArrayList()

        val flowLayoutManager = FlowLayoutManager()
        flowLayoutManager.isAutoMeasureEnabled = true
        flowLayoutManager.setAlignment(Alignment.LEFT)
        flowLayoutManager.maxItemsPerLine(3)
        interestAdaptor = InterestAdapter(interestList, this)
        rv_intrest.layoutManager = flowLayoutManager
        rv_intrest.adapter = interestAdaptor

        // for user selected interest
        userInterestViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
                UserInterestViewModel::class.java
        )
    }

    override fun itemChanged(position: Int, isChecked: Boolean) {
        interestList[position].isSelected = isChecked
    }

    override fun itemRemoved(position: Int) {
        TODO("Not yet implemented")
    }
}