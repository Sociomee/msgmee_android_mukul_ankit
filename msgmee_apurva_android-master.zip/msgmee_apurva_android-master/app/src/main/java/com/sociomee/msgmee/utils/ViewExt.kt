package  com.sociomee.msgmee.utils

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Resources
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.Icon
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.text.SpannableString
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.util.Log
import android.util.Patterns
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.SimpleExoPlayer
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomImageView
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.activity.ChatActivity
import com.sociomee.msgmee.ui.model.*
import okhttp3.internal.toLongOrDefault
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.URL
import java.text.DecimalFormat
import kotlin.math.absoluteValue
import kotlin.math.log10
import kotlin.math.pow

fun View.hide() {
    visibility = View.GONE
}

fun View.show() {
    visibility = View.VISIBLE
}

fun Context.pxToDp(px: Int): Int {
    return (px / Resources.getSystem().displayMetrics.density).toInt()
}

fun String.isValidEmail() = !isNullOrEmpty() && Patterns.EMAIL_ADDRESS.matcher(this).matches()
fun String.isValidMobile() = !isNullOrEmpty() && Patterns.PHONE.matcher(this).matches()

fun String.isValidPassword() = this.length > 5

fun View.closeKeyboard() {
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.hideSoftInputFromWindow(windowToken, 0)
}

fun View.showKeyboard() {
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
}

fun ArrayList<ChatModel>.defineMessageEnum(chatType: String) {
    this.forEach {
        it.isOneToOne = chatType == "user"
        it.isMyMessage = Constants.isCurrentUser(it.senderUserId)
        it.messageEnumType = if (it.isDeletedForAll == 1) {
            if (it.isMyMessage) {
                Constants.MessageType.MY_MESSAGE
            } else {
                Constants.MessageType.OTHER_MESSAGE
            }
        } else {
            when (it.messageType) {
                "text" -> {
                    if (it.messageJson?.type != null) {
                        when (it.messageJson.type) {
                            "replyText" -> {
                                if (it.isMyMessage) {
                                    Constants.MessageType.MY_MESSAGE_REPLY
                                } else {
                                    Constants.MessageType.OTHER_MESSAGE_REPLY
                                }
                            }
                            "replyImage" -> {
                                if (it.isMyMessage) {
                                    Constants.MessageType.MY_IMAGE_REPLY
                                } else {
                                    Constants.MessageType.OTHER_IMAGE_REPLY
                                }
                            }
                            "replyVideo" -> {
                                if (it.isMyMessage) {
                                    Constants.MessageType.MY_VIDEO_REPLY
                                } else {
                                    Constants.MessageType.OTHER_VIDEO_REPLY
                                }
                            }
                            "replyContact" -> {
                                if (it.isMyMessage) {
                                    Constants.MessageType.MY_CONTACT_REPLY
                                } else {
                                    Constants.MessageType.OTHER_CONTACT_REPLY
                                }
                            }
                            "replyAudio" -> {
                                if (it.isMyMessage) {
                                    Constants.MessageType.MY_AUDIO_REPLY
                                } else {
                                    Constants.MessageType.OTHER_AUDIO_REPLY
                                }
                            }
                            "replyDocument" -> {
                                if (it.isMyMessage) {
                                    Constants.MessageType.MY_DOC_REPLY
                                } else {
                                    Constants.MessageType.OTHER_DOC_REPLY
                                }
                            }
                            else -> {
                                if (it.isMyMessage) {
                                    Constants.MessageType.MY_MESSAGE
                                } else {
                                    Constants.MessageType.OTHER_MESSAGE
                                }
                            }
                        }
                    } else {
                        if (it.isMyMessage) {
                            Constants.MessageType.MY_MESSAGE
                        } else {
                            Constants.MessageType.OTHER_MESSAGE
                        }
                    }
                }
                "image" -> {
                    if (it.isMyMessage) {
                        if (it.messageText.isEmpty()) Constants.MessageType.MY_IMAGE else Constants.MessageType.MY_IMAGE_MESSAGE
                    } else {
                        if (it.messageText.isEmpty()) Constants.MessageType.OTHER_IMAGE else Constants.MessageType.OTHER_IMAGE_MESSAGE
                    }
                }
                "video" -> {
                    if (it.isMyMessage) {
                        if (it.messageText.isEmpty()) Constants.MessageType.MY_VIDEO else Constants.MessageType.MY_VIDEO_MESSAGE
                    } else {
                        if (it.messageText.isEmpty()) Constants.MessageType.OTHER_VIDEO else Constants.MessageType.OTHER_VIDEO_MESSAGE
                    }
                }
                "contact" -> {
                    if (it.isMyMessage) {
                        Constants.MessageType.MY_CONTACT
                    } else {
                        Constants.MessageType.OTHER_CONTACT
                    }
                }
                "audio" -> {
                    if (it.isMyMessage) {
                        Constants.MessageType.MY_AUDIO
                    } else {
                        Constants.MessageType.OTHER_AUDIO
                    }
                }
                "document" -> {
                    if (it.isMyMessage) {
                        Constants.MessageType.MY_DOC
                    } else {
                        Constants.MessageType.OTHER_DOC
                    }
                }
                "bubble" -> {
                    Constants.MessageType.CHAT_BUBBLE
                }
                else -> Constants.MessageType.MESSAGE_TYPE_ERROR
            }
        }
    }
}

fun ChatModel.getReplyType() = when (this.messageType) {
    "text" -> {
        "replyText"
    }
    "image" -> {
        "replyImage"
    }
    "video" -> {
        "replyVideo"
    }
    "contact" -> {
        "replyContact"
    }
    "audio" -> {
        "replyAudio"
    }
    "document" -> {
        "replyDocument"
    }
    else -> "replyText"
}


fun String?.mediaFullUrl() = if (this == null) null else MyRetrofit.mediaBaseUrl.plus(this)

fun ChatHeadInfoModel?.onlineText(context: Context) =
    if (this == null) context.getString(R.string.not_active) else when (this.chatHeadType) {
        "user" -> if (this.isOnline == 1) context.getString(R.string.active_now) else TimeAgo.getTimeAgo(
            this.userLastActivity
        ) ?: context.getString(R.string.not_active)
        "group" -> this.groupMembersCount.toString() + " " + context.getString(R.string.members)
        "broadcast" -> this.broadcastMembersCount.toString() + " " + context.getString(R.string.members)
        else -> ""
    }

fun ChatHeadInfoModel.chatTypeId() = when (this.chatHeadType) {
    "user" -> otherUserId
    "group" -> groupId
    "broadcast" -> broadcastId
    else -> ""
}

fun ChatHeadInfoModel.chatName() = when (this.chatHeadType) {
    "user" -> fullName
    "group" -> groupName
    "broadcast" -> broadcastListName
    else -> ""
}

fun ChatHeadInfoModel.chatProfile() = when (this.chatHeadType) {
    "user" -> profileImageThumb
    "group" -> groupImageThumb
    else -> ""
}

fun View.toBitmap(): Bitmap {
    val specSize = View.MeasureSpec.makeMeasureSpec(
        0 /* any */, View.MeasureSpec.UNSPECIFIED
    )
    this.measure(specSize, specSize)
    val bitmap = Bitmap.createBitmap(
        this.measuredWidth,
        this.measuredHeight, Bitmap.Config.ARGB_8888
    )
    val canvas = Canvas(bitmap)
    this.layout(this.left, this.top, this.right, this.bottom)
    this.draw(canvas)
    return bitmap
}

fun Bitmap.toByteArray(): ByteArray {
    val stream = ByteArrayOutputStream()
    this.compress(Bitmap.CompressFormat.JPEG, 80, stream)
    return stream.toByteArray()
}

fun Uri?.getDuration(context: Context): String? {
    if (this == null) return null
    val stringBuilder: StringBuilder = java.lang.StringBuilder()
    try {
        val mmr = MediaMetadataRetriever()
        mmr.setDataSource(context, this)
        val duration: String =
            mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION) ?: return null
        val millSecond = duration.toInt()
        if (millSecond < 0) return 0.toString() // if some error then we say duration is zero
        val hours: Int
        val minutes: Int
        var seconds = millSecond / 1000
        hours = seconds / 3600
        minutes = seconds / 60 % 60
        seconds %= 60
        if (hours in 1..9) stringBuilder.append("0").append(hours)
            .append(":") else if (hours > 0) stringBuilder.append(hours).append(":")
        if (minutes < 10) stringBuilder.append("0").append(minutes)
            .append(":") else stringBuilder.append(minutes).append(":")
        if (seconds < 10) stringBuilder.append("0").append(seconds) else stringBuilder.append(
            seconds
        )
    } catch (e: Exception) {
        e.printStackTrace()
        return null
    }
    return stringBuilder.toString()
}

@SuppressLint("Recycle")
fun Uri?.getSize(context: Context): String? {
    if (this == null) return null
    var cursor: Cursor? = null
    return try {
        val proj = arrayOf(MediaStore.Audio.Media.SIZE)
        cursor = context.contentResolver.query(this, proj, null, null, null) ?: return null
        val column_index: Int = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
        cursor.moveToFirst()
        cursor.getString(column_index).toLongOrDefault(0).getReadableFileSize()
    } catch (e: java.lang.Exception) {
        cursor?.close()
        null
    }
}

fun Long.getReadableFileSize(): String {
    if (this <= 0) return "0 B"

    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (log10(this.toDouble()) / log10(1024.0)).toInt()

    return DecimalFormat("#,##0.#").format(this / 1024.0.pow(digitGroups.toDouble()))
        .toString() + " " + units[digitGroups]
}

@SuppressLint("Recycle")
fun Uri?.getName(context: Context): String? {
    if (this == null) return null
    var cursor: Cursor? = null
    return try {
        val proj = arrayOf(MediaStore.Audio.Media.DISPLAY_NAME)
        cursor = context.contentResolver.query(this, proj, null, null, null) ?: return null
        val column_index: Int = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
        cursor.moveToFirst()
        cursor.getString(column_index)
    } catch (e: java.lang.Exception) {
        cursor?.close()
        null
    }
}

fun SimpleExoPlayer.getMilliSecFromPercentage(playPercentage: Int): Long {
    val totalDuration = this.duration.absoluteValue
    val secSeek = ((playPercentage) * (totalDuration / 100))
    Log.v("harshAudio", "seek sec == $secSeek")
    return secSeek
}

fun SimpleExoPlayer.getPlayPercentage(): Long {
    val totalDuration = this.duration.absoluteValue
    val currentPosition = this.currentPosition
    return ((100 * currentPosition) / totalDuration)
}

fun CustomImageView.setMediaImage(context: Context, playMedia: Boolean) {
    this.setImageDrawable(
        ContextCompat.getDrawable(
            context,
            if (playMedia) R.drawable.ic_pause else R.drawable.ic_play
        )
    )
}

fun ExoPlayer.isPlaying() =
    playbackState == Player.STATE_READY && playWhenReady

fun String.withBackgroundSpan(context: Context): SpannableString {
    val spanString = SpannableString(this)
    var searchText = ""
    if (context is ChatActivity) {
        searchText = context.searchText
    }
    if (searchText.isEmpty() || !this.contains(searchText)) {
        return spanString
    }
    var iteratedIndex = 0
    val textList = this.split(searchText, ignoreCase = true).toMutableList().apply {
        removeLast()
    }
    for (text in textList) {
        val startIndex = text.length + iteratedIndex
        iteratedIndex = startIndex + searchText.length
        this.substring(startIndex, iteratedIndex)
        val span = BackgroundColorSpan(ContextCompat.getColor(context, R.color.yellow_color))
        spanString.setSpan(span, startIndex, iteratedIndex, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }
    return spanString
}

fun String.imageUrlToIcon(): Icon? {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        return try {
            val url =
                URL(this)
            val profile = BitmapFactory.decodeStream(
                url.openConnection().getInputStream()
            )
            Icon.createWithBitmap(profile)
        } catch (e: IOException) {
            println(e)
            null
        }
    }
    return null
}

fun MessageNotificationData.getMessageText(context: Context): String {
    return if (this.isDeletedForAll == 1) {
        context.getString(R.string.this_messages_was_)
    } else {
        when (this.messageType) {
            "text" -> {
                this.messageText
            }
            "image" -> {
                context.getString(R.string.image)
            }
            "video" -> {
                context.getString(R.string.video)
            }
            "contact" -> {
                context.getString(R.string.contact)
            }
            "audio" -> {
                context.getString(R.string.audio)
            }
            "document" -> {
                context.getString(R.string.document)
            }
            else -> {
                this.messageText
            }
        }
    }
}

fun String.callStatus(): String {
    return when(this) {
        "ringing" -> "Ringing"
        "calling" -> "Calling"
        "reconnecting" -> "Reconnecting"
        else -> ""
    }
}

fun ArrayList<CallHistoryData>.processCallMessage(context: Context) {
    this.forEach {
        if(it.isOwner == 1) {
            if(it.isVideo == 1) {
                it.callType = Constants.CallType.OUTGOING_VIDEO
                it.callText = context.getString(R.string.outgoing_video_)
            } else {
                it.callType = Constants.CallType.OUTGOING_AUDIO
                it.callText = context.getString(R.string.outgoing_audio_)
            }
        } else {
            if(it.callState == "missed") {
                if(it.isVideo == 1) {
                    it.callType = Constants.CallType.MISSED_VIDEO
                    it.callText = context.getString(R.string.missed_video_)
                } else {
                    it.callType = Constants.CallType.MISSED_AUDIO
                    it.callText = context.getString(R.string.missed_audio_)
                }
            } else {
                if(it.isVideo == 1) {
                    it.callType = Constants.CallType.INCOMING_VIDEO
                    it.callText = context.getString(R.string.incoming_video_)
                } else {
                    it.callType = Constants.CallType.INCOMING_AUDIO
                    it.callText = context.getString(R.string.incoming_audio_)
                }
            }
        }
    }
}