package com.sociomee.msgmee.ui.model

import com.google.gson.annotations.SerializedName

data class UserInterestModel(
        @SerializedName("data")
    val userInterestData: UserInterestData,
        @SerializedName("error")
    val error: Boolean,
        @SerializedName("success")
    val success: Boolean
) {
    data class UserInterestData(
        @SerializedName("successResult")
        val successResult: SuccessResult
    ) {
        data class SuccessResult(
            @SerializedName("count")
            val count: Int,
            @SerializedName("rows")
            val userInterestLists: List<UserInterestList>
        )
            data class UserInterestList(
                @SerializedName("id")
                val id: String?=null,
                @SerializedName("interestId")
                val interestId: String?=null,
                @SerializedName("name")
                val name: String?=null,
                @SerializedName("userId")
                val userId: String?=null,
                var isSelected:Boolean
            )
        }

}