package com.sociomee.msgmee.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.`interface`.SingleItemCallback
import com.sociomee.msgmee.ui.model.ReportList

class ReportAdapter(
    private val reportList: ArrayList<ReportList>,
    private val singleItemCallback: SingleItemCallback
) : RecyclerView.Adapter<ReportAdapter.ReportHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ReportHolder(
        LayoutInflater.from(parent.context).inflate(
            R.layout.report_child,
            parent, false
        )
    )

    override fun onBindViewHolder(holder: ReportHolder, position: Int) {
        holder.report_option.text = reportList[position].reportText
        holder.itemView.setOnClickListener {
            singleItemCallback.itemInteracted(position)
        }
    }

    override fun getItemCount() = reportList.size

    class ReportHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val report_option = itemView.findViewById<CustomTextView>(R.id.report_option)
    }
}