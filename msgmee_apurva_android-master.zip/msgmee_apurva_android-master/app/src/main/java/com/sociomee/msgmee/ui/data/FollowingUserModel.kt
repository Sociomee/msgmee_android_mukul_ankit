package com.sociomee.msgmee.ui.data


import com.google.gson.annotations.SerializedName

data class FollowingUserModel(
        @SerializedName("data")
        val followingUserData: FollowingUserData,
        @SerializedName("error")
        val error: Boolean,
        @SerializedName("success")
        val success: Boolean
) {
    data class FollowingUserData(
            @SerializedName("successResult")
            val successResult: SuccessResult) {
        data class SuccessResult(
                @SerializedName("rows")
                val followingUserList: List<FollowingUserList>
        ) {
            data class FollowingUserList(
                    @SerializedName("addressBy")
                    val addressBy: Any,
                    @SerializedName("bio")
                    val bio: String,
                    @SerializedName("coverImage")
                    val coverImage: String,
                    @SerializedName("dob")
                    val dob: String,
                    @SerializedName("followingDate")
                    val followingDate: String,
                    @SerializedName("fullName")
                    val fullName: String,
                    @SerializedName("gender")
                    val gender: String,
                    @SerializedName("id")
                    val id: String,
                    @SerializedName("professionId")
                    val professionId: String,
                    @SerializedName("profileImage")
                    val profileImage: String,
                    @SerializedName("profileImageThumb")
                    val profileImageThumb: String,
                    @SerializedName("status")
                    val status: String,
                    @SerializedName("userName")
                    val userName: String,
                    var isSelected: Boolean = false
            )
        }
    }
}
