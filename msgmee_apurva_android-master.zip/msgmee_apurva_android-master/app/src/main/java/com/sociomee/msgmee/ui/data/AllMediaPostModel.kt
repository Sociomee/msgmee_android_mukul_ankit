package com.sociomee.msgmee.ui.data


import com.google.gson.annotations.SerializedName

data class AllMediaPostModel(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("successResult")
        val successResult: SuccessResult
    ) {
        data class SuccessResult(
            @SerializedName("count")
            val count: Int,
            @SerializedName("rows")
            val rows: List<Row>
        ) {
            data class Row(
                @SerializedName("alertLevel")
                val alertLevel: Any,
                @SerializedName("alertRangeMeter")
                val alertRangeMeter: Int,
                @SerializedName("allowComments")
                val allowComments: Int,
                @SerializedName("articleCategory")
                val articleCategory: Any,
                @SerializedName("articleCoverImageURL")
                val articleCoverImageURL: Any,
                @SerializedName("articleItems")
                val articleItems: Any,
                @SerializedName("articleTags")
                val articleTags: Any,
                @SerializedName("caption")
                val caption: String,
                @SerializedName("commentsCount")
                val commentsCount: Int,
                @SerializedName("createdAt")
                val createdAt: String,
                @SerializedName("displayLocation")
                val displayLocation: Any,
                @SerializedName("eventAddress")
                val eventAddress: Any,
                @SerializedName("eventCategoryId")
                val eventCategoryId: Any,
                @SerializedName("eventCoverImageURL")
                val eventCoverImageURL: Any,
                @SerializedName("eventDescription")
                val eventDescription: Any,
                @SerializedName("eventEndTime")
                val eventEndTime: Any,
                @SerializedName("eventStartTime")
                val eventStartTime: Any,
                @SerializedName("feelingCategoryIconURL")
                val feelingCategoryIconURL: Any,
                @SerializedName("feelingCategoryName")
                val feelingCategoryName: Any,
                @SerializedName("feelingIconURL")
                val feelingIconURL: Any,
                @SerializedName("feelingName")
                val feelingName: Any,
                @SerializedName("followingStatus")
                val followingStatus: String,
                @SerializedName("hidden")
                val hidden: Int,
                @SerializedName("isPrivate")
                val isPrivate: Int,
                @SerializedName("likeReactionId")
                val likeReactionId: Any,
                @SerializedName("liked")
                val liked: Int,
                @SerializedName("likesCount")
                val likesCount: Int,
                @SerializedName("mediaList")
                val mediaList: List<Media>,
                @SerializedName("notificationOff")
                val notificationOff: Int,
                @SerializedName("pollEndTime")
                val pollEndTime: Any,
                @SerializedName("pollStartTime")
                val pollStartTime: Any,
                @SerializedName("postId")
                val postId: String,
                @SerializedName("postType")
                val postType: String,
                @SerializedName("profileImageThumb")
                val profileImageThumb: String,
                @SerializedName("recommendationCoverImageURL")
                val recommendationCoverImageURL: Any,
                @SerializedName("saved")
                val saved: Int,
                @SerializedName("sharesCount")
                val sharesCount: Int,
                @SerializedName("shotzAllowDuo")
                val shotzAllowDuo: Int,
                @SerializedName("shotzAllowTrio")
                val shotzAllowTrio: Int,
                @SerializedName("shotzAudioId")
                val shotzAudioId: Any,
                @SerializedName("shotzDuoId")
                val shotzDuoId: Any,
                @SerializedName("shotzLength")
                val shotzLength: Int,
                @SerializedName("shotzMediaURL")
                val shotzMediaURL: Any,
                @SerializedName("shotzSpeed")
                val shotzSpeed: String,
                @SerializedName("shotzTrioId")
                val shotzTrioId: Any,
                @SerializedName("taggedPeoples")
                val taggedPeoples: Any,
                @SerializedName("taggedPeoplesCount")
                val taggedPeoplesCount: Int,
                @SerializedName("thoughtBackColor")
                val thoughtBackColor: Any,
                @SerializedName("thoughtForeColor")
                val thoughtForeColor: Any,
                @SerializedName("topLikes")
                val topLikes: Any,
                @SerializedName("userBlocked")
                val userBlocked: Int,
                @SerializedName("userId")
                val userId: String,
                @SerializedName("userName")
                val userName: String,
                @SerializedName("viewsCount")
                val viewsCount: Int
            ) {
                data class Media(
                    @SerializedName("caption")
                    val caption: String,
                    @SerializedName("fileType")
                    val fileType: String,
                    @SerializedName("fileURL")
                    val fileURL: String,
                    @SerializedName("mediaId")
                    val mediaId: String,
                    @SerializedName("sequence")
                    val sequence: Int
                )
            }
        }
    }
}