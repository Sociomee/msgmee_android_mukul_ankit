package com.sociomee.msgmee.global.model

data class SavedLocationModel(
        val lat: Double,
        val lng: Double,
        val location1: String,
        val location2: String,
        val location3: String
)