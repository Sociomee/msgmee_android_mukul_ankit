package com.sociomee.msgmee.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomImageView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.model.ContactModel

class ContactAdapter(private var contactList: ArrayList<ContactModel>) :
    RecyclerView.Adapter<ContactAdapter.ContactHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ContactHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.contact_list_child, parent, false)
    )

    override fun onBindViewHolder(holder: ContactHolder, position: Int) {
        val data = contactList[position]

        holder.txt_contact_name.text = data.contactName ?: ""
        holder.txt_contact_number.text = data.contactNumber ?: ""

        if (data.contactProfile == null) {
            holder.img_contact.visibility = View.GONE
            holder.cv_char.visibility = View.VISIBLE

            if (data.contactName != null) {
                holder.txt_char.text = data.contactName[0].toString()
            } else {
                holder.txt_char.text = ""
            }
        } else {
            holder.img_contact.visibility = View.VISIBLE
            holder.cv_char.visibility = View.GONE

            Glide.with(holder.itemView.context).load(data.contactProfile)
                .placeholder(R.drawable.profile_placeholder).into(holder.img_contact)
        }

        if(data.isSelected) {
            holder.cl_contact_child.setBackgroundColor(ContextCompat.getColor(holder.itemView.context,
            R.color.grey))
        } else {
            holder.cl_contact_child.setBackgroundColor(ContextCompat.getColor(holder.itemView.context,
                R.color.transparent))
        }

        holder.itemView.setOnClickListener {
            data.isSelected = !data.isSelected
            notifyDataSetChanged()
        }
    }

    fun filterContact(newList: ArrayList<ContactModel>) {
        contactList = newList
        notifyDataSetChanged()
    }

    override fun getItemCount() = contactList.size

    class ContactHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cl_contact_child = itemView.findViewById<ConstraintLayout>(R.id.cl_contact_child)
        val img_contact = itemView.findViewById<CustomImageView>(R.id.img_contact)
        val cv_char = itemView.findViewById<CardView>(R.id.cv_char)
        val txt_char = itemView.findViewById<CustomTextView>(R.id.txt_char)
        val txt_contact_name = itemView.findViewById<CustomTextView>(R.id.txt_contact_name)
        val txt_contact_number = itemView.findViewById<CustomTextView>(R.id.txt_contact_number)
    }
}