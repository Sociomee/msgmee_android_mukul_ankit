package com.sociomee.msgmee.ui.model


import com.google.gson.annotations.SerializedName

data class UserHobbiesModel(
        @SerializedName("data")
        val userHobbiesData: UserHobbiesData,
        @SerializedName("error")
        val error: Boolean,
        @SerializedName("success")
        val success: Boolean
) {
    data class UserHobbiesData(
            @SerializedName("successResult")
            val successResult: SuccessResult
    ) {
        data class SuccessResult(
                @SerializedName("count")
                val count: Int,
                @SerializedName("rows")
                val hobbiesLists: List<HobbiesList>
        )

        data class HobbiesList(
                @SerializedName("createdAt")
                val createdAt: String?=null,
                @SerializedName("deletedAt")
                val deletedAt: Any?=null,
                @SerializedName("hobbyId")
                val hobbyId: String?=null,
                @SerializedName("id")
                val id: String?=null,
                @SerializedName("isActive")
                val isActive: Int?=null,
                @SerializedName("isDeleted")
                val isDeleted: Int?=null,
                @SerializedName("name")
                val name: String?=null,
                @SerializedName("updatedAt")
                val updatedAt: Any?=null,
                @SerializedName("userId")
                val userId: String?=null,
                var isSelected:Boolean
        )

    }
}