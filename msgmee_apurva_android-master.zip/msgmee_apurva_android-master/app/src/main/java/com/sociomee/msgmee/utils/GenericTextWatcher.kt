package com.sociomee.msgmee.utils

import android.content.ClipboardManager
import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomEditText
import com.sociomee.msgmee.custom.widget.GoEditTextListener
import java.lang.Exception

class OtpEditText(val ctx:Context, val edt_pin1: CustomEditText, val edt_pin2: CustomEditText, val edt_pin3: CustomEditText, val edt_pin4: CustomEditText, val edt_pin5: CustomEditText, val edt_pin6: CustomEditText) {

    init {
        edt_pin1.addTextChangedListener(GenericTextWatcher(edt_pin1, edt_pin1, edt_pin2, edt_pin3, edt_pin4, edt_pin5, edt_pin6))
        edt_pin2.addTextChangedListener(GenericTextWatcher(edt_pin2, edt_pin1, edt_pin2, edt_pin3, edt_pin4, edt_pin5, edt_pin6))
        edt_pin3.addTextChangedListener(GenericTextWatcher(edt_pin3, edt_pin1, edt_pin2, edt_pin3, edt_pin4, edt_pin5, edt_pin6))
        edt_pin4.addTextChangedListener(GenericTextWatcher(edt_pin4, edt_pin1, edt_pin2, edt_pin3, edt_pin4, edt_pin5, edt_pin6))
        edt_pin5.addTextChangedListener(GenericTextWatcher(edt_pin5, edt_pin1, edt_pin2, edt_pin3, edt_pin4, edt_pin5, edt_pin6))
        edt_pin6.addTextChangedListener(GenericTextWatcher(edt_pin6, edt_pin1, edt_pin2, edt_pin3, edt_pin4, edt_pin5, edt_pin6))

        edt_pin1.addListener(object : GoEditTextListener {
            override fun onUpdate() {
                setTextToOtpEditText()
            }
        })
        edt_pin2.addListener(object : GoEditTextListener {
            override fun onUpdate() {
                setTextToOtpEditText()
            }
        })
        edt_pin3.addListener(object : GoEditTextListener {
            override fun onUpdate() {
                setTextToOtpEditText()
            }
        })
        edt_pin4.addListener(object : GoEditTextListener {
            override fun onUpdate() {
                setTextToOtpEditText()
            }
        })
        edt_pin5.addListener(object : GoEditTextListener {
            override fun onUpdate() {
                setTextToOtpEditText()
            }
        })
        edt_pin6.addListener(object : GoEditTextListener {
            override fun onUpdate() {
                setTextToOtpEditText()
            }
        })
    }

    fun getIntFromClipBoard() = safeInt((ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).text.toString(),-1)

    fun setTextToOtpEditText(){

        val text = getIntFromClipBoard()

        if (text==-1){
            return
        }

        var myClip=text.toString()

        if(myClip.length>6) {
            myClip = myClip.substring(0, 5)
        }

        try {
            edt_pin1.setText(myClip[0].toString())
            edt_pin1.setSelection(edt_pin1.text!!.length)
            edt_pin2.setText(myClip[1].toString())
            edt_pin2.setSelection(edt_pin2.text!!.length)
            edt_pin3.setText(myClip[2].toString())
            edt_pin3.setSelection(edt_pin3.text!!.length)
            edt_pin4.setText(myClip[3].toString())
            edt_pin4.setSelection(edt_pin4.text!!.length)
            edt_pin5.setText(myClip[4].toString())
            edt_pin5.setSelection(edt_pin5.text!!.length)
            edt_pin6.setText(myClip[5].toString())
            edt_pin6.setSelection(edt_pin6.text!!.length)
        }catch (e:Exception){

        }
    }

    fun safeInt(text: String, fallback: Int): Int {
        return text.toIntOrNull() ?: fallback
    }



    var text:String
    get() {
        return  edt_pin1.text.toString()+edt_pin2.text.toString()+edt_pin3.text.toString()+edt_pin4.text.toString()+edt_pin5.text.toString()+edt_pin6.text.toString()
    }
    set(value) {
        try {
            val data=safeInt(value,-1)
            if (data==-1){
                return
            }
            val myClip=data.toString()
            edt_pin1.setText(myClip[0].toString())
            edt_pin1.setSelection(edt_pin1.text!!.length)
            edt_pin2.setText(myClip[1].toString())
            edt_pin2.setSelection(edt_pin2.text!!.length)
            edt_pin3.setText(myClip[2].toString())
            edt_pin3.setSelection(edt_pin3.text!!.length)
            edt_pin4.setText(myClip[3].toString())
            edt_pin4.setSelection(edt_pin4.text!!.length)
            edt_pin5.setText(myClip[4].toString())
            edt_pin5.setSelection(edt_pin5.text!!.length)
            edt_pin6.setText(myClip[5].toString())
            edt_pin6.setSelection(edt_pin6.text!!.length)
        }catch (e:Exception){

        }
    }

}

class GenericTextWatcher constructor(private val view: View, val edt_pin1: EditText, val edt_pin2: EditText, val edt_pin3: EditText, val edt_pin4: EditText, val edt_pin5: EditText, val edt_pin6: EditText) : TextWatcher {

    override fun afterTextChanged(editable: Editable) {

    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

        val text = s.toString()
        when (view.id) {
            R.id.edt_pin1 -> {
                if (text.length == 1) {
                    edt_pin2.requestFocus()
                    edt_pin2.setSelection(edt_pin2.text.length)
                }
            }
            R.id.edt_pin2 -> {
                if (text.length == 1){
                    edt_pin3.requestFocus()
                    edt_pin3.setSelection(edt_pin3.text.length)
                } else if (text.isEmpty()){
                    edt_pin1.requestFocus()
                    edt_pin1.setSelection(edt_pin1.text.length)
                }
            }
            R.id.edt_pin3 -> {
                if (text.length == 1){
                    edt_pin4.requestFocus()
                    edt_pin4.setSelection(edt_pin4.text.length)
                } else if (text.isEmpty()){
                    edt_pin2.requestFocus()
                    edt_pin2.setSelection(edt_pin2.text.length)
                }
            }
            R.id.edt_pin4 -> {
                if (text.length == 1){
                    edt_pin5.requestFocus()
                    edt_pin5.setSelection(edt_pin5.text.length)
                } else if (text.isEmpty()){
                    edt_pin3.requestFocus()
                    edt_pin3.setSelection(edt_pin3.text.length)
                }
            }
            R.id.edt_pin5 -> {
                if (text.length == 1){
                    edt_pin6.requestFocus()
                    edt_pin6.setSelection(edt_pin6.text.length)
                } else if (text.isEmpty()){
                    edt_pin4.requestFocus()
                    edt_pin4.setSelection(edt_pin4.text.length)
                }
            }
            R.id.edt_pin6 -> {
                if (text.isEmpty()){
                    edt_pin5.requestFocus()
                    edt_pin5.setSelection(edt_pin5.text.length)
                }
            }
        }

    }

}
