package com.sociomee.msgmee.ui.model

import com.sociomee.msgmee.utils.Constants

data class MessageListModel(val name: String, val lastMessage: String,
                            val messageType: Constants.LastMessageType, val time: String,
                            val unreadCount: Int, val isOnline: Boolean = false,
                            var isPinned: Boolean = false, var isSelected: Boolean = false)