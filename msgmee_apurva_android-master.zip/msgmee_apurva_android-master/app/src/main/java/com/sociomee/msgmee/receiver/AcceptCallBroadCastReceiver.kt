package com.sociomee.msgmee.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import com.sociomee.msgmee.notification.MyNotificationBuilder
import com.sociomee.msgmee.ui.activity.CallActivity
import com.sociomee.msgmee.ui.repo.CallingRepo

class AcceptCallBroadCastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        val callingRepo = CallingRepo()

        val bodyMap: HashMap<String, Any> = hashMapOf(
            "callRoomId" to MyNotificationBuilder.callRoomId,
            "callState" to "inCall"
        )
        callingRepo.updateCallState(bodyMap, type = "accept")

        // if accepting call then opening call activity
        val callIntent = Intent(context, CallActivity::class.java)
        callIntent.putExtra("callRoomId", MyNotificationBuilder.callRoomId)
        callIntent.putExtra("isVideoCall", MyNotificationBuilder.isVideoCall)
        callIntent.putExtra("isOwner", false)
        callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context?.startActivity(callIntent)

        // closing notification
        with(NotificationManagerCompat.from(context!!)) {
            cancel(MyNotificationBuilder.callNotificationId)
        }
    }

}