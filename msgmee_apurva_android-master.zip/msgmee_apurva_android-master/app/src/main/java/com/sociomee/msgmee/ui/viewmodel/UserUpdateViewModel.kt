package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData

import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.repo.UserUpdateRepo

class UserUpdateViewModel : MyViewModel(){

   var userUpdateModel = MutableLiveData<Boolean>()
   lateinit var userUpdateRepo: UserUpdateRepo

    fun  observeUserUpdate() = userUpdateModel

    fun updateUser(body:HashMap<String,Any>){
        if(!this::userUpdateRepo.isInitialized){
            userUpdateRepo = UserUpdateRepo()
        }
        isLoading.value = true
        userUpdateRepo.updateUser(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS){
                userUpdateModel.value = it.data
            }else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }
}