package com.sociomee.msgmee.ui.`interface`

interface GroupInfoInterface {

    fun memberLongPressed(position: Int)

}