package com.sociomee.msgmee.ui.model

import com.google.gson.annotations.SerializedName
import com.sociomee.msgmee.utils.Constants

data class CallHistoryModel(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("successResult")
        val successResult: SuccessResult,
        var isRefresh: Boolean = true
    ) {
        data class SuccessResult(
            @SerializedName("rows")
            val callHistoryList: ArrayList<CallHistoryData>
        )
    }
}
data class CallHistoryData(
    @SerializedName("callDuration")
    val callDuration: Int,
    @SerializedName("callRoomId")
    val callRoomId: String,
    @SerializedName("callState")
    val callState: String,
    @SerializedName("endTime")
    val endTime: Any,
    @SerializedName("isOwner")
    val isOwner: Int,
    @SerializedName("members")
    val members: List<Member>,
    @SerializedName("membersCount")
    val membersCount: Int,
    @SerializedName("isVideo")
    val isVideo: Int,
    @SerializedName("startTime")
    val startTime: String,
    var callText: String = "",
    var callType: Constants.CallType
) {
    data class Member(
        @SerializedName("id")
        val id: String,
        @SerializedName("isOwner")
        val isOwner: Int,
        @SerializedName("name")
        val name: String,
        @SerializedName("profileThumb")
        val profileThumb: String?
    )
}