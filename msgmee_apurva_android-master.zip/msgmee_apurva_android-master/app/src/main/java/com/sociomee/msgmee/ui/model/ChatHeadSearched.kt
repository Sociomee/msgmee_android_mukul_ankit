package com.sociomee.msgmee.ui.model

data class ChatHeadSearched(val searchText: String)