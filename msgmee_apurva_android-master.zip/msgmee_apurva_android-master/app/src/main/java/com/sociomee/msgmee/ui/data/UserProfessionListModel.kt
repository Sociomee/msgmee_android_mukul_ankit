package com.sociomee.msgmee.ui.data


import com.google.gson.annotations.SerializedName

data class UserProfessionListModel(
        @SerializedName("data")
        val userProfessionData: UserProfessionData,
        @SerializedName("error")
        val error: Boolean,
        @SerializedName("success")
        val success: Boolean
) {
    data class UserProfessionData(
            @SerializedName("successResult")
            val successResult: SuccessResult
    )

    data class SuccessResult(
            @SerializedName("rows")
            val professionLists: List<ProfessionList>
    )

    data class ProfessionList(
            @SerializedName("createdAt")
            val createdAt: String,
            @SerializedName("deletedAt")
            val deletedAt: Any,
            @SerializedName("id")
            val id: String,
            @SerializedName("isActive")
            val isActive: Int,
            @SerializedName("isDeleted")
            val isDeleted: Int,
            @SerializedName("name")
            val name: String,
            @SerializedName("updatedAt")
            val updatedAt: Any,
            var isSelected: Boolean
    )
}

