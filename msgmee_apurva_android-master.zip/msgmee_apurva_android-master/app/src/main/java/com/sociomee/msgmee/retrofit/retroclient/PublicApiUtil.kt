package com.sociomee.msgmee.retrofit.retroclient

import com.sociomee.msgmee.retrofit.CustomCallAdapter
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object PublicApiUtil {

    private val requestAPI: PublicApiUtil? = null
    private const val PUBLIC_IP_API = "http://ip-api.com"

    val client: Retrofit
        get() {
            val retrofit: Retrofit
            val interceptor = HttpLoggingInterceptor()
            interceptor.setLevel(HttpLoggingInterceptor.Level.BODY)
            val client = OkHttpClient.Builder().addInterceptor(interceptor).connectTimeout(60, TimeUnit.SECONDS)
                    .readTimeout(60, TimeUnit.SECONDS)
                    .writeTimeout(60, TimeUnit.SECONDS).build()
            retrofit = Retrofit.Builder()
                    .baseUrl(PUBLIC_IP_API)
                    .addCallAdapterFactory(CustomCallAdapter())
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(client)
                    .build()
            return retrofit
        }
}
