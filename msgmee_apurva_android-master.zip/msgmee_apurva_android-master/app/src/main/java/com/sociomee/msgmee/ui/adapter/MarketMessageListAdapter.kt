package com.sociomee.msgmee.ui.adapter

import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomIconView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.`interface`.SingleItemCallback
import com.sociomee.msgmee.ui.activity.MarketChatActivity
import com.sociomee.msgmee.utils.VerticalTextView

class MarketMessageListAdapter(private val singleItemCallback: SingleItemCallback) : RecyclerView.Adapter<MarketMessageListAdapter.MarketListHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = MarketListHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.market_message_child, parent ,false)
    )

    override fun getItemCount() = 10

    override fun onBindViewHolder(holder: MarketListHolder, position: Int) {
        holder.img_last_message.visibility = View.GONE

        holder.txt_message_count.text = "10"
        holder.txt_messages_name.text = "Harsh Barnwal"
        holder.txt_product_name.text = "Lamborghini"

        if(position % 2 == 0) {
            holder.cv_message_circle.visibility = View.GONE

            holder.txt_market_type.text = holder.itemView.context.getString(R.string.selling)
            holder.cl_market_type.setBackgroundColor(Color.parseColor("#688473"))
        } else {
            holder.txt_market_type.text = holder.itemView.context.getString(R.string.buying)
            holder.cl_market_type.setBackgroundColor(Color.parseColor("#ACDAD6"))
        }

        holder.itemView.setOnClickListener {
            holder.itemView.context.startActivity(
                    Intent(holder.itemView.context, MarketChatActivity::class.java))
        }
        holder.itemView.setOnLongClickListener {
            singleItemCallback.itemInteracted(position)
            true
        }
    }

    class MarketListHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val img_last_message = itemView.findViewById<CustomIconView>(R.id.img_last_message)
        val txt_message_count = itemView.findViewById<CustomTextView>(R.id.txt_message_count)
        val txt_messages_name = itemView.findViewById<CustomTextView>(R.id.txt_messages_name)
        val txt_product_name = itemView.findViewById<CustomTextView>(R.id.txt_product_name)
        val cv_message_circle = itemView.findViewById<CardView>(R.id.cv_message_circle)
        val cl_market_type = itemView.findViewById<ConstraintLayout>(R.id.cl_market_type)
        val txt_market_type = itemView.findViewById<VerticalTextView>(R.id.txt_market_type)
    }
}