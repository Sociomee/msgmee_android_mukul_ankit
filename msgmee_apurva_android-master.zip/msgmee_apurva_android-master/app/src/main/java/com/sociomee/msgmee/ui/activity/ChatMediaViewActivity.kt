package com.sociomee.msgmee.ui.activity

import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.android.exoplayer2.*
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory
import com.google.android.exoplayer2.util.Util
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.ui.model.ChatModel
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.TimeAgo
import com.sociomee.msgmee.utils.isPlaying
import com.sociomee.msgmee.utils.mediaFullUrl
import kotlinx.android.synthetic.main.chat_media_view_activity.*
import kotlinx.android.synthetic.main.chat_media_view_activity.img_toolbar_back

class ChatMediaViewActivity : CustomAppCompatActivity() {

    private lateinit var chatModel: ChatModel
    var exoplayer: SimpleExoPlayer? = null
    var isHidden = false
    var isImage = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.chat_media_view_activity)

        chatModel = Constants.myGson.fromJson(
            intent!!.extras!!.getString("chatModel"),
            ChatModel::class.java
        )

        bindData()
        setViewsClick()
    }

    private fun setViewsClick() {
        img_toolbar_back.setOnClickListener {
            onBackPressed()
        }
        img_media.setOnClickListener {
            changeUIVisibility()
        }
        exo_video.videoSurfaceView.setOnClickListener {
            changeUIVisibility()
        }
        img_video_play.setOnClickListener {
            if (exoplayer!!.isPlaying()) {
                exoplayer!!.playWhenReady = false
                img_video_play.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_play))
            } else {
                exoplayer!!.playWhenReady = true
                img_video_play.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_pause))
            }
        }
    }

    private fun changeUIVisibility() {
        if (isHidden) {
            isHidden = false

            ll_bottom_view.animate().translationY(0F)
            cl_top_view.animate().translationY(0F)
            if (!isImage) {
                img_video_play.visibility = View.VISIBLE
            }
        } else {
            isHidden = true

            cl_top_view.animate().translationY(-ll_bottom_view.height.toFloat())
            ll_bottom_view.animate().translationY(ll_bottom_view.height.toFloat())
            if (!isImage) {
                img_video_play.visibility = View.GONE
            }
        }
    }

    override fun setInitialLanguage() {

    }

    override fun bindData() {
        isImage = chatModel.messageType == "image"
        if (isImage) {
            exo_video.visibility = View.GONE
            img_video_play.visibility = View.GONE

            Glide.with(this).load(chatModel.messageJson!!.mediaUrl.mediaFullUrl()).into(img_media)
        } else {
            img_media.visibility = View.GONE

            initializePlayer()
        }

        txt_message.text = chatModel.messageText
        Glide.with(this).load(chatModel.senderProfileThumb).placeholder(R.drawable.profile_placeholder).into(img_profile)
        txt_chat_head_name.text = chatModel.senderUsername
        txt_message_time.text = TimeAgo.getTimeAgo(chatModel.createdAt)
    }

    private fun initializePlayer() {
        if (exoplayer == null) {
            exoplayer = ExoPlayerFactory.newSimpleInstance(
                this,
                DefaultRenderersFactory(this), DefaultTrackSelector(),
                DefaultLoadControl()
            )
        }
        exo_video.player = exoplayer
        exo_video.requestFocus()
        exo_video.useController = false

        val dataSourceFactory = DefaultDataSourceFactory(
            this,
            Util.getUserAgent(this, "messenger")
        )
        val mediaSource = ProgressiveMediaSource.Factory(dataSourceFactory)
            .createMediaSource(Uri.parse(chatModel.messageJson!!.mediaUrl.mediaFullUrl()))

        exoplayer!!.prepare(mediaSource)
        exo_video.player = exoplayer

        exoplayer!!.repeatMode = Player.REPEAT_MODE_ONE
    }

    override fun onResume() {
        super.onResume()
        exoplayer?.playWhenReady = true
    }

    override fun onPause() {
        super.onPause()
        exoplayer?.playWhenReady = false
    }

    private fun releasePlayer() {
        exoplayer?.stop()
        exoplayer?.release()
    }

    override fun onDestroy() {
        super.onDestroy()
        releasePlayer()
    }
}