package com.sociomee.msgmee.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomIconView
import com.sociomee.msgmee.custom.widget.CustomImageView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.`interface`.SingleItemCallback
import com.sociomee.msgmee.ui.activity.CallActivity
import com.sociomee.msgmee.ui.model.UserInCallModel
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.TimeAgo
import com.sociomee.msgmee.utils.callStatus
import java.util.*
import kotlin.collections.ArrayList

@Suppress("DEPRECATION")
class ActiveCallAdapter(
    private val inCallUserList: ArrayList<UserInCallModel>,
    private val isOwner: Boolean,
    private val singleItemCallback: SingleItemCallback
) : RecyclerView.Adapter<ActiveCallAdapter.ActiveCallHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ActiveCallHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.active_call_child, parent, false)
    )

    override fun getItemCount() = inCallUserList.size

    override fun onBindViewHolder(holder: ActiveCallHolder, position: Int) {
        val model = inCallUserList[position]
        if (holder.callTimer != null) {
            holder.callTimer!!.cancel()
        }
        holder.txt_call_name.text = model.userName
        Glide.with(holder.itemView.context).load(model.profileImageThumb)
            .placeholder(R.drawable.profile_placeholder).into(holder.img_call_profile)

        // starting timer
        when {
            Constants.isCurrentUser(model.memberId) -> {
                holder.img_end_call.visibility = View.GONE
                holder.txt_call_duration.text = holder.itemView.context.getString(R.string.active)
            }
            model.callState == "inCall" -> {
                var elapsedTime = (TimeAgo.getTimeDifference(model.startTime))
                holder.callTimer = Timer()
                val tt: TimerTask = object : TimerTask() {
                    override fun run() {
                        (holder.itemView.context as CallActivity).runOnUiThread {
                            elapsedTime += 1L
                            val seconds = elapsedTime % 60
                            val minutes = elapsedTime / 60
                            val stringTime =
                                String.format(Locale.ENGLISH, "%02d:%02d", minutes, seconds)
                            holder.txt_call_duration.text = stringTime
                        }
                    }
                }
                holder.callTimer!!.schedule(tt, 0L, 1000L)
                holder.img_end_call.visibility = View.VISIBLE
            }
            else -> {
                holder.txt_call_duration.text = model.callState.callStatus()
                holder.img_end_call.visibility = View.VISIBLE
            }
        }

        if (isOwner) {
            holder.img_end_call.alpha = 1.0f
            holder.img_end_call.setOnClickListener {
                singleItemCallback.itemInteracted(position)
            }
        } else {
            holder.img_end_call.alpha = 0.4f
            holder.img_end_call.setOnClickListener {}
        }
    }

    class ActiveCallHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var callTimer: Timer? = null

        val img_call_profile = itemView.findViewById<CustomImageView>(R.id.img_call_profile)
        val img_end_call = itemView.findViewById<CustomIconView>(R.id.img_end_call)
        val txt_call_duration = itemView.findViewById<CustomTextView>(R.id.txt_call_duration)
        val txt_call_name = itemView.findViewById<CustomTextView>(R.id.txt_call_name)
    }
}