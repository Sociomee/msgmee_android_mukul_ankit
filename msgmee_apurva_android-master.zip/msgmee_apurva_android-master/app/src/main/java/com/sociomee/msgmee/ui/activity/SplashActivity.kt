package com.sociomee.msgmee.ui.activity

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.Log
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.messaging.FirebaseMessaging
import com.huawei.multimedia.audiokit.utils.Constant
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.model.UserInfoModel
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.InitApplication
import com.sociomee.msgmee.utils.MyPreferences
import kotlinx.android.synthetic.main.splash_activity.*

class SplashActivity : CustomAppCompatActivity() {

    private lateinit var initApplicatio: InitApplication
    private lateinit var handler: Handler
    private lateinit var runnable: Runnable

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash_activity)

        handler = Handler(Looper.myLooper()!!)
        runnable = Runnable {
//            showIpDialog()
            loadUserData()
        }

        handler.postDelayed(runnable, 1000)


        initApplicatio = InitApplication(this)

        if (initApplication!!.state) {
            switchCompat.isChecked = true
        }

        switchCompat.setOnCheckedChangeListener { _, isChecked ->
            handler.removeCallbacks(runnable)
            if (isChecked) {
                initApplication!!.state = true
                delegate.localNightMode = AppCompatDelegate.MODE_NIGHT_NO
            } else {
                initApplication!!.state = false
                delegate.localNightMode = AppCompatDelegate.MODE_NIGHT_YES
            }
        }
        fetchAndSaveFCM()
    }

    private fun showIpDialog() {
        val availableBaseUrl = MyPreferences.getFromPreferencesOrNull(this, "baseUrl") ?: MyRetrofit.baseUrl
        val availableSocketUrl = MyPreferences.getFromPreferencesOrNull(this, "socketUrl") ?: MyRetrofit.socketUrl

        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setTitle("BaseUrl Picker")

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        // base url editText
        val baseUrlEdt = EditText(this)
        baseUrlEdt.hint = "Enter BaseUrl"
        baseUrlEdt.setText(availableBaseUrl)
        baseUrlEdt.inputType = InputType.TYPE_CLASS_TEXT
        layout.addView(baseUrlEdt)

        // socket url editText
        val socketUrlEdt = EditText(this)
        socketUrlEdt.hint = "Enter Socket Url"
        socketUrlEdt.setText(availableSocketUrl)
        socketUrlEdt.inputType = InputType.TYPE_CLASS_TEXT
        layout.addView(socketUrlEdt)

        builder.setView(layout)

        builder.setPositiveButton("OK") { _, _ ->
            val newBaseUrl = baseUrlEdt.text.toString().trim()
            val newSocketUrl = socketUrlEdt.text.toString().trim()
            MyRetrofit.baseUrl = newBaseUrl
            MyRetrofit.socketUrl = newSocketUrl

            MyPreferences.saveStringInPreference(this, "baseUrl" ,newBaseUrl)
            MyPreferences.saveStringInPreference(this, "socketUrl" ,newSocketUrl)

            loadUserData()
        }
        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    private fun loadUserData() {
        val data = MyPreferences.getFromPreferences(this, Constants.userDataKey) ?: ""
        if (data.isNotEmpty()) {
            Constants.userInfo = Constants.myGson.fromJson(MyPreferences.getFromPreferences(this, Constants.userDataKey), UserInfoModel::class.java)
        }
        if (Constants.userInfo != null) {
//            startActivity(HomeActivity::class.java)
        } else {
            startActivity(WelcomeActivity::class.java)
            finish()
        }
        if (MyPreferences.isUserLoggedIn(this)) {
            startActivity(MessengerActivity::class.java)
        } else {
            startActivity(WelcomeActivity::class.java)

        }
        finish()
    }

    override fun setInitialLanguage() {

    }

    private fun fetchAndSaveFCM() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.v("harsh", "Fetching FCM registration token failed", task.exception)
                return@OnCompleteListener
            }

            // Get new FCM registration token
            val token = task.result

            if (token != MyPreferences.getFcmToken(this@SplashActivity)) {
                MyPreferences.saveFcmToken(this@SplashActivity, token.toString())
            }
            // Log and toast
            Log.d("harshFCMToken", token.toString())
        })
    }

    override fun onDestroy() {
        handler.removeCallbacks(runnable)
        super.onDestroy()
    }

    override fun bindData() {

    }
}