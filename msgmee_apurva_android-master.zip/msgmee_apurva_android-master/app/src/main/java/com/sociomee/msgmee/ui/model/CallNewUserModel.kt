package com.sociomee.msgmee.ui.model

import com.google.gson.annotations.SerializedName

data class CallNewUserModel(
    @SerializedName("callRoomId")
    val callRoomId: String,
    @SerializedName("memberId")
    val memberId: String,
    @SerializedName("member")
    val member: Member,
) {
    data class Member(
        @SerializedName("fullname")
        val fullName: String,
        @SerializedName("sequenceNo")
        val sequenceNo: Int,
        @SerializedName("userId")
        val userId: String,
        @SerializedName("userName")
        val userName: String,
        @SerializedName("profileImageThumb")
        val profileImageThumb: String?
    )
}