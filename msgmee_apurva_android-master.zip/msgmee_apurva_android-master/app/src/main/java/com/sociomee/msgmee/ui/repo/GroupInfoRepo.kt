package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.ApiCall
import com.sociomee.msgmee.ui.model.*
import retrofit2.Response

class GroupInfoRepo {

    fun fetchGroupInfo(body: HashMap<String, Any>): MutableLiveData<MyResponse<GroupInfoData>> {
        val data = MutableLiveData<MyResponse<GroupInfoData>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.fetchGroupInfo(body)

        call.enqueue(object: MyCallback<GroupInfoModel> {
            override fun success(response: Response<GroupInfoModel>) {
                data.postValue(MyResponse.success(response.body()!!.data.groupInfoModel))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }
        })
        return data
    }

    fun fetchGroupPeopleList(body: HashMap<String, Any>): MutableLiveData<MyResponse<List<ChatMemberData>>> {
        val data = MutableLiveData<MyResponse<List<ChatMemberData>>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.fetchGroupPeopleList(body)

        call.enqueue(object: MyCallback<ChatMemberModel> {
            override fun success(response: Response<ChatMemberModel>) {
                data.postValue(MyResponse.success(response.body()!!.data.successResult.rows))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }
        })
        return data
    }

    fun updateGroupInfo(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.updateGroupInfo(body)

        call.enqueue(object: MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }
        })
        return data
    }

    fun changeGroupMemberRole(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.changeGroupMemberRole(body)

        call.enqueue(object: MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }
        })
        return data
    }

    fun leaveGroup(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.leaveGroup(body)

        call.enqueue(object: MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }
        })
        return data
    }

    fun removeUserFromGroup(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.removeUserFromGroup(body)

        call.enqueue(object: MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }
        })
        return data
    }

}