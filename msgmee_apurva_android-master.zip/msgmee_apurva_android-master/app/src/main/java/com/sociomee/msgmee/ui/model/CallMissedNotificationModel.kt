package com.sociomee.msgmee.ui.model


import com.google.gson.annotations.SerializedName

data class CallMissedNotificationModel(
    @SerializedName("CallRoomInfo")
    val callRoomInfo: CallRoomInfo?
) {
    data class CallRoomInfo(
        @SerializedName("callDuration")
        val callDuration: Int,
        @SerializedName("callStartTime")
        val callStartTime: String,
        @SerializedName("callState")
        val callState: String,
        @SerializedName("callerImageThumb")
        val callerImageThumb: Any,
        @SerializedName("callerUserId")
        val callerUserId: String,
        @SerializedName("callerUserName")
        val callerUserName: String,
        @SerializedName("isGroup")
        val isGroup: Int,
        @SerializedName("isVideo")
        val isVideo: Int,
        @SerializedName("memberId")
        val memberId: String
    )
}