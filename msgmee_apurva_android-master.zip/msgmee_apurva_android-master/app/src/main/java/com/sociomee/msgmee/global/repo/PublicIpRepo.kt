package com.sociomee.msgmee.global.repo

import android.content.Context
import android.util.Log
import com.sociomee.msgmee.global.model.SavedLocationModel
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.`interface`.PublicIPApi
import com.sociomee.msgmee.retrofit.model.IPModel
import com.sociomee.msgmee.retrofit.retroclient.PublicApiUtil
import com.sociomee.msgmee.utils.Constants
import retrofit2.Response

class PublicIpRepo {

    companion object {
        fun fetchLocationFromPublicIp(context: Context) {
            val publicIPApi: PublicIPApi = PublicApiUtil.client.create(PublicIPApi::class.java)
            val call = publicIPApi.locationDetails()
            call.enqueue(object : MyCallback<IPModel> {
                override fun success(response: Response<IPModel>) {
                    if (response.body() != null) {
                        val savedLocationModel = SavedLocationModel(response.body()!!.lat,
                                response.body()!!.lon, response.body()!!.country,
                                response.body()!!.regionName, response.body()!!.city)
                        Constants.saveLocation(context, savedLocationModel)
                    }
                }

                override fun networkError() {
                    Log.v("harsh", "public ip networkError")
                }

                override fun authError() {
                    Log.v("harsh", "public ip authError")
                }

                override fun serverError() {
                    Log.v("harsh", "public ip serverError")
                }
            })
        }
    }
}