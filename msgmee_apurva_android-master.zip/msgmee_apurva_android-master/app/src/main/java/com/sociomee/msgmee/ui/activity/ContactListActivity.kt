package com.sociomee.msgmee.ui.activity

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.ui.adapter.ContactAdapter
import com.sociomee.msgmee.ui.model.ContactModel
import kotlinx.android.synthetic.main.contact_list_activity.*
import kotlinx.coroutines.*

class ContactListActivity : CustomAppCompatActivity() {

    lateinit var contactAdapter: ContactAdapter
    private val REQUIRED_PERMISSIONS = arrayOf(
        "android.permission.READ_CONTACTS"
    )
    private val REQUEST_CODE_PERMISSIONS = 1001
    private val contactList = ArrayList<ContactModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.contact_list_activity)

        contactAdapter = ContactAdapter(contactList)
        if (contactPermissionsGranted()) {
            CoroutineScope(Dispatchers.Default).launch {
                getContactList()
            }
        } else {
            ActivityCompat.requestPermissions(
                this,
                REQUIRED_PERMISSIONS,
                REQUEST_CODE_PERMISSIONS
            )
        }
        bindData()
        setViewsClick()
    }

    private fun setViewsClick() {
        img_toolbar_back.setOnClickListener {
            onBackPressed()
        }
        // watching text changes
        edt_search.addTextChangedListener(textChangeWatcher)

        txt_toolbar_send.setOnClickListener {
            val selectedContacts = ArrayList<ContactModel>()
            contactList.forEach {
                if (it.isSelected)
                    selectedContacts.add(it)
            }
            if (selectedContacts.isNotEmpty()) {
                val data = Intent()
                data.putParcelableArrayListExtra("contactList", selectedContacts)
                setResult(RESULT_OK, data)
            }
            finish()
        }
    }

    private val textChangeWatcher = object : TextWatcher {
        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

        }

        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

        }

        override fun afterTextChanged(p0: Editable?) {
            filterContactList()
        }
    }

    private fun filterContactList() {
        val newText = edt_search.text.toString().trim()

        if (newText.isEmpty()) {
            contactAdapter.filterContact(contactList)
        } else {
            val newList = ArrayList<ContactModel>()

            contactList.forEach {
                if ((it.contactName ?: "").contains(newText, ignoreCase = true)) {
                    newList.add(it)
                }
            }
            contactAdapter.filterContact(newList)
        }
    }

    override fun setInitialLanguage() {
        tl_search.hint = getString(R.string.search_contacts)
        txt_toolbar_send.text = getString(R.string.send)
        txt_chat_head_name.text = getString(R.string.contact_list)
    }

    override fun bindData() {
        rl_contacts.layoutManager = LinearLayoutManager(this)
        rl_contacts.adapter = contactAdapter
    }

    private suspend fun getContactList() {
        val contentResolver = contentResolver
        val cursor =
            contentResolver.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null)
        if (cursor != null && cursor.count > 0) {
            while (cursor.moveToNext()) {
                val id = cursor.getString(
                    cursor.getColumnIndex(ContactsContract.Contacts._ID)
                )
                val name = cursor.getString(
                    cursor.getColumnIndex(
                        ContactsContract.Contacts.DISPLAY_NAME
                    )
                )
                val profilePath = cursor.getString(
                    cursor.getColumnIndex(
                        ContactsContract.Contacts.PHOTO_URI
                    )
                )

                if (cursor.getInt(
                        cursor.getColumnIndex(
                            ContactsContract.Contacts.HAS_PHONE_NUMBER
                        )
                    ) > 0
                ) {
                    val pCur = contentResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                        arrayOf(id), null
                    )
                    if (pCur != null) {
                        while (pCur.moveToNext()) {
                            val phoneNo = pCur.getString(
                                pCur.getColumnIndex(
                                    ContactsContract.CommonDataKinds.Phone.NUMBER
                                )
                            )
                            var profileUri: Uri? = null
                            if (profilePath != null && profilePath.isNotEmpty()) {
                                profileUri = Uri.parse(profilePath)
                            }
                            val model = ContactModel(
                                name,
                                phoneNo.replace(" ", ""),
                                profileUri
                            )
                            if (!contactList.contains(model)) {
                                contactList.add(model)
                            }
                        }
                    }
                    pCur?.close()
                }
            }
        }
        cursor?.close()
        updateContactList()
    }

    private suspend fun updateContactList() {
        withContext(Dispatchers.Main) {
            contactAdapter.notifyDataSetChanged()
            progress_bar.visibility = View.GONE
        }
    }

    private fun contactPermissionsGranted(): Boolean {
        for (permission in REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    permission
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return false
            }
        }
        return true
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (contactPermissionsGranted()) {
                CoroutineScope(Dispatchers.Default).launch {
                    getContactList()
                }
            } else {
                Toast.makeText(this, "Permissions not granted by the user.", Toast.LENGTH_SHORT)
                    .show()
                finish()
            }
        }
    }
}