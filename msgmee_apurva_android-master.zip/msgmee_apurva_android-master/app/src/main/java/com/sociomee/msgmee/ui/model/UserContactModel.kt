package com.sociomee.app.ui.profile.data


import com.google.gson.annotations.SerializedName

data class UserContactModel(
        @SerializedName("data")
    val userContactData: UserContactData,
        @SerializedName("error")
    val error: Boolean,
        @SerializedName("success")
    val success: Boolean
) {
    data class UserContactData(
        @SerializedName("successResult")
        val userContactList: List<UserContactList>
    ) {
        data class UserContactList(
                @SerializedName("contact")
                val contact: String,
                @SerializedName("id")
                val id: String,
                @SerializedName("isEmail")
                val isEmail: Int,
                @SerializedName("profileImage")
                val profileImage: String,
                @SerializedName("userId")
                val userId: String
        )
    }
}