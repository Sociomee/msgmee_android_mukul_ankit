package com.sociomee.msgmee.ui.model

data class TypingModel(val username: String, val userId: String, val chatHeadId: String)