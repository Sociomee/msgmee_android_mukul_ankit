package com.sociomee.msgmee.ui.model

import android.widget.ProgressBar

data class FileDownloadModel(val messageId: String, val fileName: String,
                             val fileServerPath: String, val progressBar: ProgressBar)