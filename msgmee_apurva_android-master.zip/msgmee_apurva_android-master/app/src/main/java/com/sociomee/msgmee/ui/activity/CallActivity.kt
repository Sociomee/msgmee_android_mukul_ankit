package com.sociomee.msgmee.ui.activity

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.app.ActivityCompat
import androidx.core.view.children
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.exoplayer2.*
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
import com.google.android.exoplayer2.upstream.DataSource
import com.google.android.exoplayer2.upstream.DataSpec
import com.google.android.exoplayer2.upstream.RawResourceDataSource
import com.google.android.exoplayer2.upstream.RawResourceDataSource.RawResourceDataSourceException
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.gson.reflect.TypeToken
import com.sociomee.msgmee.MsgMee
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.custom.widget.CustomEditText
import com.sociomee.msgmee.custom.widget.CustomIconView
import com.sociomee.msgmee.custom.widget.CustomImageView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.notification.MyNotificationBuilder
import com.sociomee.msgmee.ui.adapter.ActiveCallAdapter
import com.sociomee.msgmee.ui.adapter.AddCallAdapter
import com.sociomee.msgmee.ui.adapter.GroupVideoCallAdapter
import com.sociomee.msgmee.ui.model.*
import com.sociomee.msgmee.ui.repo.CallingRepo
import com.sociomee.msgmee.ui.viewmodel.CallingVM
import com.sociomee.msgmee.ui.viewmodel.FriendListVM
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.MySocketEvents
import com.sociomee.msgmee.utils.ScrollListener
import com.sociomee.msgmee.utils.callStatus
import com.xiaofeng.flowlayoutmanager.Alignment
import com.xiaofeng.flowlayoutmanager.FlowLayoutManager
import io.agora.rtc.IRtcEngineEventHandler
import io.agora.rtc.RtcEngine
import io.agora.rtc.video.VideoCanvas
import io.socket.client.Ack
import kotlinx.android.synthetic.main.call_activity.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.json.JSONObject
import java.util.*
import kotlin.collections.ArrayList
import androidx.lifecycle.Observer
import com.sociomee.msgmee.ui.`interface`.SingleItemCallback
import kotlinx.android.synthetic.main.call_removed_dialog.view.*

@Suppress("DEPRECATION")
@SuppressLint("InflateParams")
class CallActivity : CustomAppCompatActivity(), View.OnClickListener {

    private lateinit var callListBottomSheet: BottomSheetDialog
    private lateinit var peopleListBottomSheet: BottomSheetDialog
    private var isVideoEnable = true
    private var isMicEnable = true
    private var isVideoCall = true
    private lateinit var callRoomId: String
    private val AUDIO_CALL_CODE = 100
    private val VIDEO_CALL_CODE = 200
    private val AUDIO_CALL_REQUIRED_PERMISSIONS = arrayOf(
        "android.permission.RECORD_AUDIO"
    )
    private val VIDEO_CALL_REQUIRED_PERMISSIONS = arrayOf(
        "android.permission.RECORD_AUDIO",
        "android.permission.CAMERA"
    )
    private var xDelta = 0
    private var yDelta = 0
    private lateinit var groupVideoCallAdapter: GroupVideoCallAdapter
    private val inCallUserList = ArrayList<UserInCallModel>()
    private var isGroupCall = false
    private var isInPip = false
    private var onStopCalled = false
    private var isPipAvailable = true
    private lateinit var friendListVM: FriendListVM
    private lateinit var callingVM: CallingVM
    private lateinit var callingRepo: CallingRepo
    private var friendList = ArrayList<FriendModel>()
    private var isLastPage = false
    private var isLoading = false
    private var isOwner = false
    private lateinit var addCallAdapter: AddCallAdapter
    private var callTo: StartCallModel? = null
    private var pageIndex = 0
    private var searchText: String = ""
    private var audioCallLayoutList = ArrayList<ConstraintLayout>()
    private var removeStateList = listOf("disconnected'", "declined", "ended", "missed")
    private var callRoomData: JSONObject? = null
    private val userInCallType = object : TypeToken<ArrayList<UserInCallModel>>() {}.type
    private var countDownTimer: CountDownTimer? = null
    var exoplayer: SimpleExoPlayer? = null
    var isCallStarted = false
    var activeCallAdapter: ActiveCallAdapter? = null

    // Agora variables
    private var rtcEngine: RtcEngine? = null
    private val rtcEventHandler = object : IRtcEngineEventHandler() {
        override fun onUserJoined(uid: Int, elapsed: Int) {}
        override fun onUserOffline(uid: Int, reason: Int) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.call_activity)

        isVideoCall = intent?.extras?.getBoolean("isVideoCall") ?: true
        isOwner = intent?.extras?.getBoolean("isOwner") ?: true
        callRoomId = intent?.extras?.getString("callRoomId") ?: ""

        audioCallLayoutList.add(cl_call_profile_1_outer)
        audioCallLayoutList.add(cl_call_profile_2_outer)
        audioCallLayoutList.add(cl_call_profile_3_outer)
        audioCallLayoutList.add(cl_call_profile_4_outer)
        audioCallLayoutList.add(cl_call_profile_5_outer)
        audioCallLayoutList.add(cl_call_profile_6_outer)
        audioCallLayoutList.add(cl_call_profile_6_outer)
        audioCallLayoutList.add(cl_call_profile_7_outer)

        val callToData: String? = intent?.extras?.getString("callToData")
        if (callToData != null && callToData.isNotEmpty()) {
            callTo = Constants.myGson.fromJson(callToData, StartCallModel::class.java)
        }

        if (isOwner && callToData == null) {
            showToast()
            finish()
        }

        isPipAvailable = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            isVideoCall && packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        } else {
            false
        }

        initData()
        observeData()
        registerSocketEvents()
        setViewsClick()
        bindData()

        // checking for required permissions
        if (isVideoCall) {
            if (Constants.isPermissionGranted(this, VIDEO_CALL_REQUIRED_PERMISSIONS)) {
                initAgora()
            } else {
                ActivityCompat.requestPermissions(
                    this,
                    VIDEO_CALL_REQUIRED_PERMISSIONS,
                    VIDEO_CALL_CODE
                )
            }
        } else {
            cl_single_video_call.visibility = View.GONE
            if (Constants.isPermissionGranted(this, AUDIO_CALL_REQUIRED_PERMISSIONS)) {
                initAgora()
            } else {
                ActivityCompat.requestPermissions(
                    this,
                    AUDIO_CALL_REQUIRED_PERMISSIONS,
                    AUDIO_CALL_CODE
                )
            }
        }

        EventBus.getDefault().register(this)
    }

    private fun registerSocketEvents() {
        if (!MsgMee.getSocket().hasListeners(MySocketEvents.EVENT_CALL_STATE_UPDATE)) {
            MsgMee.getSocket()
                .on(MySocketEvents.EVENT_CALL_STATE_UPDATE, MySocketEvents.callStateUpdate)
        }
        if (!MsgMee.getSocket().hasListeners(MySocketEvents.EVENT_CALL_MEMBER_ADDED)) {
            MsgMee.getSocket()
                .on(MySocketEvents.EVENT_CALL_MEMBER_ADDED, MySocketEvents.callMemberAdded)
        }
    }

    private fun unregisterSocketEvents() {
        MsgMee.getSocket().off(MySocketEvents.EVENT_CALL_STATE_UPDATE)
        MsgMee.getSocket().off(MySocketEvents.EVENT_CALL_MEMBER_ADDED)
    }

    @Suppress("unused")
    @Subscribe
    fun callStateUpdated(callStateUpdateModel: CallStateUpdateModel) {
        runOnUiThread {
            if(callStateUpdateModel.newState == "ended" && Constants.isCurrentUser(callStateUpdateModel.memberId)) {
                showRemovedDialog()
                return@runOnUiThread
            }

            val removePerson = removeStateList.contains(callStateUpdateModel.newState)

            val updateIndex = inCallUserList.indexOfFirst {
                it.memberId == callStateUpdateModel.memberId
            }
            if (updateIndex != -1) {
                if (removePerson) {
                    inCallUserList.removeAt(updateIndex)
                } else {
                    inCallUserList[updateIndex].callState = callStateUpdateModel.newState
                }


                updateCallUI()
            }
        }
    }

    private fun showRemovedDialog() {
        val view = LayoutInflater.from(this).inflate(R.layout.call_removed_dialog, null)
        val dialog = AlertDialog.Builder(this, R.style.CustomAlertDialog).setView(view)
        val alertDialog = dialog.show()
        alertDialog.setCancelable(false)
        view.txt_info.text = getString(R.string.removed_you_from_)
        view.btn_ok.setText(R.string.ok)

        view.btn_ok.setOnClickListener {
            alertDialog.dismiss()
            finish()
        }

        freeResources()
    }

    private fun updateCallUI() {
        if (inCallUserList.size < 2) {
            // ending call
            finish()
        }

        if (isVideoCall) {
            if (inCallUserList.size < 3) {
                if (isGroupCall) {
                    enterOneToOneVideoCall()
                } else {
                    setupRemoteVideo()
                }
            } else {
                if (isGroupCall) {
                    groupVideoCallAdapter.notifyDataSetChanged()
                } else {
                    enterGroupCall()
                }
            }
        } else {
            startCallTimer()
            enterAudioCall()
        }
        isGroupCall = inCallUserList.size > 2
        updateCallListAdapter()
    }

    @Suppress("unused")
    @Subscribe
    fun callMemberAdded(callNewUserModel: CallNewUserModel) {
        runOnUiThread {
            inCallUserList.add(
                UserInCallModel(
                    0,
                    "calling",
                    callNewUserModel.member.fullName,
                    callNewUserModel.member.userId,
                    callNewUserModel.member.profileImageThumb,
                    "",
                    callNewUserModel.member.userName,
                    callNewUserModel.member.sequenceNo
                )
            )
            updateCallUI()
        }
    }

    private fun fetchCallData() {
        if (callRoomData == null) {
            callRoomData = JSONObject()
            callRoomData!!.put("callRoomId", callRoomId)
        }

        // emitting socket for on time response
        MsgMee.getSocket().emit(MySocketEvents.EVENT_CALL_DETAIL, callRoomData, Ack { ackData ->
            runOnUiThread {
                val data = ackData[0].toString()
                val tempList: ArrayList<UserInCallModel> =
                    Constants.myGson.fromJson(data, userInCallType)
                tempList.forEach {
                    inCallUserList.removeAll { data ->
                        data.memberId == it.memberId
                    }
                    inCallUserList.add(it)
                }

                isGroupCall = inCallUserList.size > 2
                processCallData()

                if (!isVideoCall)
                    startCallTimer()

                updateCallListAdapter()
            }
        })
    }

    private fun startCallTimer() {
        if (countDownTimer == null) {
            for (it in inCallUserList) {
                if (it.callState == "inCall" && !Constants.isCurrentUser(it.memberId)) {
                    isCallStarted = true
                    break
                }
            }

            if (isCallStarted) {
                // stopping call ringing tone
                exoplayer?.stop()

                val maxValue = Int.MAX_VALUE.toLong()
                countDownTimer = object : CountDownTimer(maxValue, 1000) {
                    override fun onTick(millisUntilFinished: Long) {
                        val time = (maxValue - millisUntilFinished) / 1000
                        val seconds = time % 60
                        val minutes = time / 60
                        val stringTime =
                            String.format(Locale.ENGLISH, "%02d:%02d", minutes, seconds)
                        txt_audio_call_duration.text = stringTime
                    }

                    override fun onFinish() {}
                }
                countDownTimer!!.start()
            }
        }
    }

    private fun initData() {
        MyNotificationBuilder.isInCall = true
        friendListVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            FriendListVM::class.java
        )
        callingVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            CallingVM::class.java
        )
        callingRepo = CallingRepo()

        // starting call ringing
        playCallOutgoingRingtone()

        cl_single_video_call.visibility = View.GONE
        rl_group_video_call.visibility = View.GONE
        view_group_video_call.visibility = View.GONE
        cl_audio_call.visibility = View.GONE
    }

    private fun playCallOutgoingRingtone() {
        val dataSpec =
            DataSpec(RawResourceDataSource.buildRawResourceUri(R.raw.outgoing_call_ringing))
        val rawResourceDataSource = RawResourceDataSource(this)
        try {
            rawResourceDataSource.open(dataSpec)
        } catch (e: RawResourceDataSourceException) {
            e.printStackTrace()
        }

        val factory: DataSource.Factory = DataSource.Factory { rawResourceDataSource }
        val mediaSource = ProgressiveMediaSource.Factory(factory)
            .createMediaSource(rawResourceDataSource.uri)
//        val dataSourceFactory = DefaultDataSourceFactory(
//            this,
//            Util.getUserAgent(this, "messenger")
//        )
//        val mediaSource = ProgressiveMediaSource.Factory(dataSourceFactory)
//            .createMediaSource(soundUri)
        exoplayer = ExoPlayerFactory.newSimpleInstance(
            this,
            DefaultRenderersFactory(this), DefaultTrackSelector(),
            DefaultLoadControl()
        )
        exoplayer!!.prepare(mediaSource)
        exoplayer!!.repeatMode = ExoPlayer.REPEAT_MODE_ONE
        exoplayer!!.playWhenReady = true
    }

    private fun observeData() {
        friendListVM.observeFriendList().observe(this, Observer { newList ->
            isLastPage = if (newList.rows.isEmpty()) {
                true
            } else {
                val tempList = ArrayList<String>()
                inCallUserList.forEach {
                    tempList.add(it.memberId)
                }
                newList.rows.forEach {
                    if(tempList.contains(it.id)) {
                        it.isInCall = true
                    }
                    if (!friendList.contains(it)) {
                        friendList.add(it)
                    }
                }
                if (!this::addCallAdapter.isInitialized) {
                    addCallAdapter = AddCallAdapter(friendList, ::addUserInCall)
                }
                addCallAdapter.notifyDataSetChanged()
                false
            }
            isLoading = false
        })

        callingVM.observeInitiateCall().observeForever {
            // fetching data from server and showing to user
            fetchCallData()
        }

        observeError()
    }

    private fun observeError() {
        friendListVM.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    showToast("Server Error")
                }
                else -> {
                }
            }
        })
        callingVM.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    showToast("Server Error")
                }
                else -> {
                }
            }
        })
    }

    private fun bindGroupRecycler() {
        groupVideoCallAdapter = GroupVideoCallAdapter(this, inCallUserList, rtcEngine!!)
        val flowLayoutManager = FlowLayoutManager()
        flowLayoutManager.isAutoMeasureEnabled = true
        flowLayoutManager.setAlignment(Alignment.LEFT)
        flowLayoutManager.maxItemsPerLine(2)
        rl_group_video_call.layoutManager = flowLayoutManager
        rl_group_video_call.adapter = groupVideoCallAdapter
        groupVideoCallAdapter.notifyDataSetChanged()

        // stopping scroll
        rl_group_video_call.addOnItemTouchListener(object :
            RecyclerView.SimpleOnItemTouchListener() {
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                if (rv.scrollState == RecyclerView.SCROLL_STATE_DRAGGING) {
                    // Stop  scrolling by touch
                    return false
                }
                return true
            }
        })

        view_group_video_call.setOnClickListener {
            openCallListBottomSheet()
        }
    }

    private fun setViewsClick() {
        cv_call_own_profile_outer.setOnClickListener(this)
        cv_call_profile_1_outer.setOnClickListener(this)
        cv_call_profile_2_outer.setOnClickListener(this)
        cv_call_profile_3_outer.setOnClickListener(this)
        cv_call_profile_4_outer.setOnClickListener(this)
        cv_call_profile_5_outer.setOnClickListener(this)
        cv_call_profile_6_outer.setOnClickListener(this)
        cv_call_profile_7_outer.setOnClickListener(this)

        img_call_add_person.setOnClickListener {
            fetchFriendList()
            openAddPeopleBottomSheet()
        }
        img_call_end.setOnClickListener {
            finish()
        }
        img_call_video.setOnClickListener {
            changeVideoStatus(img_call_video)
        }
        img_call_mic.setOnClickListener {
            changeMicStatus(img_call_mic)
        }
        cv_local_video.setOnTouchListener(touchListener)
    }

    private fun fetchFriendList(isRefresh: Boolean = true, searchText: String = "") {
        if (isRefresh)
            pageIndex = 0
        val body: HashMap<String, Any> = hashMapOf(
            "searchKey" to searchText,
            "pageIndex" to pageIndex,
            "pageSize" to Constants.globalPageSize,
        )

        friendListVM.fetchFriendList(body, isRefresh)
    }

    private fun changeVideoStatus(view: CustomIconView, isMain: Boolean = true) {
        isVideoEnable = !isVideoEnable
        if (isVideoEnable) {
            Glide.with(this).load(R.drawable.ic_enable_video).into(view)
            if(!isMain) {
                Glide.with(this).load(R.drawable.ic_enable_video).into(img_call_video)
            }
        } else {
            Glide.with(this).load(R.drawable.ic_disable_video).into(view)
            if(!isMain) {
                Glide.with(this).load(R.drawable.ic_disable_video).into(img_call_video)
            }
        }
        rtcEngine!!.muteLocalVideoStream(!isVideoEnable)
    }

    private fun changeMicStatus(view: CustomIconView, isMain: Boolean = true) {
        isMicEnable = !isMicEnable
        if (isMicEnable) {
            Glide.with(this).load(R.drawable.ic_enable_mic).into(view)
            if(!isMain) {
                Glide.with(this).load(R.drawable.ic_enable_mic).into(img_call_mic)
            }
        } else {
            Glide.with(this).load(R.drawable.ic_disable_mic).into(view)
            if(!isMain) {
                Glide.with(this).load(R.drawable.ic_disable_mic).into(img_call_mic)
            }
        }
        rtcEngine!!.muteLocalAudioStream(!isMicEnable)
    }

    private fun initAgora() {
        if (isOwner)
            callRoomId = "${Constants.userInfo!!.username}_${System.currentTimeMillis()}"

        initializeAgoraEngine()
        joinChannel()

        // adding current user in call list
        inCallUserList.add(
            UserInCallModel(
                0,
                "inCall",
                Constants.userInfo!!.fullName,
                Constants.userInfo!!.id,
                Constants.userInfo!!.profileImageThumb,
                "",
                Constants.userInfo!!.username
            )
        )
        if (isOwner) {
            startCall()
        } else {
            fetchCallData()
        }
    }

    private fun processCallData() {
        if (isVideoCall) {
            if (isGroupCall) {
                enterGroupCall()
            } else {
                enterOneToOneVideoCall()
            }
        } else {
            enterAudioCall()
        }
    }

    private fun startCall() {
        val bodyMap: HashMap<String, Any> = hashMapOf(
            "callRoomId" to callRoomId,
            "callMembers" to listOf(callTo!!.userId),
            "isVideo" to if (isVideoCall) 1 else 0
        )
        callingVM.initiateCall(bodyMap)

        // adding second person in call list
        inCallUserList.add(
            UserInCallModel(
                0,
                "calling",
                callTo!!.username,
                callTo!!.userId,
                callTo!!.profilePicture,
                "",
                callTo!!.username
            )
        )
        isGroupCall = inCallUserList.size > 2

        processCallData()
    }

    private fun enterAudioCall() {
        cl_single_video_call.visibility = View.GONE
        rl_group_video_call.visibility = View.GONE
        view_group_video_call.visibility = View.GONE
        cl_audio_call.visibility = View.VISIBLE
        val tempList = inCallUserList.filter {
            !Constants.isCurrentUser(it.memberId)
        }
        val availableUsersCount = tempList.size
        for (index in audioCallLayoutList.indices) {
            if (index < availableUsersCount) {
                audioCallLayoutList[index].visibility = View.VISIBLE

                // setting angle
                val params =
                    audioCallLayoutList[index].layoutParams as ConstraintLayout.LayoutParams
                val angle = ((360 / availableUsersCount) * index).toFloat()
                params.circleAngle = angle
                audioCallLayoutList[index].layoutParams = params

                for (view in audioCallLayoutList[index].children) {
                    if (view is CustomTextView) {
                        val data =
                            "${tempList[index].callState.callStatus()} ${tempList[index].userName}"
                        view.text = data
                    } else if (view is CustomImageView) {
                        Glide.with(this).load(tempList[index].profileImageThumb)
                            .placeholder(R.drawable.profile_placeholder).into(view)
                    }
                }
                Log.v("harshCalling", "angle for index $index == $angle")
            } else {
                audioCallLayoutList[index].visibility = View.GONE
            }
        }
    }

    private fun enterOneToOneVideoCall() {
        cl_single_video_call.visibility = View.VISIBLE
        rl_group_video_call.visibility = View.GONE
        view_group_video_call.visibility = View.GONE
        cl_audio_call.visibility = View.GONE
        setupLocalVideo()
        setupRemoteVideo()
    }

    private fun setupLocalVideo() {
        // Enable the video module.
        rtcEngine!!.enableVideo()

        val container = findViewById<FrameLayout>(R.id.fl_local_video)

        // Create a SurfaceView object.
        val surfaceView = RtcEngine.CreateRendererView(baseContext)
        surfaceView.setZOrderMediaOverlay(true)
        container.addView(surfaceView)
        rtcEngine!!.setupLocalVideo(
            VideoCanvas(
                surfaceView,
                VideoCanvas.RENDER_MODE_FIT,
                Constants.userInfo!!.userSequenceNo
            )
        )
    }

    private fun setupRemoteVideo() {
        val index = inCallUserList.indexOfFirst {
            it.memberId != Constants.userInfo!!.id
        }
        if (rtcEngine == null ||
            index == -1 ||
            removeStateList.contains(inCallUserList[index].callState) ||
            inCallUserList[index].uid == 0
        )
            return

        val container = findViewById<FrameLayout>(R.id.fl_remote_video)

        // Create a SurfaceView object.
        val surfaceView = RtcEngine.CreateRendererView(baseContext)
        container.addView(surfaceView)

        // Set the remote video view.
        rtcEngine!!.setupRemoteVideo(
            VideoCanvas(
                surfaceView,
                VideoCanvas.RENDER_MODE_FIT,
                inCallUserList[index].uid
            )
        )

        txt_single_video_state.visibility = if (inCallUserList[index].callState == "inCall") {
            View.GONE
        } else {
            txt_single_video_state.text = inCallUserList[index].callState
            View.VISIBLE
        }
    }

    private fun enterGroupCall() {
        rl_group_video_call.visibility = View.VISIBLE
        view_group_video_call.visibility = View.VISIBLE
        cl_single_video_call.visibility = View.GONE
        cl_audio_call.visibility = View.GONE

        if (!this@CallActivity::groupVideoCallAdapter.isInitialized) {
            bindGroupRecycler()
        } else {
            groupVideoCallAdapter.notifyItemInserted(inCallUserList.size - 1)
        }
    }

    private fun joinChannel() {
        rtcEngine!!.joinChannel(
            null,
            callRoomId,
            "Extra Optional Data",
            Constants.userInfo!!.userSequenceNo
        )
    }

    private fun initializeAgoraEngine() {
        try {
            rtcEngine =
                RtcEngine.create(baseContext, getString(R.string.agora_app_id), rtcEventHandler)
        } catch (e: Exception) {
            Log.v("harshCalling", Log.getStackTraceString(e))
            showToast()
            finish()
        }
    }

    override fun setInitialLanguage() {

    }

    override fun bindData() {
        img_call_video.visibility = if (isVideoCall) {
            View.VISIBLE
        } else {
            View.GONE
        }
        txt_audio_call.text = ""
        txt_audio_call_duration.text = ""
    }

    private val removeUserClicked = object : SingleItemCallback {
        override fun itemInteracted(position: Int) {
            val bodyMap: HashMap<String, Any> = hashMapOf(
                "callRoomId" to callRoomId,
                "memberId" to inCallUserList[position].memberId
            )
            callingRepo.removeUserFromCall(bodyMap)
            showToast("Removing ${inCallUserList[position].userName} from call")
            callListBottomSheet.dismiss()
        }
    }

    private fun openCallListBottomSheet() {
        val view = LayoutInflater.from(this).inflate(R.layout.call_list_bs, null)
        callListBottomSheet = BottomSheetDialog(this, R.style.SheetDialog)
        callListBottomSheet.setContentView(view)
        callListBottomSheet.behavior.state = BottomSheetBehavior.STATE_EXPANDED

        val rl_call_list = view.findViewById<RecyclerView>(R.id.rl_call_list)
        val img_call_video_bs = view.findViewById<CustomIconView>(R.id.img_call_video_bs)
        val img_call_end_bs = view.findViewById<CustomIconView>(R.id.img_call_end_bs)
        val img_call_mic_bs = view.findViewById<CustomIconView>(R.id.img_call_mic_bs)

        img_call_video_bs.visibility = if (isVideoCall) {
            if (isVideoEnable) {
                Glide.with(this).load(R.drawable.ic_enable_video).into(img_call_video_bs)
            } else {
                Glide.with(this).load(R.drawable.ic_disable_video).into(img_call_video_bs)
            }
            View.VISIBLE
        } else {
            View.GONE
        }
        if (isMicEnable) {
            Glide.with(this).load(R.drawable.ic_enable_mic).into(img_call_mic_bs)
        } else {
            Glide.with(this).load(R.drawable.ic_disable_mic).into(img_call_mic_bs)
        }

        img_call_mic_bs.setOnClickListener {
            changeMicStatus(img_call_mic_bs, isMain = false)
        }
        img_call_video_bs.setOnClickListener {
            changeVideoStatus(img_call_video_bs, isMain = false)
        }
        img_call_end_bs.setOnClickListener {
            callListBottomSheet.dismiss()
            finish()
        }

        activeCallAdapter = ActiveCallAdapter(inCallUserList, isOwner, removeUserClicked)
        rl_call_list.layoutManager = LinearLayoutManager(this)
        rl_call_list.adapter = activeCallAdapter
        activeCallAdapter!!.notifyDataSetChanged()
        callListBottomSheet.show()
    }

    private fun updateCallListAdapter() {
        if(activeCallAdapter != null && callListBottomSheet.isShowing) {
            activeCallAdapter!!.notifyDataSetChanged()
        }
    }

    private fun openAddPeopleBottomSheet() {
        if (!this::addCallAdapter.isInitialized) {
            addCallAdapter = AddCallAdapter(friendList, ::addUserInCall)
        }
        friendList.clear()

        val view = LayoutInflater.from(this).inflate(R.layout.select_profession_bs, null)
        peopleListBottomSheet = BottomSheetDialog(this, R.style.SheetDialog)
        peopleListBottomSheet.setContentView(view)
        peopleListBottomSheet.behavior.state = BottomSheetBehavior.STATE_EXPANDED

        val edt_search_profession = view.findViewById<CustomEditText>(R.id.edt_search_profession)
        val rl_list_profession = view.findViewById<RecyclerView>(R.id.rl_list_profession)

        edt_search_profession.hint = getString(R.string.search)

        val layoutManager = LinearLayoutManager(this)
        rl_list_profession.layoutManager = layoutManager
        rl_list_profession.adapter = addCallAdapter
        addCallAdapter.notifyDataSetChanged()
        peopleListBottomSheet.show()

        edt_search_profession.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                searchText = edt_search_profession.text.toString().trim()
                fetchFriendList(true, searchText)
                return@setOnEditorActionListener true
            }
            return@setOnEditorActionListener false
        }

        // for pagination
        rl_list_profession.addOnScrollListener(object : ScrollListener(layoutManager) {
            override fun isNewLastPage() = true
            override fun isOldLastPage() = isLastPage
            override fun isLoading() = isLoading
            override fun loadNewItems() {}

            override fun loadOldItems() {
                isLoading = true
                pageIndex++
                fetchFriendList(false, "")
            }
        })
    }

    override fun onClick(v: View?) {
        openCallListBottomSheet()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == VIDEO_CALL_CODE) {
            if (Constants.isPermissionGranted(this, VIDEO_CALL_REQUIRED_PERMISSIONS)) {
                initAgora()
            } else {
                Toast.makeText(
                    this,
                    "Camera and Audio permission is required for attending video call",
                    Toast.LENGTH_SHORT
                )
                    .show()
            }
        } else if (requestCode == AUDIO_CALL_CODE) {
            if (Constants.isPermissionGranted(this, AUDIO_CALL_REQUIRED_PERMISSIONS)) {
                initAgora()
            } else {
                Toast.makeText(
                    this,
                    "Audio permission is required for attending audio call",
                    Toast.LENGTH_SHORT
                )
                    .show()
            }
        }
    }

    private fun addUserInCall(index: Int) {
        val data = friendList[index]
        val bodyMap: HashMap<String, Any> = hashMapOf(
            "callRoomId" to callRoomId,
            "memberId" to data.id,
            "isVideo" to if (isVideoCall) 1 else 0,
            "member" to hashMapOf(
                "fullname" to data.fullName,
                "userName" to data.userName,
                "userId" to data.id,
                "profileImageThumb" to (data.profileImageThumb ?: ""),
                "sequenceNo" to data.userSequenceNo
            )
        )
        callingVM.addUserInCall(bodyMap)
        peopleListBottomSheet.dismiss()
    }

    private fun freeResources() {
        EventBus.getDefault().unregister(this)
        unregisterSocketEvents()

        updateCallState()

        rtcEngine?.leaveChannel()
        RtcEngine.destroy()
        rtcEngine = null

        MyNotificationBuilder.isInCall = false

        countDownTimer?.cancel()

        exoplayer?.stop()
        exoplayer?.release()
    }

    override fun onDestroy() {
        Log.v("harshCalling", "onDestroy == called")

        // updating call state
        freeResources()

        super.onDestroy()
    }

    private fun updateCallState() {
        val bodyMap: HashMap<String, Any> = hashMapOf(
            "callRoomId" to callRoomId,
            "callState" to "ended"
        )
        callingRepo.updateCallState(bodyMap)

        inCallUserList.forEach {
            if (!Constants.isCurrentUser(it.memberId) && (it.callState == "calling" || it.callState == "ringing")) {
                val body: HashMap<String, Any> = hashMapOf(
                    "callRoomId" to callRoomId,
                    "memberId" to it.memberId
                )
                callingRepo.addMissedCall(body)
            }
        }
    }

    private val touchListener = View.OnTouchListener { view: View, motionEvent: MotionEvent ->
        val x = (motionEvent.rawX).toInt()
        val y = (motionEvent.rawY).toInt()

        when (motionEvent.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val params = view.layoutParams as (ConstraintLayout.LayoutParams)
                // Where the user started the drag
                Log.v(
                    "harshDrag",
                    "ACTION_DOWN -> x == $x, y == $y, marginStart == ${params.marginStart}, topMargin == ${params.topMargin}"
                )
                xDelta = x - params.marginStart
                yDelta = y - params.topMargin
            }

            MotionEvent.ACTION_MOVE -> {
                val params = view.layoutParams as (ConstraintLayout.LayoutParams)
                Log.v(
                    "harshDrag",
                    "ACTION_MOVE -> x == $x, y == $y, marginStart == ${params.marginStart}, topMargin == ${params.topMargin}"
                )
                params.marginEnd = -(x - xDelta)
                params.topMargin = y - yDelta
                params.marginStart = 0
                params.bottomMargin = -250
                view.layoutParams = params
            }

            MotionEvent.ACTION_UP -> {
                Log.d("harshDrag", "ACTION_UP")
            }
        }
        rl_root.invalidate()
        view.performClick()
        return@OnTouchListener true
    }

    override fun onBackPressed() {
        if (isPipAvailable) {
            onPause()
        } else {
            super.onBackPressed()
        }
    }

    override fun onPause() {
        // entering in picture in picture mode
        if (isPipAvailable)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                enterPictureInPictureMode(PictureInPictureParams.Builder().build())
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                @Suppress("DEPRECATION")
                enterPictureInPictureMode()
            }
        super.onPause()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        Log.v("harshCalling", "onUserLeaveHint")
    }

    override fun onResume() {
        super.onResume()
        onStopCalled = false
    }

    override fun onStop() {
        super.onStop()
        onStopCalled = true
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        isInPip = isInPictureInPictureMode
        if (isInPip) {
            // Hide the full-screen UI (controls, etc.) while in picture-in-picture mode.
            Log.v("harshCalling", "pip started")
            cl_call_button.visibility = View.GONE
            img_call_add_person.visibility = View.GONE

            // changing height percentage to 0.8 and width percentage to 0.3
            val constraintSet = ConstraintSet()
            constraintSet.clone(cl_single_video_call)
            constraintSet.constrainPercentHeight(R.id.cv_local_video, 0.8f)
            constraintSet.constrainPercentWidth(R.id.cv_local_video, 0.3f)
            constraintSet.applyTo(cl_single_video_call)
        } else {
            // Restore the full-screen UI.
            Log.v("harshCalling", "pip end and full screen started")
            if (onStopCalled) {
                finish()
            } else {
                cl_call_button.visibility = View.VISIBLE
                img_call_add_person.visibility = View.VISIBLE

                // changing height percentage to 0.4 and width percentage to 0.5
                val constraintSet = ConstraintSet()
                constraintSet.clone(cl_single_video_call)
                constraintSet.constrainPercentHeight(R.id.cv_local_video, 0.4f)
                constraintSet.constrainPercentWidth(R.id.cv_local_video, 0.5f)
                constraintSet.applyTo(cl_single_video_call)
            }
        }
    }
}