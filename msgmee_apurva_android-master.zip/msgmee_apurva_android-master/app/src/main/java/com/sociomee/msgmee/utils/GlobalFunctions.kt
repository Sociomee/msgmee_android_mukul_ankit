package com.sociomee.msgmee.utils

import android.content.Context
import android.net.wifi.WifiManager
import android.provider.Settings
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder

fun getIpAddress(applicationContext: Context): String? {
    val wifiManager = applicationContext.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    val wifiInfo = wifiManager.connectionInfo
    val ipInt = wifiInfo.ipAddress
    return InetAddress.getByAddress(
            ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(ipInt).array()).hostAddress
}

fun getDeviceID(context: Context): String? {
     return Settings.Secure.getString(context.contentResolver,
            Settings.Secure.ANDROID_ID)
}

fun getDeviceInformation(context: Context) {
    return HashMap<String, String>().let {
        it["OS"] = System.getProperty("os.version") ?: ""
        it["SDK"] = android.os.Build.VERSION.SDK
        it["DEVICE"] = android.os.Build.DEVICE
        it["MODEL"] = android.os.Build.MODEL
        it["PRODUCT"] = android.os.Build.PRODUCT
    }
}