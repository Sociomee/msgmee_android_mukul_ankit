package com.sociomee.msgmee.ui.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.huawei.multimedia.audiokit.utils.Constant

import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.`interface`.LanguageSelectCallback
import com.sociomee.msgmee.ui.activity.LoginActivity
import com.sociomee.msgmee.ui.activity.SignUpActivity
import com.sociomee.msgmee.ui.adapter.ChooseLanguageAdapter
import com.sociomee.msgmee.ui.adapter.CountrySpinnerAdaptor
import com.sociomee.msgmee.ui.data.AuthModel
import com.sociomee.msgmee.ui.data.CountryDataModel
import com.sociomee.msgmee.ui.data.SocialLoginData
import com.sociomee.msgmee.ui.model.LanguageList
import com.sociomee.msgmee.ui.viewmodel.AuthSharedViewModel
import com.sociomee.msgmee.ui.viewmodel.CountryListVM
import com.sociomee.msgmee.ui.viewmodel.LanguageViewModel
import com.sociomee.msgmee.ui.viewmodel.RegisterViewModel
import com.sociomee.msgmee.utils.*
import kotlinx.android.synthetic.main.user_contact_detail_fragment.*
import kotlinx.android.synthetic.main.user_contact_detail_fragment.countryCodeSpinner
import kotlinx.android.synthetic.main.user_contact_detail_fragment.ll_language
import kotlinx.android.synthetic.main.user_contact_detail_fragment.txt_apple
import kotlinx.android.synthetic.main.user_contact_detail_fragment.txt_choose_your_
import kotlinx.android.synthetic.main.user_contact_detail_fragment.txt_language
import kotlinx.android.synthetic.main.user_contact_detail_fragment.txt_login
import kotlinx.android.synthetic.main.user_contact_detail_fragment.txt_or

const val GOOGLE_SIGNUP = 11

class UserContactDetailFragment : Fragment(R.layout.user_contact_detail_fragment),
        LanguageSelectCallback {


    private lateinit var languageViewModel: LanguageViewModel
    var languageList = ArrayList<LanguageList>()
    lateinit var authSharedViewModel: AuthSharedViewModel
    lateinit var selectedLanguage: LanguageList
    lateinit var chooseLanguageAdapter: ChooseLanguageAdapter
    lateinit var dialog: BottomSheetDialog
    private lateinit var registerViewModel: RegisterViewModel
    var enteredRegisterDetail = ""
    var number="";
    var isEmail = true
    var signUpType = ""
    private lateinit var gso: GoogleSignInOptions
    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var googleAccountData: GoogleSignInAccount
    private lateinit var socialLoginData: SocialLoginData
    private lateinit var countryAdapter: CountrySpinnerAdaptor
    private var selectedCountry: CountryDataModel? = null
    private var countryList = ArrayList<CountryDataModel>()
    private lateinit var countryListVM: CountryListVM
    private var languageId = ""

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setLanguageData()

        initData()
        observeData()
        setViewsClick()
        setupGoogleSignIn()
    }

    private fun setupGoogleSignIn() {
        gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestIdToken(getString(R.string.default_web_client_id))
                .build()
        googleSignInClient = GoogleSignIn.getClient(context!!, gso)
    }

    private fun initData() {
        authSharedViewModel = ViewModelProvider(requireActivity(),
                ViewModelProvider.NewInstanceFactory()).get(
                AuthSharedViewModel::class.java
        )
        languageViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
                LanguageViewModel::class.java)
        registerViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
                RegisterViewModel::class.java)
        countryListVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
                CountryListVM::class.java)

        languageList = ArrayList()
        chooseLanguageAdapter = ChooseLanguageAdapter(languageList, this)
        languageViewModel.getLanguageList()
        countryListVM.getCountryList()
    }

    private fun showLanguageBottomDialog() {
        val view = LayoutInflater.from(context!!)
                .inflate(R.layout.choose_language_bottom_sheet, null)
        dialog = BottomSheetDialog(context!!, R.style.SheetDialog)
        dialog.setContentView(view)
        val recyclerView = view.findViewById<RecyclerView>(R.id.rv_choose_language)
        val manager = LinearLayoutManager(context!!)
        recyclerView.layoutManager = manager
        recyclerView.adapter = chooseLanguageAdapter
        dialog.show()
        recyclerView.addItemDecoration(DividerItemDecoration(context!!, manager.orientation))
    }

    private fun setLanguageData() {
        txt_my_contact.text = getString(R.string.my_contact)
        txt_choose_your_.text = getString(R.string.choose_your_)
        ed_new_password.hint = getString(R.string.email_id_)
        txt_when_you_.text = getString(R.string.when_you_)
        txt_already_have_.text = getString(R.string.already_have_)
        txt_login.text = getString(R.string.login)
        txt_or.text = getString(R.string.or)
        btn_continue.text = getString(R.string.continue_btn)
        txt_login_id.text = getString(R.string.continue_with_google)
        txt_apple.text = getString(R.string.continue_with_apple)
        txt_language.text = getString(R.string.choose_language)
    }

    private fun observeData() {
        languageViewModel.observeLanguageList().observe(this, Observer {
            languageList.addAll(it)
        })
        registerViewModel.observeLoading().observe(this, Observer {
            (activity as CustomAppCompatActivity).changeLoadingStatus(it!!)
        })
//        languageViewModel.observeLanguageList().observe(this, Observer {
//            languageList.addAll(it)
//        })
//        registerViewModel.observeLoading().observe(this, Observer {
//            (activity as CustomAppCompatActivity).changeLoadingStatus(it!!)
//        })
        registerViewModel.observeLoginIdAvailability().observe(this, Observer {
            if (!it) {
                txt_error.visibility = View.VISIBLE
                if (isEmail) {
                    txt_error.text = getString(R.string.email_address_already_exists)
                } else {
                    txt_error.text = getString(R.string.mobile_number_already_exists)
                }
            } else {
                txt_error.visibility = View.GONE

                if (signUpType == "password") {
                    // now sending otp
                    val bodyMap = HashMap<String, Any>().apply {
                        put("isEmail", isEmail)
                        put("type", AuthenticationUtil.OtpType.SIGNUP.type)
                        if (isEmail) {
                            put("email", enteredRegisterDetail)
                        } else {
                            put("email", "")
                            put("mobile", "+91 "+number)
                        }
                    }
                    registerViewModel.sendOtp(bodyMap)
                } else {
                    (activity as SignUpActivity).changeFragment(
                            AuthenticationUtil.SignupFragmentType.CREDENTIAL, "otpFragment")
                    authSharedViewModel.saveAuth(
                            AuthModel(isEmail, enteredRegisterDetail, signUpType,
                                    socialLoginData = this.socialLoginData))
                }

            }
        })
        registerViewModel.observeOtpSent().observe(this, Observer {
            if (!it) {
                txt_error.visibility = View.VISIBLE
                txt_error.text = getString(R.string.something_went_wrong_)
            } else {
                (activity as SignUpActivity).changeFragment(
                        AuthenticationUtil.SignupFragmentType.OTP, "otpFragment")
if(isEmail){
    authSharedViewModel.saveAuth(AuthModel(isEmail, enteredRegisterDetail, signUpType))
}
                else {
    authSharedViewModel.saveAuth(AuthModel(isEmail, "+91 "+number, signUpType))
                }
//                authSharedViewModel.saveAuth(AuthModel(isEmail, enteredRegisterDetail, signUpType))
            }
        })
        countryListVM.observeCountryList().observe(this, Observer {
            countryList.addAll(it)

            countryAdapter = CountrySpinnerAdaptor(countryList)
            countryCodeSpinner.adapter = countryAdapter
            selectedCountry = countryList[0]
        })

        // observing errors
        observeError()
    }

    private fun observeError() {
        registerViewModel.observeError().observe(this, Observer {
            handleError(it)
        })

        languageViewModel.observeError().observe(this, Observer {
            handleError(it)
        })
        countryListVM.observeError().observe(this, Observer {
            handleError(it)
        })
    }

    private fun handleError(status: ResponseStatus) {
        when (status) {
            ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                (activity as CustomAppCompatActivity).showToast("Internet not available")
            }
            ResponseStatus.AUTH_ERROR -> {
                (activity as CustomAppCompatActivity).showToast("Auth Error")
            }
            ResponseStatus.SERVER_ERROR -> {
                (activity as CustomAppCompatActivity).showToast("Server Error")
            }
            else -> {
            }
        }
    }

    override fun languageSelectCallback(index: Int) {

        selectedLanguage = languageList[index]

        txt_language.text = selectedLanguage.name
        languageId = selectedLanguage.id
        MyPreferences.saveStringInPreference(context!!, Constants.languageId, selectedLanguage.id)
        dialog.dismiss()
    }

    private fun setViewsClick() {
        btn_continue.setOnClickListener {

            enteredRegisterDetail = et_email_num.text.toString()
            number = et_email_num.text.toString()
            if (languageId.isEmpty()){
                txt_error.visibility = View.VISIBLE
                txt_error.text = getString(R.string.choose_language)
            }else {

                when {
                    enteredRegisterDetail.isValidEmail() -> {
                        txt_error.visibility = View.GONE
                        isEmail = true
                        signUpType = "password"
                        registerViewModel.checkEmailAvailability(
                                hashMapOf("email" to enteredRegisterDetail))
                    }
                    enteredRegisterDetail.isValidMobile() -> {
                        // concatenating country code

                        val countryCode = selectedCountry?.code ?: "+91"
                        enteredRegisterDetail = "$countryCode $enteredRegisterDetail"

                        txt_error.visibility = View.GONE
                        isEmail = false
                        signUpType = "password"
                        registerViewModel.checkMobileAvailability(
                                hashMapOf("mobile" to enteredRegisterDetail))
                    }
                    else -> {
                        txt_error.visibility = View.VISIBLE
                        txt_error.text = getString(R.string.please_enter_valid_)
                    }
                }
            }

        }

        ll_language.setOnClickListener {
            showLanguageBottomDialog()
        }

        txt_login.setOnClickListener {
            startActivity(Intent(context!!, LoginActivity::class.java))
            activity!!.finish()
        }

        img_toolbar_back.setOnClickListener {
            (activity as SignUpActivity).onBackPress()
        }
        card_google.setOnClickListener {
            signUpType = "google"
            val signInIntent: Intent = googleSignInClient.signInIntent
            startActivityForResult(signInIntent, GOOGLE_SIGNUP)
        }
        card_apple.setOnClickListener {
            signUpType = "apple"
        }
        countryCodeSpinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                selectedCountry = countryList[position]
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {}
        }
    }

    private fun handleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account = completedTask.getResult(ApiException::class.java)
            if (account == null) {
                (activity as CustomAppCompatActivity).showToast(
                        getString(R.string.something_went_wrong_))
                return
            }
            googleAccountData = account
            isEmail = true
            enteredRegisterDetail = account.email.toString()
            socialLoginData = SocialLoginData(account.displayName.toString(),
                    account.photoUrl.toString())
            registerViewModel.checkEmailAvailability(
                    hashMapOf("email" to enteredRegisterDetail))
        } catch (e: ApiException) {
            Log.e("harsh", "signInResult:failed code=" + e.statusCode)
            (activity as CustomAppCompatActivity).showToast(
                    getString(R.string.something_went_wrong_))
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == GOOGLE_SIGNUP) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            handleSignInResult(task)
        }
    }
}