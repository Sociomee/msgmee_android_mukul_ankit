package com.sociomee.msgmee.ui.model

import com.google.gson.annotations.SerializedName
import com.sociomee.msgmee.utils.Constants

data class ChatDataModel(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("successResult")
        val chatModel: ArrayList<ChatModel>
    )
}

data class ChatModel(
    @SerializedName("chatHeadId")
    var chatHeadId: String,
    @SerializedName("deletedByUserId")
    val deletedByUserId: String,
    @SerializedName("deletedByUserName")
    val deletedByUserName: String?,
    @SerializedName("messageId")
    val messageId: String,
    @SerializedName("senderUserName")
    val senderUsername: String,
    @SerializedName("senderProfileThumb")
    val senderProfileThumb: String?,
    @SerializedName("createdAt")
    val createdAt: String,
    @SerializedName("messageJson")
    val messageJson: MessageJson?,
    @SerializedName("messageText")
    val messageText: String,
    @SerializedName("messageType")
    val messageType: String,
    @SerializedName("readCount")
    val readCount: Int,
    @SerializedName("isRead")
    val isRead: Int,
    @SerializedName("senderUserId")
    val senderUserId: String,
    @SerializedName("sequenceNo")
    val messageSequenceNo: Int,
    @SerializedName("isDeletedForAll")
    var isDeletedForAll: Int,
    @SerializedName("isForwarded")
    var isForwarded: Int = 0,
    var messageEnumType: Constants.MessageType,
    var isMyMessage: Boolean = true,
    var isOneToOne: Boolean = true,
    var isSelected: Boolean = false,
    var playMedia: Boolean = false,
    var isDownloading: Boolean = false
) : Comparable<ChatModel> {
    data class MessageJson(
        @SerializedName("addedByUserId")
        val addedByUserId: String,
        @SerializedName("addedByUserName")
        val addedByUserName: String,
        @SerializedName("addedUserId")
        val addedUserId: String,
        @SerializedName("addedUserName")
        val addedUserName: String,
        @SerializedName("removedUserId")
        val removedUserId: String,
        @SerializedName("removedByUserId")
        val removedByUserId: String,
        @SerializedName("removedUserName")
        val removedUserName: String,
        @SerializedName("removedByUserName")
        val removedByUserName: String,
        @SerializedName("leftUserId")
        val leftUserId: String,
        @SerializedName("leftUserName")
        val leftUserName: String,
        @SerializedName("createdByUserId")
        val createdByUserId: String,
        @SerializedName("createdByUserName")
        val createdByUserName: String,
        @SerializedName("type")
        val type: String?,
        @SerializedName("mediaUrl")
        val mediaUrl: String?,
        @SerializedName("contactName")
        val contactName: String,
        @SerializedName("contactNumber")
        val contactNumber: String,
        @SerializedName("mediaDuration")
        val mediaDuration: String?,
        @SerializedName("mediaSize")
        val mediaSize: String?,
        @SerializedName("mediaName")
        val mediaName: String?,
        @SerializedName("replyMessageText")
        val replyMessageText: String?,
        @SerializedName("replyMessageUsername")
        val replyMessageUsername: String?,
        @SerializedName("replyMessageId")
        val replyMessageId: String?,
        @SerializedName("replyMessageSequence")
        val replyMessageSequence: Int,
        @SerializedName("replyMediaUrl")
        val replyMediaUrl: String?
    )

    override fun compareTo(other: ChatModel) = this.chatHeadId.compareTo(other.chatHeadId)

    companion object {
        fun createUnreadMessage(chatHeadId: String, messageType: String): ChatModel {
            return ChatModel(
                chatHeadId,
                "",
                "",
                "",
                "",
                "",
                "",
                null,
                "",
                messageType,
                0,
                1,
                "",
                0,
                0,
                0,
                Constants.MessageType.UNREAD_BUBBLE,
            )
        }
    }

}