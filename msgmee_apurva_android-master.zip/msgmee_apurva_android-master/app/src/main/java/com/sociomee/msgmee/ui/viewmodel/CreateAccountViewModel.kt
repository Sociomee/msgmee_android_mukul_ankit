package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.ui.data.CreateAccountModel
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.repo.CreateAccountRepo

class CreateAccountViewModel : MyViewModel() {

    private val createData = MutableLiveData<CreateAccountModel>()
    private lateinit var createAccountRepo: CreateAccountRepo

    // returning LiveData
    fun observeCreateAccountData() = createData

    fun createAccount(body: HashMap<String, Any>) {
        if(!this::createAccountRepo.isInitialized) {
            createAccountRepo = CreateAccountRepo()
        }
        isLoading.value = true
        createAccountRepo.createAccount(body).observeForever {
            if(it.status == ResponseStatus.SUCCESS) {
                createData.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

}