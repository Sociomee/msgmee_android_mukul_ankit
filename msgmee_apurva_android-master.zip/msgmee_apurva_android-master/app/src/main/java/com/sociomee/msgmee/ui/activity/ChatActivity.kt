package com.sociomee.msgmee.ui.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.ColorStateList
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.widget.ImageViewCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.google.android.exoplayer2.*
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory
import com.google.android.exoplayer2.util.Util
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.gson.Gson
import com.luck.picture.lib.PictureSelector
import com.luck.picture.lib.config.PictureConfig
import com.luck.picture.lib.entity.LocalMedia
import com.luck.picture.lib.instagram.InsGallery
import com.sociomee.msgmee.BuildConfig
import com.sociomee.msgmee.MsgMee
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.imagePicker.GlideCacheEngine
import com.sociomee.msgmee.imagePicker.GlideEngine
import com.sociomee.msgmee.notification.MyNotificationBuilder
import com.sociomee.msgmee.ui.`interface`.MultiSelectCallBack
import com.sociomee.msgmee.ui.`interface`.SingleItemCallback
import com.sociomee.msgmee.ui.adapter.ChatAdapter
import com.sociomee.msgmee.ui.adapter.ReportAdapter
import com.sociomee.msgmee.ui.model.*
import com.sociomee.msgmee.ui.viewmodel.ChatVM
import com.sociomee.msgmee.ui.viewmodel.MediaUploadVM
import com.sociomee.msgmee.ui.viewmodel.ReportVM
import com.sociomee.msgmee.utils.*
import kotlinx.android.synthetic.main.chat_activity.*
import kotlinx.android.synthetic.main.report_bottom_sheet.view.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.json.JSONObject
import java.io.File
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap
import androidx.lifecycle.Observer

@SuppressLint("InflateParams")
class ChatActivity : CustomAppCompatActivity(), MultiSelectCallBack, SingleItemCallback {

    // ViewModels
    private lateinit var chatVM: ChatVM
    private lateinit var mediaUploadVM: MediaUploadVM
    private lateinit var reportVM: ReportVM

    // Handlers
    private var typingHandler: Handler? = null
    private var typingEndHandler: Handler? = null
    private var mediaPlayHandler: Handler? = null
    private var audioRecordTimerHandler: Handler? = null
    private var removeUnreadHandler: Handler? = null

    // Lists
    private val messageList = ArrayList<ChatModel>()
    private val searchMessageList = ArrayList<SearchMessageData>()
    private var selectedMessageList = ArrayList<Int>()
    private var mediaList: MutableList<LocalMedia> = ArrayList()
    private var pendingMediaList = ArrayList<MediaPreviewModel>()
    private var pendingContactList = ArrayList<ContactModel>()
    private val reportList = ArrayList<ReportList>()
    private var pendingDownloadList = ArrayList<FileDownloadModel>()
    private val CAMERA_REQUIRED_PERMISSIONS = arrayOf(
        "android.permission.CAMERA"
    )
    private val AUDIO_RECORD_REQUIRED_PERMISSIONS = arrayOf(
        "android.permission.RECORD_AUDIO"
    )
    private val STORAGE_REQUIRED_PERMISSIONS = arrayOf(
        "android.permission.READ_EXTERNAL_STORAGE",
        "android.permission.WRITE_EXTERNAL_STORAGE"
    )

    // Booleans
    private var isKeyboardOpen = false
    private var showFab = false
    private var multiSelectOpen = false
    private var isReplyShowing = false
    private var isChatRestricted = false
    private var isNewLastPage = true
    private var isOldLastPage = false
    private var isLoading = false
    private var currentlyDownloading = false
    private var showSearchBar = false
    private var isRecordingAudio = false
    private var isAudioSeekingRequired = false

    // Integers, Floats
    private val AUDIO_RECORD_REQUEST_PERMISSIONS = 11
    private val CAMERA_REQUEST_PERMISSIONS = 101
    private val STORAGE_REQUEST_PERMISSIONS = 1001
    private val OPEN_GROUP_INFO_CODE = 100
    private val CAMERA_REQUEST = 102
    private val FORWARD_MESSAGE = 1021
    private var multiSelectCount = 0
    private val selectAudioCode = 10
    private val selectDocCode = 11
    private var unreadIndex = -1
    private val selectedMediaPreview = 12
    private val selectContactCode = 13
    private var searchResultTotal = 0
    private var currentSearchIndex = 0
    private var searchArrowAlpha = 0.3f
    private var audioRecordSec = 0
    private var typingDelay: Long = 600 // 600 milliseconds

    // Strings
    private lateinit var capturedPhotoPath: String
    var searchText: String = ""
    private lateinit var recordingAudioPath: String

    // Adapters
    private lateinit var chatAdapter: ChatAdapter
    private lateinit var reportAdapter: ReportAdapter

    // Models
    private lateinit var oldMediaPlayModel: MediaPlayModel
    private var chatHeadInfoModel: ChatHeadInfoModel? = null
    private lateinit var chatHeadIntentData: ChatHeadInfo
    private lateinit var replyModel: ChatModel
    private lateinit var messageReplyModel: MessageReplyModel

    // Generic variables
    private var typingData: JSONObject? = null

    private lateinit var reportListBottomSheetDialog: BottomSheetDialog
    private var mediaRecorder: MediaRecorder? = null
    var exoplayer: SimpleExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.chat_activity)

        chatHeadIntentData =
            Gson().fromJson(intent!!.extras!!.getString("chatHeadData"), ChatHeadInfo::class.java)

        initData()
        bindData()
        addKeyboardListener()
        observeData()
        setViewsClick()

        // registering to event bus
        EventBus.getDefault().register(this)
    }

    private fun initData() {
        chatVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            ChatVM::class.java
        )
        mediaUploadVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            MediaUploadVM::class.java
        )
        reportVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            ReportVM::class.java
        )
        chatAdapter = ChatAdapter(messageList, this)
    }

    private fun observeData() {
        chatVM.observeLoading().observe(this, Observer {
            changeLoadingStatus(it)
        })
        chatVM.observeChatHeadData().observe(this, Observer {
            chatHeadInfoModel = it
            MyNotificationBuilder.openedChatHeadId = chatHeadInfoModel!!.chatHeadId
            hideBlockedItem()
            bindNameAndProfile(chatHeadInfoModel!!.chatName(), chatHeadInfoModel!!.chatProfile())
            txt_online_status.text = chatHeadInfoModel.onlineText(this)
        })
        chatVM.observeMessageList().observe(this, Observer { newMessageData ->
            newMessageData.messageList.defineMessageEnum(chatHeadIntentData.chatHeadType)

            if (newMessageData.messageList.isEmpty()) {
                when (newMessageData.chatFetchType) {
                    Constants.ChatFetchType.NEW_MESSAGE -> {
                        isNewLastPage = true
                    }
                    Constants.ChatFetchType.OLD_MESSAGE -> {
                        isOldLastPage = true
                    }
                    Constants.ChatFetchType.SEARCH_MESSAGE, Constants.ChatFetchType.REPLY_MESSAGE_CLICK -> {
                        isOldLastPage = true
                        isNewLastPage = true
                    }
                }
            } else {
                if (newMessageData.chatFetchType == Constants.ChatFetchType.SEARCH_MESSAGE ||
                    newMessageData.chatFetchType == Constants.ChatFetchType.REPLY_MESSAGE_CLICK
                ) {
                    messageList.clear()
                    messageList.addAll(newMessageData.messageList)

                    // sorting by sequence number
                    messageList.sortByDescending {
                        it.messageSequenceNo
                    }
                    chatAdapter.notifyDataSetChanged()

                    if (newMessageData.chatFetchType == Constants.ChatFetchType.SEARCH_MESSAGE) {
                        val searchMessageIndex = messageList.indexOfFirst {
                            searchMessageList[currentSearchIndex].messageId == it.messageId
                        }
                        if (searchMessageIndex != -1)
                            searchScrollTo(searchMessageIndex)
                    } else {
                        val replyIndex = messageList.indexOfFirst {
                            messageReplyModel.replyMessageId == it.messageId
                        }
                        if (replyIndex != -1)
                            rl_chat.smoothScrollToPosition(replyIndex)
                    }

                    isOldLastPage = false
                    isNewLastPage = false
                } else {
                    messageList.addAll(newMessageData.messageList)

                    // sorting by sequence number
                    messageList.sortByDescending {
                        it.messageSequenceNo
                    }

                    // adding unread bubble and scrolling to that position
                    unreadIndex = messageList.indexOfLast {
                        it.readCount == 0 && !it.isMyMessage
                    }
                    val isUnreadMessage = unreadIndex != -1 && unreadIndex != messageList.size - 1

                    Log.v("harshChat", "unreadIndex == $unreadIndex")

                    if (isUnreadMessage) {
                        messageList.add(
                            unreadIndex + 1, ChatModel.createUnreadMessage(
                                chatHeadIntentData.chatHeadId!!,
                                "unreadMessage"
                            )
                        )
                    }
                    chatAdapter.notifyDataSetChanged()
                    if (isUnreadMessage) {
                        rl_chat.scrollToPosition(unreadIndex)

                        if (removeUnreadHandler == null) {
                            removeUnreadHandler = Handler(Looper.myLooper()!!)
                        }
                        removeUnreadHandler!!.postDelayed(removeUnreadRunnable, 10000)
                    }
                }
                Log.v("harshChat", "messageList size == ${messageList.size}")
            }
            if (newMessageData.chatFetchType == Constants.ChatFetchType.NEW_MESSAGE) {
                // hiding bottom progress bar
                changeMessageProgressVisibility(Constants.MessageProgressChange.HIDE_NEW)
            } else if (newMessageData.chatFetchType == Constants.ChatFetchType.OLD_MESSAGE) {
                // hiding top progress bar
                changeMessageProgressVisibility(Constants.MessageProgressChange.HIDE_OLD)
            }
            isLoading = false
        })
        chatVM.observeChatHeadClear().observe(this, Observer {
            if (it) {
                messageList.clear()
                chatAdapter.notifyDataSetChanged()
            } else {
                showToast()
            }
        })
        chatVM.observeDeleteForAll().observe(this, Observer {
            if (!it) {
                showToast()
            }
        })
        chatVM.observeDeleteForMe().observe(this, Observer {
            if (it.isSuccess) {
                it.messageIndexList!!.forEach { removeIndex ->
                    messageList.removeAt(removeIndex)
                    chatAdapter.notifyItemRemoved(removeIndex)
                }
            } else {
                showToast()
            }
        })
        chatVM.observeMessageSending().observe(this, Observer {
            if (it == null) {
                showToast()
            } else {
                // if there is any pending media message then sending it
                if (pendingMediaList.size > 0) {
                    mediaUploadVM.uploadPathMedia(
                        listOf(
                            MediaModel(
                                pendingMediaList[0].mediaPath,
                                pendingMediaList[0].mediaType
                            )
                        ),
                        Constants.messageMediaUploadKey
                    )
                }

                // if there is any pending contact message then sending it
                if (pendingContactList.size > 0)
                    sendContactMessage()

                // checking if chat head is null then fetching data
                if (chatHeadIntentData.chatHeadId == null) {
                    chatHeadIntentData.chatHeadId = it
                    fetchInitialData()
                    img_options_menu.visibility = View.VISIBLE
                }
            }
        })
        chatVM.observeSearchMessages().observe(this, Observer {
            searchMessageList.clear()
            searchMessageList.addAll(it.searchList)

            // starting search
            txt_search_count.visibility = View.VISIBLE
            pb_search.visibility = View.GONE

            searchResultTotal = searchMessageList.size
            txt_search_count.text = searchResultTotal.toString()

            currentSearchIndex = 0

            if (searchMessageList.isNotEmpty()) {
                searchMessageList.sortByDescending { model ->
                    model.sequenceNo
                }

                processSearch()
            }
        })
        chatVM.observeForwardMessages().observe(this, Observer {
            if (it) {
                showToast("Messages forwarded successfully")
            } else {
                showToast()
            }
        })
        reportVM.observeReportUser().observe(this, Observer {
            if (it) {
                showToast("Reported chat successfully")
            } else {
                showToast()
            }
        })
        reportVM.observeUserReportList().observe(this, Observer {
            reportList.clear()
            reportList.addAll(it)
            reportAdapter.notifyDataSetChanged()
        })

        // observing media upload
        mediaUploadVM.observeMediaUpload().observe(this, Observer {
            if (it[0].mediaType == Constants.SelectedMediaType.CONTACT) {
                processContactMessage(it[0].mediaPath)
            } else {
                processMediaMessage(it[0])
            }
        })

        if (chatHeadIntentData.chatHeadId != null) {
            fetchInitialData()
        }

        observeError()
    }

    private fun processSearch() {
        val searchMessageIndex = messageList.indexOfFirst {
            searchMessageList[currentSearchIndex].messageId == it.messageId
        }
        if (searchMessageIndex == -1) {
            // showing loading
            txt_search_count.visibility = View.INVISIBLE
            pb_search.visibility = View.VISIBLE
            fetchMessages(
                searchMessageList[currentSearchIndex].sequenceNo.toString(),
                Constants.ChatFetchType.SEARCH_MESSAGE
            )
        } else {
            searchScrollTo(searchMessageIndex)
        }

        img_search_down.alpha = if (currentSearchIndex == 0) {
            searchArrowAlpha
        } else {
            1.0f
        }

        img_search_up.alpha = if (currentSearchIndex == searchResultTotal - 1) {
            searchArrowAlpha
        } else {
            1.0f
        }
    }

    private fun searchScrollTo(position: Int) {
        chatAdapter.notifyItemChanged(position)
        txt_search_count.visibility = View.VISIBLE
        pb_search.visibility = View.GONE
        rl_chat.smoothScrollToPosition(position)
        val searchCountText = "${currentSearchIndex + 1}/$searchResultTotal"
        txt_search_count.text = searchCountText
    }

    private val removeUnreadRunnable = Runnable {
        // removing unread message bubble
        val index = messageList.indexOfFirst {
            it.messageEnumType == Constants.MessageType.UNREAD_BUBBLE
        }
        if(index != -1) {
            messageList.removeAt(index)
            chatAdapter.notifyItemRemoved(index)
        }
    }

    private fun processMediaMessage(mediaModel: MediaModel) {
        var mediaType = mediaModel.mediaType.name.toLowerCase(Locale.ENGLISH)
        val messageJson: HashMap<String, Any?>? = hashMapOf(
            "type" to mediaType,
            "mediaUrl" to mediaModel.mediaPath
        )

        val messageText = when (mediaModel.mediaType) {
            Constants.SelectedMediaType.AUDIO -> {
                messageJson!!["mediaName"] = mediaModel.mediaUri.getName(this)
                messageJson["mediaDuration"] = mediaModel.mediaUri.getDuration(this)
                messageJson["mediaSize"] = mediaModel.mediaUri.getSize(this)
                ""
            }
            Constants.SelectedMediaType.DOC -> {
                messageJson!!["mediaName"] = mediaModel.mediaUri.getName(this)
                messageJson["mediaSize"] = mediaModel.mediaUri.getSize(this)
                mediaType = "document"
                ""
            }
            else -> {
                // removing currently sent message
                if (pendingMediaList.size > 0) {
                    val message = pendingMediaList[0].mediaMessage
                    pendingMediaList.removeAt(0)
                    message
                } else {
                    ""
                }
            }
        }
        sendMessage(
            mediaType,
            messageText,
            messageJson
        )
    }

    private fun processContactMessage(mediaPath: String?) {
        val messageJson: HashMap<String, Any?> = hashMapOf(
            "type" to "contact",
            "mediaUrl" to mediaPath,
            "contactName" to pendingContactList[0].contactName,
            "contactNumber" to pendingContactList[0].contactNumber
        )
        sendMessage(
            "contact",
            "",
            messageJson
        )

        // removing currently sent message
        pendingContactList.removeAt(0)
    }

    private fun fetchInitialData() {
        // fetching messages
        fetchMessages(null, Constants.ChatFetchType.NEW_MESSAGE, isFirstFetch = true)

        // fetching chatHeadInfo
        val bodyMap: HashMap<String, Any> = hashMapOf(
            "chatHeadId" to chatHeadIntentData.chatHeadId!!
        )
        chatVM.getChatHeadById(bodyMap)
    }

    private fun fetchMessages(
        messageSequence: String?,
        chatFetchType: Constants.ChatFetchType,
        isFirstFetch: Boolean = false
    ) {
        if (chatHeadIntentData.chatHeadId == null)
            return

        val bodyMap: HashMap<String, Any> = hashMapOf(
            "chatHeadId" to chatHeadIntentData.chatHeadId!!,
            "pageSize" to 10,
        )

        if (messageSequence != null) {
            bodyMap["messageSequence"] = messageSequence
        }

        when (chatFetchType) {
            Constants.ChatFetchType.NEW_MESSAGE -> {
                bodyMap["newerMsg"] = true

                // showing bottom progress bar
                if (!isFirstFetch)
                    changeMessageProgressVisibility(Constants.MessageProgressChange.SHOW_NEW)
            }
            Constants.ChatFetchType.OLD_MESSAGE -> {
                bodyMap["olderMsg"] = true

                // showing top progress bar
                changeMessageProgressVisibility(Constants.MessageProgressChange.SHOW_OLD)
            }
            Constants.ChatFetchType.SEARCH_MESSAGE, Constants.ChatFetchType.REPLY_MESSAGE_CLICK -> {
                bodyMap["newerMsg"] = true
                bodyMap["olderMsg"] = true
            }
        }

        chatVM.fetchChatHeadMessages(bodyMap, chatFetchType)
    }

    private fun observeError() {
        fun processError(it: ResponseStatus) {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    showToast("Server Error")
                }
                else -> {
                }
            }
        }

        reportVM.observeError().observe(this, Observer {
            processError(it)
        })
        chatVM.observeError().observe(this, Observer {
            processError(it)
        })
        mediaUploadVM.observeError().observe(this, Observer {
            processError(it)
        })
    }

    private fun hideBlockedItem() {
        fun hideViews() {
            cv_attachment.visibility = View.GONE
            cl_reply_root.visibility = View.GONE
            cv_chat.visibility = View.GONE
            cv_camera.visibility = View.GONE
            cv_send.visibility = View.GONE
            cv_mic.visibility = View.GONE
            img_emoji.visibility = View.GONE
        }

        when (chatHeadInfoModel!!.chatHeadType) {
            "user" -> {
                if (chatHeadInfoModel!!.isBlockedByMe == 1 || chatHeadInfoModel!!.isBlockedByOther == 1) {
                    hideViews()
                    isChatRestricted = true
                }
            }
            "group" -> {
                if (chatHeadInfoModel!!.isGroupMember == 0) {
                    hideViews()
                    isChatRestricted = true
                }
            }
        }

        if (isChatRestricted) {
            img_options_menu.visibility = View.GONE
        }
    }

    private fun addKeyboardListener() {
        edt_chat.addTextChangedListener(textChangedListener)
        changeViewBasedOnKeyboard()
    }

    private val textChangedListener = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {}
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            if (!isRecordingAudio) {
                isKeyboardOpen = edt_chat.text!!.trim().isNotEmpty()
                changeViewBasedOnKeyboard()

                if (chatHeadIntentData.chatHeadType != "broadcast" && chatHeadInfoModel != null) {
                    if (typingHandler != null) {
                        typingHandler!!.removeCallbacks(typingRunnable)
                    } else {
                        typingHandler = Handler(Looper.myLooper()!!)
                    }
                    typingHandler!!.postDelayed(typingRunnable, typingDelay)
                }
            }
        }
    }

    val typingRunnable = Runnable {
        if (typingData == null) {
            typingData = JSONObject()
            if (chatHeadInfoModel!!.chatHeadType == "user") {
                typingData!!.put("otherUserId", chatHeadInfoModel!!.chatTypeId())
            } else {
                typingData!!.put("groupId", chatHeadInfoModel!!.chatTypeId())
            }
        }
        MsgMee.getSocket().emit(MySocketEvents.EVENT_TYPING, typingData)
    }

    override fun multiSelectChange(isMultiSelectOpen: Boolean, selectCount: Int) {
    }

    override fun notifyMultiSelectItemChange(
        isMultiSelectOpen: Boolean, selectCount: Int,
        selectedMessageList: ArrayList<Int>
    ) {
        this.multiSelectOpen = isMultiSelectOpen
        this.multiSelectCount = selectCount
        txt_multi_select_count.text = if (selectCount == 1) "" else selectCount.toString()
        this.selectedMessageList = selectedMessageList

        img_reply.visibility = if (multiSelectOpen && selectCount == 1) View.VISIBLE else View.GONE

        chat_toolbar_group.visibility = if (multiSelectOpen) View.GONE else View.VISIBLE
        if (chatHeadIntentData.chatHeadType == "user") {
            img_video_call.visibility = if (multiSelectOpen) View.GONE else View.VISIBLE
            img_audio_call.visibility = if (multiSelectOpen) View.GONE else View.VISIBLE
        }
        reply_toolbar_group.visibility = if (multiSelectOpen) View.VISIBLE else View.GONE
    }

    private fun changeViewBasedOnKeyboard() {
        if (isChatRestricted)
            return

        cv_attachment.visibility = if (isKeyboardOpen) View.GONE else View.VISIBLE
        cv_camera.visibility = if (isKeyboardOpen) View.GONE else View.VISIBLE
        cv_mic.visibility = if (isKeyboardOpen) View.GONE else View.VISIBLE
        cv_send.visibility = if (isKeyboardOpen) View.VISIBLE else View.GONE

        if (isKeyboardOpen) {
            ImageViewCompat.setImageTintList(
                img_emoji,
                ColorStateList.valueOf(ContextCompat.getColor(this, R.color.lite_green_100))
            )
        } else {
            // setting color according to dark or light mode
            val typedValue = TypedValue()
            this.theme.resolveAttribute(R.attr.colorControlNormal, typedValue, true)
            ImageViewCompat.setImageTintList(
                img_emoji,
                ColorStateList.valueOf(typedValue.data)
            )
        }
    }

    private fun setViewsClick() {
        img_toolbar_back.setOnClickListener {
            onBackPressed()
        }
        img_video_call.setOnClickListener {
            Constants.startCall(this, true, StartCallModel(
                chatHeadIntentData.chatName,
                chatHeadIntentData.chatName,
                chatHeadIntentData.chatTypeId,
                chatHeadIntentData.chatProfile
            ))
        }
        img_audio_call.setOnClickListener {
            Constants.startCall(this, false, StartCallModel(
                chatHeadIntentData.chatName,
                chatHeadIntentData.chatName,
                chatHeadIntentData.chatTypeId,
                chatHeadIntentData.chatProfile
            ))
        }
        cv_attachment.setOnClickListener {
            if (!isRecordingAudio) {
                animateFabMenu()
            }
        }
        img_reply_close.setOnClickListener {
            isReplyShowing = false
            animateReply()
        }
        img_delete.setOnClickListener {
            openChatOptions(isChatOption = false)
        }
        img_reply.setOnClickListener {
            processReply()
        }
        cv_ml_card.setOnClickListener {
            openChatInfo()
        }
        txt_chat_head_name.setOnClickListener {
            openChatInfo()
        }
        txt_online_status.setOnClickListener {
            openChatInfo()
        }
        cv_contact_fab.setOnClickListener {
            // closing fab menu
            animateFabMenu()

            val audioIntent = Intent(this, ContactListActivity::class.java)
            startActivityForResult(audioIntent, selectContactCode)
        }
        cv_audio_fab.setOnClickListener {
            // closing fab menu
            animateFabMenu()

            val audioIntent = Intent()
            audioIntent.type = "audio/*"
            audioIntent.action = Intent.ACTION_GET_CONTENT
            startActivityForResult(audioIntent, selectAudioCode)
        }
        cv_gallery_fab.setOnClickListener {
            // closing fab menu
            animateFabMenu()

            MyPreferences.saveIntInPreference(this, "maxSelect", 10)

            InsGallery.openGallery(
                this, GlideEngine.createGlideEngine(),
                GlideCacheEngine.createCacheEngine(), ArrayList<LocalMedia>(),
                PictureConfig.REQUEST_GALLERY_IMAGE_FOR_POST
            )
        }
        cv_camera.setOnClickListener {
            if (!isRecordingAudio) {
                if (Constants.isPermissionGranted(this, CAMERA_REQUIRED_PERMISSIONS)) {
                    dispatchTakePictureIntent()
                } else {
                    ActivityCompat.requestPermissions(
                        this,
                        CAMERA_REQUIRED_PERMISSIONS,
                        CAMERA_REQUEST_PERMISSIONS
                    )
                }
            }
        }
        cv_doc_fab.setOnClickListener {
            // closing fab menu
            animateFabMenu()

            val audioIntent = Intent()
            audioIntent.type = "*/*"
            audioIntent.action = Intent.ACTION_GET_CONTENT
            startActivityForResult(audioIntent, selectDocCode)
        }
        cv_send.setOnClickListener {
            val messageText = edt_chat.text.toString().trim()
            if (messageText.isEmpty())
                return@setOnClickListener
            if (isReplyShowing) {
                val messageJson: HashMap<String, Any?> = hashMapOf(
                    "replyMessageText" to replyModel.messageText,
                    "replyMessageUsername" to replyModel.senderUsername,
                    "replyMessageId" to replyModel.messageId,
                    "replyMessageSequence" to replyModel.messageSequenceNo
                )
                val messageType = "text"
                messageJson["type"] = replyModel.getReplyType()
                if (replyModel.messageJson != null) {
                    messageJson["replyMediaUrl"] = replyModel.messageJson!!.mediaUrl
                }

                sendMessage(
                    messageType,
                    messageText,
                    messageJson,
                    replyMessageId = replyModel.messageId
                )

                // closing reply layout
                isReplyShowing = false
                animateReply()
            } else {
                sendMessage("text", messageText)
            }
        }
        img_options_menu.setOnClickListener {
            openChatOptions()
        }
        img_toolbar_search_back.setOnClickListener {
            showSearchBar = false
            changeSearchBarVisibility()
        }
        edt_search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                startSearching()
                return@setOnEditorActionListener true
            }
            return@setOnEditorActionListener false
        }
        img_search_down.setOnClickListener {
            if (currentSearchIndex > 0) {
                currentSearchIndex--
                processSearch()
            }
        }
        img_search_up.setOnClickListener {
            if (currentSearchIndex < searchResultTotal - 1) {
                currentSearchIndex++
                processSearch()
            }
        }
        cv_mic.setOnClickListener {
            if (isRecordingAudio) {
                changeAudioRecording()
            }
        }
        cv_mic.setOnLongClickListener {
            if (!isRecordingAudio) {
                if (Constants.isPermissionGranted(this, AUDIO_RECORD_REQUIRED_PERMISSIONS)) {
                    changeAudioRecording()
                } else {
                    ActivityCompat.requestPermissions(
                        this,
                        AUDIO_RECORD_REQUIRED_PERMISSIONS,
                        AUDIO_RECORD_REQUEST_PERMISSIONS
                    )
                }
            }
            return@setOnLongClickListener true
        }
        img_forward.setOnClickListener {
            val intent = Intent(this, ForwardToActivity::class.java)
            startActivityForResult(intent, FORWARD_MESSAGE)
        }
    }

    private fun changeAudioRecording(isSendMessage: Boolean = true) {
        if (isRecordingAudio) {
            isRecordingAudio = false
            updateAudioRecordUI()
            mediaRecorder?.apply {
                stop()
                release()
            }
            mediaRecorder = null

            if (isSendMessage) {
                // sending recorded audio as message
                val audioUri = FileProvider.getUriForFile(
                    this,
                    BuildConfig.APPLICATION_ID + ".provider", File(recordingAudioPath)
                )
                mediaUploadVM.uploadContentUriMedia(
                    this,
                    listOf(
                        MediaModel(
                            "",
                            Constants.SelectedMediaType.AUDIO,
                            audioUri
                        )
                    ),
                    Constants.messageMediaUploadKey
                )
            }
        } else {
            isRecordingAudio = true
            updateAudioRecordUI()

            mediaRecorder = MediaRecorder().apply {
                recordingAudioPath = Constants.getFolderPath(
                    this@ChatActivity, Constants.FolderType.RECORD_AUDIO
                ).plus("MessageMee_${System.currentTimeMillis()}_.mp3")
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setOutputFile(recordingAudioPath)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)

                prepare()
                start()
            }
        }
    }

    private fun updateAudioRecordUI() {
        if (isRecordingAudio) {
            cv_attachment.alpha = searchArrowAlpha
            cv_camera.alpha = searchArrowAlpha
            img_emoji.visibility = View.GONE

            ImageViewCompat.setImageTintList(
                img_mic,
                ColorStateList.valueOf(ContextCompat.getColor(this, R.color.red))
            )

            edt_chat.setText(getString(R.string.recording_).plus("  00:00 ${getString(R.string.min)}"))

            // starting record counter
            audioRecordTimerHandler?.removeCallbacks(audioRecordTimerRunnable)
            if (audioRecordTimerHandler == null)
                audioRecordTimerHandler = Handler(Looper.myLooper()!!)

            audioRecordTimerHandler!!.postDelayed(audioRecordTimerRunnable, 1000)
        } else {
            cv_attachment.alpha = 1.0f
            cv_camera.alpha = 1.0f
            edt_chat.text!!.clear()
            audioRecordSec = 0
            img_emoji.visibility = View.VISIBLE

            // setting color according to dark or light mode
            val typedValue = TypedValue()
            this.theme.resolveAttribute(R.attr.colorControlNormal, typedValue, true)
            ImageViewCompat.setImageTintList(
                img_mic,
                ColorStateList.valueOf(typedValue.data)
            )

            // stopping record counter
            audioRecordTimerHandler?.removeCallbacks(audioRecordTimerRunnable)
        }
    }

    private val audioRecordTimerRunnable = Runnable {
        updateRecordTimer()
    }

    private fun updateRecordTimer() {
        audioRecordSec++
        edt_chat.setText(getString(R.string.recording_).plus("  ${getFormattedTimer()} ${getString(R.string.min)}"))
        audioRecordTimerHandler!!.postDelayed(audioRecordTimerRunnable, 1000)
    }

    private fun getFormattedTimer() =
        String.format("%02d:%02d", audioRecordSec / 60, audioRecordSec % 60)

    private fun startSearching() {
        Log.v("harshSearch", "search button clicked ${edt_search.text.toString()}")
        // first closing keyboard
        edt_search.closeKeyboard()

        // now searching for entered keyword
        searchText = edt_search.text.toString().trim()
        if (searchText.isNotEmpty()) {
            val bodyMap: HashMap<String, Any> = hashMapOf(
                "chatHeadId" to chatHeadIntentData.chatHeadId!!,
                "searchKey" to searchText
            )
            chatVM.searchMessages(bodyMap)
            txt_search_count.visibility = View.INVISIBLE
            pb_search.visibility = View.VISIBLE
        }
    }

    private fun sendMessage(
        messageType: String,
        messageText: String,
        messageJson: HashMap<String, Any?>? = null,
        isForwarded: Boolean = false,
        replyMessageId: String? = null,
    ) {
        val messageData: HashMap<String, Any> = hashMapOf(
            "messageType" to messageType,
            "messageText" to messageText,
            "isForwarded" to isForwarded
        )
        if (messageJson != null) {
            messageData["messageJson"] = messageJson
        }
        if (replyMessageId != null) {
            messageData["replyMessageId"] = replyMessageId
        }
        val bodyMap: HashMap<String, Any> = hashMapOf(
            "messageData" to messageData
        )

        if (chatHeadIntentData.chatHeadId == null) {
            bodyMap["otherUserId"] = chatHeadIntentData.chatTypeId
            chatVM.sendMessage(bodyMap, true)
        } else {
            bodyMap["chatHeadId"] = chatHeadIntentData.chatHeadId!!
            chatVM.sendMessage(bodyMap)
        }

        edt_chat.text!!.clear()
        // edt_chat.hideKeyboard()
    }

    private fun openChatInfo() {
        if (isChatRestricted)
            return
        if (chatHeadIntentData.chatHeadType == "group") {
            val intent = Intent(this, GroupInfoActivity::class.java)
            intent.putExtra("groupId", chatHeadIntentData.chatTypeId)
            startActivityForResult(intent, OPEN_GROUP_INFO_CODE)
        } else if (chatHeadIntentData.chatHeadType == "broadcast") {
            val intent = Intent(this, BroadcastInfoActivity::class.java)
            intent.putExtra("broadcastId", chatHeadIntentData.chatTypeId)
            startActivity(intent)
        }
    }

    private fun animateReply() {
        if (isReplyShowing) {
            cl_reply_root.animate().translationY(0f)
            edt_chat.hint = getString(R.string.type_to_reply)
        } else {
            cl_reply_root.animate().translationY(resources.getDimension(R.dimen.animate_200))
            edt_chat.hint = getString(R.string.type_your_message)
        }
    }

    private fun animateFabMenu() {
        showFab = !showFab
        if (showFab) {
            cv_doc_fab.animate().translationY(0f)
            cv_gallery_fab.animate().translationY(0f)
            cv_contact_fab.animate().translationY(0f)
            cv_audio_fab.animate().translationY(0f)
        } else {
            cv_gallery_fab.animate().translationY(resources.getDimension(R.dimen.animate_200))
            cv_contact_fab.animate().translationY(resources.getDimension(R.dimen.animate_300))
            cv_audio_fab.animate().translationY(resources.getDimension(R.dimen.animate_400))
            cv_doc_fab.animate().translationY(resources.getDimension(R.dimen.animate_500))
        }
    }

    override fun setInitialLanguage() {
        edt_chat.hint = getString(R.string.type_your_message)
        edt_search.hint = getString(R.string.search_)
    }

    override fun bindData() {
        bindNameAndProfile(chatHeadIntentData.chatName, chatHeadIntentData.chatProfile)

        if (chatHeadIntentData.chatHeadType != "user") {
            img_video_call.visibility = View.GONE
            img_audio_call.visibility = View.GONE
        }

        if (chatHeadIntentData.chatHeadId == null) {
            img_options_menu.visibility = View.GONE
        }

        val layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, true)
        rl_chat.layoutManager = layoutManager
        rl_chat.adapter = chatAdapter
        chatAdapter.notifyDataSetChanged()

        // hiding top and bottom message load progress bar
        changeMessageProgressVisibility(Constants.MessageProgressChange.HIDE_BOTH)

        // adding scroll listener for pagination
        rl_chat.addOnScrollListener(object : ScrollListener(layoutManager) {
            override fun isNewLastPage() = isNewLastPage
            override fun isOldLastPage() = isOldLastPage
            override fun isLoading() = isLoading

            override fun loadOldItems() {
                rl_chat.stopScroll()
                isLoading = true
                fetchMessages(
                    messageList.last().messageSequenceNo.toString(),
                    Constants.ChatFetchType.OLD_MESSAGE
                )
            }

            override fun loadNewItems() {
                rl_chat.stopScroll()
                isLoading = true
                fetchMessages(
                    messageList.first().messageSequenceNo.toString(),
                    Constants.ChatFetchType.NEW_MESSAGE
                )
            }
        })

        // default y value
        cv_gallery_fab.y = resources.getDimension(R.dimen.animate_200)
        cv_contact_fab.y = resources.getDimension(R.dimen.animate_300)
        cv_audio_fab.y = resources.getDimension(R.dimen.animate_400)
        cv_doc_fab.y = resources.getDimension(R.dimen.animate_500)
        cl_reply_root.y = resources.getDimension(R.dimen.animate_200)
        cl_search.y = resources.getDimension(R.dimen.animate_100)
    }

    private fun changeMessageProgressVisibility(messageProgressChange: Constants.MessageProgressChange) {
        when (messageProgressChange) {
            Constants.MessageProgressChange.HIDE_BOTH -> {
                pb_old_message.visibility = View.GONE
                pb_new_message.visibility = View.GONE
            }
            Constants.MessageProgressChange.HIDE_OLD -> {
                pb_old_message.visibility = View.GONE
            }
            Constants.MessageProgressChange.HIDE_NEW -> {
                pb_new_message.visibility = View.GONE
            }
            Constants.MessageProgressChange.SHOW_OLD -> {
                pb_old_message.visibility = View.VISIBLE
            }
            Constants.MessageProgressChange.SHOW_NEW -> {
                pb_new_message.visibility = View.VISIBLE
            }
        }
    }


    override fun onBackPressed() {
        when {
            multiSelectOpen -> {
                chatAdapter.clearMultiSelect()
            }
            showSearchBar -> {
                showSearchBar = false
                changeSearchBarVisibility()
            }
            else -> {
                super.onBackPressed()
            }
        }
    }

    private fun processReply() {
        replyModel = messageList[selectedMessageList[0]]

        chatAdapter.clearMultiSelect()
        isReplyShowing = true

        cv_reply_media.visibility = View.VISIBLE

        txt_reply_text.text = when (replyModel.messageEnumType) {
            Constants.MessageType.MY_MESSAGE, Constants.MessageType.OTHER_MESSAGE,
            Constants.MessageType.MY_MESSAGE_REPLY, Constants.MessageType.OTHER_MESSAGE_REPLY,
            Constants.MessageType.MY_IMAGE_REPLY, Constants.MessageType.OTHER_IMAGE_REPLY,
            Constants.MessageType.MY_CONTACT_REPLY, Constants.MessageType.OTHER_CONTACT_REPLY,
            Constants.MessageType.MY_AUDIO_REPLY, Constants.MessageType.OTHER_AUDIO_REPLY,
            Constants.MessageType.MY_DOC_REPLY, Constants.MessageType.OTHER_DOC_REPLY,
            Constants.MessageType.MY_VIDEO_REPLY, Constants.MessageType.OTHER_VIDEO_REPLY,
            Constants.MessageType.MY_GIF_REPLY, Constants.MessageType.OTHER_GIF_REPLY -> {
                cv_reply_media.visibility = View.GONE

                replyModel.messageText
            }
            Constants.MessageType.MY_IMAGE, Constants.MessageType.OTHER_IMAGE,
            Constants.MessageType.MY_IMAGE_MESSAGE, Constants.MessageType.OTHER_IMAGE_MESSAGE -> {
                Glide.with(this).load(replyModel.messageJson!!.mediaUrl.mediaFullUrl())
                    .into(img_reply_media)

                if (replyModel.messageText.isEmpty()) {
                    getString(R.string.image)
                } else {
                    replyModel.messageText
                }
            }
            Constants.MessageType.MY_CONTACT, Constants.MessageType.OTHER_CONTACT -> {
                Glide.with(this).load(replyModel.messageJson!!.mediaUrl.mediaFullUrl())
                    .placeholder(R.drawable.profile_placeholder).into(img_reply_media)

                if (replyModel.messageText.isEmpty()) {
                    getString(R.string.contact)
                } else {
                    replyModel.messageText
                }
            }
            Constants.MessageType.MY_AUDIO, Constants.MessageType.OTHER_AUDIO -> {
                Glide.with(this).load(R.drawable.ic_music).into(img_reply_media)

                if (replyModel.messageText.isEmpty()) {
                    getString(R.string.audio)
                } else {
                    replyModel.messageText
                }
            }
            Constants.MessageType.MY_DOC, Constants.MessageType.OTHER_DOC -> {
                Glide.with(this).load(R.drawable.ic_doc).into(img_reply_media)

                if (replyModel.messageText.isEmpty()) {
                    getString(R.string.document)
                } else {
                    replyModel.messageText
                }
            }
            Constants.MessageType.MY_VIDEO, Constants.MessageType.OTHER_VIDEO,
            Constants.MessageType.MY_VIDEO_MESSAGE, Constants.MessageType.OTHER_VIDEO_MESSAGE -> {
                Glide.with(this).load(replyModel.messageJson!!.mediaUrl.mediaFullUrl())
                    .into(img_reply_media)

                if (replyModel.messageText.isEmpty()) {
                    getString(R.string.video)
                } else {
                    replyModel.messageText
                }
            }
            Constants.MessageType.MY_GIF, Constants.MessageType.OTHER_GIF -> {
                Glide.with(this).load(replyModel.messageJson!!.mediaUrl.mediaFullUrl())
                    .into(img_reply_media)

                if (replyModel.messageText.isEmpty()) {
                    getString(R.string.gif)
                } else {
                    replyModel.messageText
                }
            }
            else -> ""
        }
        txt_reply_username.text = Constants.getUsername(this, replyModel.senderUsername)

        animateReply()

        // focusing on editText and opening keyboard
        edt_chat.requestFocus()
        edt_chat.showKeyboard()
    }

    private fun bindNameAndProfile(chatName: String, chatProfile: String?) {
        txt_chat_head_name.text = chatName
        if (chatHeadIntentData.chatHeadType == "broadcast") {
            Glide.with(this).load(R.drawable.ic_broadcast_background)
                .into(img_messenger_profile)
        } else {
            Glide.with(this).load(chatProfile)
                .placeholder(R.drawable.profile_placeholder).into(img_messenger_profile)
        }
    }

    private fun openChatOptions(isChatOption: Boolean = true) {
        val view = LayoutInflater.from(this).inflate(R.layout.profile_options_bs, null)
        val dialog = BottomSheetDialog(this, R.style.SheetDialog)
        dialog.setContentView(view)

        val txt_menu_1 = view.findViewById<CustomTextView>(R.id.txt_menu_1)
        val txt_menu_2 = view.findViewById<CustomTextView>(R.id.txt_menu_2)
        val txt_menu_3 = view.findViewById<CustomTextView>(R.id.txt_menu_3)
        val txt_menu_4 = view.findViewById<CustomTextView>(R.id.txt_menu_4)
        val txt_menu_5 = view.findViewById<CustomTextView>(R.id.txt_menu_5)
        val view_menu_1 = view.findViewById<View>(R.id.view_menu_1)
        val view_menu_2 = view.findViewById<View>(R.id.view_menu_2)
        val view_menu_3 = view.findViewById<View>(R.id.view_menu_3)
        val view_menu_4 = view.findViewById<View>(R.id.view_menu_4)

        txt_menu_4.visibility = View.GONE
        view_menu_3.visibility = View.GONE
        txt_menu_5.visibility = View.GONE
        view_menu_4.visibility = View.GONE

        fun processChatOption() {
            txt_menu_1.text = getString(R.string.search_messages)
            txt_menu_2.text = getString(R.string.clear_messages)

            if (chatHeadIntentData.chatHeadType != "broadcast") {
                txt_menu_3.text = getString(R.string.report_chat)
            } else {
                txt_menu_3.visibility = View.GONE
                view_menu_2.visibility = View.GONE
            }

            txt_menu_2.setOnClickListener {
                val bodyMap: HashMap<String, Any> = hashMapOf(
                    "chatHeadId" to chatHeadIntentData.chatHeadId!!
                )
                chatVM.clearChatHead(bodyMap)
                dialog.dismiss()
            }

            txt_menu_3.setOnClickListener {
                val reportView =
                    LayoutInflater.from(this).inflate(R.layout.report_bottom_sheet, null)
                reportListBottomSheetDialog = BottomSheetDialog(this, R.style.SheetDialog)
                reportListBottomSheetDialog.setContentView(reportView)
                reportView.txt_report_people.text = getString(R.string.report_chat)

                val manager = LinearLayoutManager(this)
                reportView.rv_user_reportList.layoutManager = manager
                reportAdapter = ReportAdapter(reportList, this)
                reportView.rv_user_reportList.adapter = reportAdapter
                reportView.rv_user_reportList.addItemDecoration(
                    DividerItemDecoration(
                        this,
                        manager.orientation
                    )
                )
                reportListBottomSheetDialog.show()
                if (chatHeadIntentData.chatHeadType == "user") {
                    val bodyMap = HashMap<String, Any>().apply {
                        put("type", "user")
                    }
                    reportVM.getReportUserListData(bodyMap)
                } else { // group chat
                    val bodyMap = HashMap<String, Any>().apply {
                        put("type", "messengerGroup")
                    }
                    reportVM.getReportUserListData(bodyMap)
                }
                dialog.dismiss()
            }

            txt_menu_1.setOnClickListener {
                showSearchBar = true
                changeSearchBarVisibility()
                dialog.dismiss()
            }
        }

        fun processDeleteOption() {
            txt_menu_3.visibility = View.GONE
            view_menu_2.visibility = View.GONE
            var isDeleteForAllAvailable = true

            messageList.forEach {
                if (it.isSelected && !it.isMyMessage) {
                    isDeleteForAllAvailable = false
                }
            }

            if (isDeleteForAllAvailable) {
                txt_menu_2.text = getString(R.string.delete_for_everyone)
            } else {
                txt_menu_2.visibility = View.GONE
                view_menu_1.visibility = View.GONE
            }
            txt_menu_1.text = getString(R.string.delete_for_me)

            txt_menu_2.setOnClickListener {
                val deleteMessageList = ArrayList<String>()
                for (index in selectedMessageList) {
                    deleteMessageList.add(messageList[index].messageId)
                }
                val bodyMap: HashMap<String, Any> = hashMapOf(
                    "messageIds" to deleteMessageList
                )
                chatVM.deleteMessagesForAll(bodyMap)
                dialog.dismiss()

                chatAdapter.clearMultiSelect()
            }

            txt_menu_1.setOnClickListener {
                val deleteMessageList = ArrayList<String>()
                val deleteMessageIndex = ArrayList<Int>()
                for (index in selectedMessageList) {
                    deleteMessageList.add(messageList[index].messageId)
                    deleteMessageIndex.add(index)
                }
                val bodyMap: HashMap<String, Any> = hashMapOf(
                    "chatHeadId" to chatHeadIntentData.chatHeadId!!,
                    "messageIds" to deleteMessageList
                )
                chatVM.deleteMessagesForMe(bodyMap, deleteMessageIndex)
                dialog.dismiss()

                chatAdapter.clearMultiSelect()
            }
        }

        if (isChatOption) {
            processChatOption()
        } else {
            processDeleteOption()
        }

        dialog.show()
    }

    private fun changeSearchBarVisibility() {
        if (showSearchBar) {
            edt_search.text!!.clear()
            txt_search_count.visibility = View.GONE
            pb_search.visibility = View.GONE
            img_search_up.alpha = 0.3f
            img_search_down.alpha = 0.3f
            cl_toolbar.animate().translationY(-resources.getDimension(R.dimen.animate_100))
            Handler(Looper.myLooper()!!).postDelayed({
                // after completion of first animation now animating search bar
                cl_search.animate().translationY(0F)

                // focusing on editText and opening keyboard
                edt_search.requestFocus()
                edt_search.showKeyboard()
            }, 150)
        } else {
            cl_search.animate().translationY(-resources.getDimension(R.dimen.animate_100))
            Handler(Looper.myLooper()!!).postDelayed({
                // after completion of first animation now animating tool bar
                cl_toolbar.animate().translationY(0F)

                // for removing all spans
                searchText = ""
                chatAdapter.notifyDataSetChanged()
            }, 150)
        }
    }

    // callback of report selection
    override fun itemInteracted(position: Int) {
        val bodyMap = HashMap<String, Any>().apply {
            put("otherUserId", chatHeadIntentData.chatTypeId)
            put("reportOptionId", reportList[position].id)
        }
        reportVM.reportUser(bodyMap)
        reportListBottomSheetDialog.dismiss()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            CAMERA_REQUEST_PERMISSIONS -> {
                if (Constants.isPermissionGranted(this, CAMERA_REQUIRED_PERMISSIONS)) {
                    dispatchTakePictureIntent()
                } else {
                    Toast.makeText(
                        this,
                        "Camera permission is required for taking photos.",
                        Toast.LENGTH_SHORT
                    )
                        .show()
                }
            }
            STORAGE_REQUEST_PERMISSIONS -> {
                if (Constants.isPermissionGranted(this, STORAGE_REQUIRED_PERMISSIONS)) {
                    startDownloading()
                } else {
                    Toast.makeText(
                        this,
                        "Storage permission is required for downloading file",
                        Toast.LENGTH_SHORT
                    )
                        .show()
                }
            }
            AUDIO_RECORD_REQUEST_PERMISSIONS -> {
                if (Constants.isPermissionGranted(this, AUDIO_RECORD_REQUIRED_PERMISSIONS)) {
                    changeAudioRecording()
                } else {
                    Toast.makeText(
                        this,
                        "Audio record permission is required for recording audio",
                        Toast.LENGTH_SHORT
                    )
                        .show()
                }
            }
        }
    }

    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.also {
                val photoFile = Constants.createFile(this)
                // Continue only if the File was successfully created
                if (photoFile == null) {
                    showToast()
                } else {
                    capturedPhotoPath = photoFile.absolutePath
                    photoFile.also {
                        val photoURI: Uri = FileProvider.getUriForFile(
                            this,
                            "${packageName}.fileprovider",
                            it
                        )
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                        startActivityForResult(takePictureIntent, CAMERA_REQUEST)
                    }
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            selectAudioCode -> {
                if (resultCode == RESULT_OK && data != null) {
                    val uri: Uri? = data.data
                    mediaUploadVM.uploadContentUriMedia(
                        this,
                        listOf(
                            MediaModel(
                                "",
                                Constants.SelectedMediaType.AUDIO,
                                uri
                            )
                        ),
                        Constants.messageMediaUploadKey
                    )
                }
            }
            selectContactCode -> {
                if (resultCode == RESULT_OK && data != null && data.extras != null) {
                    pendingContactList =
                        data.extras!!.getParcelableArrayList<ContactModel>("contactList") as ArrayList<ContactModel>?
                            ?: ArrayList()

                    if (pendingContactList.size > 0) {
                        // first uploading media
                        sendContactMessage()
                    }
                }
            }
            selectDocCode -> {
                if (resultCode == RESULT_OK && data != null) {
                    val uri: Uri? = data.data
                    if (uri != null) {
                        val mimeType = contentResolver.getType(uri) ?: ""

                        val mediaType = when {
                            mimeType.contains("image", true) -> {
                                Constants.SelectedMediaType.IMAGE
                            }
                            mimeType.contains("video", true) -> {
                                Constants.SelectedMediaType.VIDEO
                            }
                            mimeType.contains("audio", true) -> {
                                Constants.SelectedMediaType.AUDIO
                            }
                            else -> {
                                Constants.SelectedMediaType.DOC
                            }
                        }
                        // uploading selected media
                        mediaUploadVM.uploadContentUriMedia(
                            this,
                            listOf(
                                MediaModel(
                                    "",
                                    mediaType,
                                    uri
                                )
                            ),
                            Constants.messageMediaUploadKey
                        )
                    }
                }
            }
            PictureConfig.REQUEST_GALLERY_IMAGE_FOR_POST -> {
                if (resultCode == RESULT_OK && data != null) {
                    mediaList.clear()

                    mediaList = PictureSelector.obtainMultipleResult(data)
                    if (mediaList.size > 0) {
                        val selectedMediaList = ArrayList<MediaPreviewModel>()
                        mediaList.forEach {
                            val mediaType = if (it.mimeType.contains(
                                    "video",
                                    true
                                )
                            ) Constants.SelectedMediaType.VIDEO else Constants.SelectedMediaType.IMAGE
                            selectedMediaList.add(
                                MediaPreviewModel(
                                    if (mediaType == Constants.SelectedMediaType.IMAGE) it.cutPath else it.path,
                                    mediaType
                                )
                            )
                        }

                        // opening media preview activity
                        val intent = Intent(this, MediaPreviewActivity::class.java)
                        intent.putParcelableArrayListExtra("mediaList", selectedMediaList)
                        startActivityForResult(intent, selectedMediaPreview)
                    }
                }
            }
            CAMERA_REQUEST -> {
                if (resultCode == RESULT_OK) {
                    // uploading selected media
                    val selectedMediaList = ArrayList<MediaPreviewModel>()
                    selectedMediaList.add(
                        MediaPreviewModel(
                            capturedPhotoPath,
                            Constants.SelectedMediaType.IMAGE
                        )
                    )
                    // opening media preview activity
                    val intent = Intent(this, MediaPreviewActivity::class.java)
                    intent.putParcelableArrayListExtra("mediaList", selectedMediaList)
                    startActivityForResult(intent, selectedMediaPreview)
                }
            }
            OPEN_GROUP_INFO_CODE -> {
                if (data != null && data.extras != null) {
                    val updatedData = Gson().fromJson(
                        data.extras!!.getString("updatedData"),
                        ChatHeadInfo::class.java
                    )

                    chatHeadInfoModel!!.groupName = updatedData.chatName
                    if (updatedData.chatProfile != null) {
                        chatHeadInfoModel!!.groupImageThumb = updatedData.chatProfile
                    }
                    bindNameAndProfile(updatedData.chatName, updatedData.chatProfile)
                }
            }
            selectedMediaPreview -> {
                if (resultCode == RESULT_OK && data != null && data.extras != null) {
                    pendingMediaList =
                        data.extras!!.getParcelableArrayList<MediaPreviewModel>("mediaList") as ArrayList<MediaPreviewModel>?
                            ?: ArrayList()

                    if (pendingMediaList.size > 0) {
                        // first uploading media
                        mediaUploadVM.uploadPathMedia(
                            listOf(
                                MediaModel(
                                    pendingMediaList[0].mediaPath,
                                    pendingMediaList[0].mediaType
                                )
                            ),
                            Constants.messageMediaUploadKey
                        )
                    }
                }
            }
            FORWARD_MESSAGE -> {
                if (resultCode == RESULT_OK && data != null && data.extras != null) {
                    val forwardToList =
                        data.extras!!.getParcelableArrayList<SelectedChatModel>("selectedChatList") as ArrayList<SelectedChatModel>?
                            ?: ArrayList()

                    if (forwardToList.size > 0) {
                        // forwarding selected messages to selected chat list
                        forwardSelectedMessages(forwardToList)
                    }
                }
            }
        }
    }

    private fun forwardSelectedMessages(forwardToList: ArrayList<SelectedChatModel>) {
        val forwardPendingList = ArrayList(selectedMessageList)
        chatAdapter.clearMultiSelect()

        val bodyMap = HashMap<String, Any>()
        val messageDataList = ArrayList<HashMap<String, Any>>()
        forwardPendingList.forEach {
            val messageData: HashMap<String, Any> = hashMapOf(
                "messageType" to messageList[it].messageType,
                "messageText" to messageList[it].messageText,
                "isForwarded" to true
            )
            if (messageList[it].messageJson != null && messageList[it].messageJson!!.replyMessageId == null) {
                messageData["messageJson"] = messageList[it].messageJson!!
            }
            messageDataList.add(messageData)
        }
        bodyMap["sendTo"] = forwardToList
        bodyMap["messageDataList"] = messageDataList

        chatVM.forwardMessages(bodyMap)
    }

    private fun sendContactMessage() {
        if (pendingContactList[0].contactProfile != null) {
            mediaUploadVM.uploadContentUriMedia(
                this,
                listOf(
                    MediaModel(
                        "",
                        Constants.SelectedMediaType.CONTACT,
                        pendingContactList[0].contactProfile!!
                    )
                ),
                Constants.messageMediaUploadKey
            )
        } else {
            processContactMessage(null)
        }
    }

    @Suppress("unused")
    @Subscribe
    fun userTyping(typingModel: TypingModel) {
        runOnUiThread {
            if (typingModel.chatHeadId == chatHeadIntentData.chatHeadId) {
                val typingText =
                    (if (chatHeadIntentData.chatHeadType != "user") "${typingModel.username} ${
                        getString(
                            R.string.is_
                        )
                    }" else "").plus(
                        getString(R.string.typing_)
                    )
                txt_online_status.text = typingText
                if (typingEndHandler == null) {
                    typingEndHandler = Handler(Looper.myLooper()!!)
                }
                typingEndHandler?.removeCallbacks(typingEndRunnable)
                typingEndHandler!!.postDelayed(typingEndRunnable, typingDelay)
            }
        }
    }

    private val typingEndRunnable = Runnable {
        txt_online_status.text = chatHeadInfoModel.onlineText(this)
    }

    @Suppress("unused")
    @Subscribe
    fun downloadFile(fileDownloadModel: FileDownloadModel) {
        if (Constants.isPermissionGranted(this, STORAGE_REQUIRED_PERMISSIONS)) {
            pendingDownloadList.add(fileDownloadModel)
            startDownloading()
        } else {
            pendingDownloadList.clear()
            pendingDownloadList.add(fileDownloadModel)
            ActivityCompat.requestPermissions(
                this,
                STORAGE_REQUIRED_PERMISSIONS,
                STORAGE_REQUEST_PERMISSIONS
            )
        }
    }

    private fun startDownloading() {
        if (currentlyDownloading) {
            return
        }

        if (pendingDownloadList.size > 0) {
            currentlyDownloading = true
            val downloadFile = DownloadFile()
            downloadFile.downloadFile(
                pendingDownloadList[0].messageId,
                Constants.getFolderPath(this, Constants.FolderType.DOCUMENT_FOLDER),
                pendingDownloadList[0].fileName,
                pendingDownloadList[0].fileServerPath.mediaFullUrl()!!,
                ::progressUpdate,
                ::downloadComplete
            )
        }
    }

    private fun progressUpdate(messageId: String, progress: Int) {
        runOnUiThread {
            Log.v("harshDownload", "messageId == $messageId, progress == $progress")
            pendingDownloadList[0].progressBar.progress = progress
        }
    }

    private fun downloadComplete(messageId: String, downloadSuccess: Boolean) {
        runOnUiThread {
            if (!downloadSuccess) {
                showToast("Something went wrong while downloading the file, please try again later")
            }

            currentlyDownloading = false
            val messageIndex = messageList.indexOfFirst {
                it.messageId == messageId
            }

            if (messageIndex != -1) {
                messageList[messageIndex].isDownloading = false
                chatAdapter.notifyItemChanged(messageIndex)
            }

            // removing downloaded media then start new download if any pending download available
            pendingDownloadList.removeAt(0)
            startDownloading()
        }
    }

    @Suppress("unused")
    @Subscribe
    fun messageReplyClicked(model: MessageReplyModel) {
        this.messageReplyModel = model
        val replyMessageIndex = messageList.indexOfFirst {
            it.messageSequenceNo == messageReplyModel.replyMessageSequence
        }
        if (replyMessageIndex != -1) {
            rl_chat.smoothScrollToPosition(replyMessageIndex)
        } else {
            fetchMessages(
                messageReplyModel.replyMessageSequence.toString(),
                Constants.ChatFetchType.REPLY_MESSAGE_CLICK
            )
        }
    }

    @Suppress("unused")
    @Subscribe
    fun changeAudioPlay(mediaPlayModel: MediaPlayModel) {
        runOnUiThread {

            // internal method for playing selected audio
            fun playAudio() {
                // creating data source
                val dataSourceFactory = DefaultDataSourceFactory(
                    this,
                    Util.getUserAgent(this, "messenger")
                )

                // creating media source from given url
                val mediaSource = ProgressiveMediaSource.Factory(dataSourceFactory)
                    .createMediaSource(Uri.parse(mediaPlayModel.chatModel.messageJson!!.mediaUrl!!.mediaFullUrl()))

                // preparing and playing audio
                isAudioSeekingRequired = mediaPlayModel.playPercentage > 0
                exoplayer?.prepare(mediaSource)
                exoplayer?.playWhenReady = true
            }

            // initialising variable if not initialised
            if (exoplayer == null) {
                exoplayer = ExoPlayerFactory.newSimpleInstance(
                    this,
                    DefaultRenderersFactory(this), DefaultTrackSelector(),
                    DefaultLoadControl()
                )
                exoplayer?.addListener(exoplayerEvents)
            }
            if (mediaPlayHandler == null) {
                mediaPlayHandler = Handler(Looper.myLooper()!!)
            }


            // resetting old player settings
            isAudioSeekingRequired = false
            mediaPlayHandler?.removeCallbacks(audioProgressRunnable)

            // taking action on media according to it's previous state
            if (this::oldMediaPlayModel.isInitialized) {
                if (mediaPlayModel.chatModel.messageId != oldMediaPlayModel.chatModel.messageId) {
                    stopUpdateOldUI()

                    // stopping exo player if playing
                    exoplayer?.playWhenReady = false
                    exoplayer?.stop(true)

                    // playing new selected audio
                    playAudio()
                } else {
                    if (mediaPlayModel.chatModel.playMedia) {
                        if (mediaPlayModel.playPercentage != 0) {
                            exoplayer?.seekTo(exoplayer!!.getMilliSecFromPercentage(mediaPlayModel.playPercentage))
                        }
                        exoplayer?.playWhenReady = true

                        mediaPlayHandler!!.postDelayed(audioProgressRunnable, 1000)
                    } else {
                        exoplayer?.playWhenReady = false
                    }
                }
            } else {
                playAudio()
            }

            oldMediaPlayModel = mediaPlayModel
        }
    }

    private fun stopUpdateOldUI() {
        val messageIndex = messageList.indexOfFirst { model ->
            model.messageId == oldMediaPlayModel.chatModel.messageId
        }

        if (messageIndex != -1) {
            messageList[messageIndex].playMedia = false
            chatAdapter.notifyItemChanged(messageIndex)
        }
        oldMediaPlayModel.seekBar.progress = 0
        oldMediaPlayModel.loadingBar.visibility = View.GONE
        oldMediaPlayModel.imgPlayPause.visibility = View.VISIBLE
    }

    private val exoplayerEvents = object : Player.EventListener {
        override fun onPlayerStateChanged(playWhenReady: Boolean, playbackState: Int) {
            super.onPlayerStateChanged(playWhenReady, playbackState)
            when (playbackState) {
                Player.STATE_READY -> {
                    Log.v("harshAudio", "STATE_READY")
                    mediaPlayHandler!!.postDelayed(audioProgressRunnable, 1000)

                    if(isAudioSeekingRequired) {
                        val millis =
                            exoplayer!!.getMilliSecFromPercentage(oldMediaPlayModel.playPercentage)
                        exoplayer?.seekTo(exoplayer!!.currentWindowIndex, millis)
                        exoplayer?.playWhenReady = true
                        isAudioSeekingRequired = false
                    }
                }
                Player.STATE_BUFFERING -> {
                    Log.v("harshAudio", "STATE_BUFFERING")
                }
                Player.STATE_ENDED -> {
                    Log.v("harshAudio", "STATE_ENDED")
                    mediaPlayHandler?.removeCallbacks(audioProgressRunnable)

                    stopUpdateOldUI()
                }
            }
        }

        override fun onPlayerError(error: ExoPlaybackException?) {
            super.onPlayerError(error)
            showToast("Can't play the audio")
            stopUpdateOldUI()
        }

        override fun onLoadingChanged(isLoading: Boolean) {
            super.onLoadingChanged(isLoading)
            Log.v("harshAudio", "onLoadingChanged == $isLoading")

            oldMediaPlayModel.loadingBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            oldMediaPlayModel.imgPlayPause.visibility = if (isLoading) View.GONE else View.VISIBLE
        }
    }

    private val audioProgressRunnable: Runnable = Runnable {
        processPlayProgress()
    }

    private fun processPlayProgress() {
        val progress = exoplayer?.getPlayPercentage()
        Log.v("harshAudio", "play percentage == $progress")
        oldMediaPlayModel.seekBar.progress = progress?.toInt() ?: 0

        mediaPlayHandler!!.postDelayed(audioProgressRunnable, 1000)
    }

    @Suppress("unused")
    @Subscribe
    fun userOnlineStatusChanged(onlineChangeData: OnlineChangeModel) {
        runOnUiThread {
            if (chatHeadInfoModel != null && chatHeadInfoModel!!.chatHeadType == "user" && chatHeadInfoModel!!.chatTypeId() == onlineChangeData.userId) {
                chatHeadInfoModel?.isOnline = if (onlineChangeData.isOnline) 1 else 0
                txt_online_status.text = chatHeadInfoModel.onlineText(this)
            }
        }
    }

    @Suppress("unused")
    @Subscribe
    fun userDeletedMessage(messageDeleteModel: MessageDeleteModel) {
        runOnUiThread {
            if (chatHeadInfoModel != null && chatHeadInfoModel!!.chatHeadId == messageDeleteModel.chatHeadId) {
                messageDeleteModel.messageIdsList!!.forEach { messageId ->
                    messageList.forEach { model ->
                        if (model.messageId == messageId) {
                            model.isDeletedForAll = 1
                        }
                    }
                }

                messageList.defineMessageEnum(chatHeadIntentData.chatHeadType)
                chatAdapter.notifyDataSetChanged()
            }
        }
    }

    @Suppress("unused")
    @Subscribe
    fun newMessage(newMessageList: ArrayList<ChatModel>) {
        runOnUiThread {
            if (newMessageList[0].chatHeadId == chatHeadIntentData.chatHeadId) {
                newMessageList.defineMessageEnum(chatHeadIntentData.chatHeadType)

                for (model in newMessageList) {
                    messageList.add(0, model)
                    chatAdapter.notifyItemInserted(0)

                    // emitting message read
                    if (!model.isMyMessage) {
                        val bodyMap = hashMapOf(
                            "chatHeadId" to model.chatHeadId,
                            "messageId" to model.messageId,
                            "messageSequence" to model.messageSequenceNo
                        )
                        MsgMee.getSocket().emit(MySocketEvents.EVENT_MESSAGE_READ, bodyMap)
                    }
                }
                rl_chat.smoothScrollToPosition(0)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        registerSocketEvents()
        MyNotificationBuilder.openedChatHeadId = chatHeadIntentData.chatHeadId
    }

    override fun onStop() {
        super.onStop()
        unregisterSocketEvents()
        if (isRecordingAudio) {
            changeAudioRecording(isSendMessage = false)
        }
        MyNotificationBuilder.openedChatHeadId = chatHeadIntentData.chatHeadId
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
        typingHandler?.removeCallbacks(typingRunnable)
        typingEndHandler?.removeCallbacks(typingRunnable)
        removeUnreadHandler?.removeCallbacks(removeUnreadRunnable)
        exoplayer?.stop()
        exoplayer?.release()
    }

    private fun registerSocketEvents() {
        if (!MsgMee.getSocket().hasListeners(MySocketEvents.EVENT_TYPING)) {
            MsgMee.getSocket().on(MySocketEvents.EVENT_TYPING, MySocketEvents.userTyping)
        }
        if (!MsgMee.getSocket().hasListeners(MySocketEvents.EVENT_MESSAGE_DELETED)) {
            MsgMee.getSocket()
                .on(MySocketEvents.EVENT_MESSAGE_DELETED, MySocketEvents.messageDeleted)
        }
    }

    private fun unregisterSocketEvents() {
        MsgMee.getSocket().off(MySocketEvents.EVENT_TYPING)
        MsgMee.getSocket().off(MySocketEvents.EVENT_MESSAGE_DELETED)
    }
}