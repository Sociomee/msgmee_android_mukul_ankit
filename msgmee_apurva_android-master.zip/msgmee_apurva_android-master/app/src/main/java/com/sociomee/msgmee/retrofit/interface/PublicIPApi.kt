package com.sociomee.msgmee.retrofit.`interface`

import com.sociomee.msgmee.retrofit.MyCall
import com.sociomee.msgmee.retrofit.model.IPModel
import retrofit2.http.GET

interface PublicIPApi {
    @GET("/json")
    fun locationDetails(): MyCall<IPModel>
}
