package com.sociomee.msgmee.ui.fragment

import android.annotation.TargetApi
import android.app.AlertDialog
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.DatePicker
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider

import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.activity.SignUpActivity
import com.sociomee.msgmee.ui.viewmodel.UserUpdateViewModel
import com.sociomee.msgmee.utils.AuthenticationUtil
import kotlinx.android.synthetic.main.user_birthdate_fragment.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.HashMap

class UserBirthdateFragment : Fragment(R.layout.user_birthdate_fragment) {

    var dobStatus = false
    lateinit var mDate: DatePicker
    lateinit var  passDate: String
    lateinit var userUpdateViewModel: UserUpdateViewModel
    var gender=""
    var childGender=""

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setData()
        initData()
        observeData()
        setViewsClick()
    }

    private fun setViewsClick() {
        clickListener()
        rb_special.setOnCheckedChangeListener { _, isChecked ->
            if(isChecked){
                rg_special.visibility=View.VISIBLE
                txt_special.visibility=View.VISIBLE
            }else{
                rg_special.visibility=View.GONE
                txt_special.visibility=View.GONE
            }
        }
    }

    private fun initData() {
        userUpdateViewModel = ViewModelProvider(this,ViewModelProvider.NewInstanceFactory()).get(
                UserUpdateViewModel::class.java
        )
    }

    private fun clickListener() {
        img_toolbar_back.setOnClickListener {
            (activity as SignUpActivity).onBackPress()
        }

        btn_continue.setOnClickListener {
            if(!this::mDate.isInitialized){
                Toast.makeText(context, "Please choose DOB first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (radioGroup.checkedRadioButtonId==-1){
                Toast.makeText(context, "please choose gender first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (radioGroup.checkedRadioButtonId==R.id.rb_special && rg_special.checkedRadioButtonId==-1){
                Toast.makeText(context, "please choose gender first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            gender=(view!!.findViewById(radioGroup.checkedRadioButtonId) as RadioButton).tag.toString()

            when {
                rg_special.checkedRadioButtonId != -1 -> childGender = (view!!.findViewById(rg_special.checkedRadioButtonId) as RadioButton).tag.toString()
                radioGroup.checkedRadioButtonId == R.id.rb_male -> childGender = "he"
                radioGroup.checkedRadioButtonId == R.id.rb_female -> childGender = "she"
            }

            val year: Int = mDate.year
            val month: Int = mDate.month
            val day: Int = mDate.dayOfMonth

            val calendar = Calendar.getInstance()
            calendar[year, month] = day

            val format = SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.getDefault())
            val strDate: String = format.format(calendar.time)

            val bodyMap = HashMap<String,Any>().apply {
                put("gender",gender)
                put("addressBy",childGender)
                put("dob",strDate)
            }
            userUpdateViewModel.updateUser(bodyMap)
        }
    }

    private fun observeError() {
        userUpdateViewModel.observeError().observe(this, Observer {
            when(it){
                ResponseStatus.INTERNET_NOT_AVAILABLE-> {
                    Toast.makeText(context,"Internet not available",Toast.LENGTH_LONG).show()
                }
                ResponseStatus.AUTH_ERROR-> {
                    Toast.makeText(context,"Auth Error",Toast.LENGTH_LONG).show()
                }
                ResponseStatus.SERVER_ERROR-> {
                    Toast.makeText(context,"Server Error",Toast.LENGTH_LONG).show()
                }
                else -> {}
            }
        })
    }

    private fun observeData() {
        userUpdateViewModel.observeUserUpdate().observe(this, Observer {
            if (it){
                (activity as SignUpActivity).changeFragment(AuthenticationUtil.SignupFragmentType.INTEREST, "ChooseIntrestFragment")
            } else {
                Toast.makeText(context, "failed", Toast.LENGTH_SHORT).show()
            }
        })
        // observing errors
        observeError()
    }

    fun setData(){
        txt_choose_dob.text=getString(R.string.enter_dob)
        txt_dd.text=getString(R.string.dd)
        txt_mm.text=getString(R.string.jan)
        txt_yyyy.text=getString(R.string.yyyy)
        txt_choose_gendar.text=getString(R.string.choose_gender)
        rb_male.text=getString(R.string.male)
        rb_female.text=getString(R.string.female)
        rb_special.text=getString(R.string.i_am_)
        btn_continue.text=getString(R.string.continue_btn)


        rb_rather_not.text=getString(R.string.rather_not)
        rb_she.text=getString(R.string.she)
        rb_he.text=getString(R.string.he)
        txt_special.text=getString(R.string.how_should_)

        ll_dob.setOnClickListener {
            val locale: Locale = getCurrentLocale()!!
            Locale.setDefault(locale)

            val builder = AlertDialog.Builder(context!!)
            val viewGroup = view!!.findViewById<ViewGroup>(android.R.id.content)
            val dialogView: View = LayoutInflater.from(view!!.context).inflate(R.layout.user_birth_date_picker_laert_dialog, viewGroup, false)

            val datePicker = dialogView.findViewById<DatePicker>(R.id.datePicker)
            val calendar = Calendar.getInstance()
            calendar.add(Calendar.YEAR, -13)

            datePicker.maxDate = calendar.timeInMillis

            if (this::mDate.isInitialized)
                datePicker.updateDate(mDate.year, mDate.month, mDate.dayOfMonth)

            val txt_pick = dialogView.findViewById<TextView>(R.id.txt_pick)
            txt_pick.text=getString(R.string.continue_btn)
            builder.setView(dialogView)
            val alertDialog = builder.create()

            txt_pick.setOnClickListener {
                mDate = datePicker
                val newmonth: String
                val daynews: String
                var monthOfYear = datePicker.month
                val dayOfMonth = datePicker.dayOfMonth
                monthOfYear += 1
                newmonth = if (monthOfYear < 10) {
                    "0$monthOfYear"
                } else {
                    monthOfYear.toString()
                }
                daynews = if (dayOfMonth < 10) {
                    "0$dayOfMonth"
                } else {
                    dayOfMonth.toString()
                }
                val userAge: Calendar = GregorianCalendar(datePicker.year, newmonth.toInt(), daynews.toInt())
                val minAdultAge: Calendar = GregorianCalendar()
                minAdultAge.add(Calendar.YEAR, -13)
                minAdultAge.add(Calendar.MONTH, 1)
                if (minAdultAge.before(userAge)) {
                    // getString(R.string.register_bod_you_must_be)
                    dobStatus = true
                } else {
                    dobStatus = false
//                    edit_bod.text = daynews + "-" + newmonth + "-" + datePicker.year
                    passDate = monthOfYear.toString() + "-" + datePicker.dayOfMonth + "-" + datePicker.year
                }
                txt_dd.text = datePicker.dayOfMonth.toString()
                txt_mm.text = monthOfYear.toString()
                txt_yyyy.text = datePicker.year.toString()

                alertDialog.dismiss()
            }

            alertDialog.show()

        }
    }

    @Suppress("DEPRECATION")
    @TargetApi(Build.VERSION_CODES.N)
    fun getCurrentLocale(): Locale? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            resources.configuration.locales[0]
        } else {
            resources.configuration.locale
        }
    }
}