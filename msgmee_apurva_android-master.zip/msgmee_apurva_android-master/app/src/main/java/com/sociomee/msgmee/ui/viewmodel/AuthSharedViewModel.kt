package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.ui.data.AuthModel

class AuthSharedViewModel : MyViewModel() {

    private val savedAuth = MutableLiveData<AuthModel>()

    // returning LiveData
    fun observeSavedAuth() = savedAuth

    fun saveAuth(enteredAuth: AuthModel) {
        savedAuth.value = enteredAuth
    }

}