package com.sociomee.msgmee.ui.activity

import android.os.Bundle
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import kotlinx.android.synthetic.main.incoming_call_activity.*

class IncomingCallActivity : CustomAppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.incoming_call_activity)

        setViewsClick()
    }

    private fun setViewsClick() {
        img_incoming_call_accept.setOnClickListener {
            startActivity(OutgoingCallActivity::class.java)
        }
        img_incoming_call_end.setOnClickListener {
            onBackPressed()
        }
    }

    override fun setInitialLanguage() {
        txt_incoming_caller_name.text = "Harsh"
        txt_incoming_call_status.text = getString(R.string.incoming_video_call)
        txt_incoming_call_status.text = getString(R.string.incoming_audio_call)
        txt_incoming_call_decline.text = getString(R.string.decline)
        txt_incoming_call_accept.text = getString(R.string.accept)
    }

    override fun bindData() {

    }
}