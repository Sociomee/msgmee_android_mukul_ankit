package com.sociomee.msgmee.ui.viewmodel

import android.content.Context
import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.model.MediaModel
import com.sociomee.msgmee.ui.repo.MediaUploadRepo
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class MediaUploadVM : MyViewModel() {

    private val mediaUploadData = MutableLiveData<ArrayList<MediaModel>>()
    private lateinit var mediaUploadRepo: MediaUploadRepo

    // returning LiveData
    fun observeMediaUpload() = mediaUploadData

    fun uploadPathMedia(pathList: List<MediaModel>, uploadType: String) {
        val builder = MultipartBody.Builder()
        builder.setType(MultipartBody.FORM)

        for (i in pathList.indices) {
            val file = File(pathList[i].mediaPath)

            builder.addFormDataPart(
                "files", file.name, file.asRequestBody(
                    "*/*".toMediaTypeOrNull()
                )
            )
        }
        builder.addFormDataPart("uploadFor", uploadType)
        val requestBody = builder.build()
        uploadAndProcessResult(pathList, requestBody)
    }

    fun uploadContentUriMedia(context: Context, pathList: List<MediaModel>, uploadType: String) {
        val builder = MultipartBody.Builder()
        builder.setType(MultipartBody.FORM)

        for (i in pathList.indices) {
            builder.addFormDataPart(
                "files", "contact",
                context.contentResolver.openInputStream(pathList[i].mediaUri!!)!!.readBytes()
                    .toRequestBody("*/*".toMediaTypeOrNull())
            )
        }
        builder.addFormDataPart("uploadFor", uploadType)
        val requestBody = builder.build()
        uploadAndProcessResult(pathList, requestBody)
    }

    private fun uploadAndProcessResult(pathList: List<MediaModel>, requestBody: MultipartBody) {
        if (!this::mediaUploadRepo.isInitialized) {
            mediaUploadRepo = MediaUploadRepo()
        }
        isLoading.value = true
        mediaUploadRepo.uploadMedia(requestBody).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                val uploadedMediaList = ArrayList<MediaModel>()
                for (index in it.data!!.mediaUploadData.successResult.indices) {
                    uploadedMediaList.add(
                        MediaModel(
                            it.data.mediaUploadData.successResult[index],
                            pathList[index].mediaType,
                            pathList[index].mediaUri
                        )
                    )
                }
                mediaUploadData.value = uploadedMediaList
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }


}