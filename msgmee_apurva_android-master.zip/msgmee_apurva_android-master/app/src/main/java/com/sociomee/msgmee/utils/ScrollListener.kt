package com.sociomee.msgmee.utils

import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


abstract class ScrollListener
    (var layoutManager: LinearLayoutManager) : RecyclerView.OnScrollListener() {

    abstract fun isNewLastPage(): Boolean

    abstract fun isOldLastPage(): Boolean

    abstract fun isLoading(): Boolean

    var scrollingUp = false

    override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
        super.onScrolled(recyclerView, dx, dy)
        val visibleItemCount = layoutManager.childCount
        val totalItemCount = layoutManager.itemCount
        val firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition()

        scrollingUp = when {
            dy > 0 -> {
                //Scrolling down
                Log.i("harshScroll", "scroll down!")
                false
            }
            dy < 0 -> {
                //Scrolling up
                Log.i("harshScroll", "scroll up!")
                true
            }
            else -> {
                scrollingUp
            }
        }

//        Log.v(
//            "harshScroll",
//            "visibleItemCount == $visibleItemCount, totalItemCount == $totalItemCount, firstVisibleItemPosition ==  $firstVisibleItemPosition"
//        )

        if (!isLoading()) {
            if (!isOldLastPage() && visibleItemCount + firstVisibleItemPosition >= totalItemCount && firstVisibleItemPosition >= 0) {
                Log.v("harshScroll", "loading more data")
                loadOldItems()
            } else if (!isNewLastPage() && firstVisibleItemPosition == 0 && !scrollingUp) {
                Log.v("harshScroll", "loading more old data")
                loadNewItems()
            }
        }
    }

    abstract fun loadOldItems()

    abstract fun loadNewItems()
}