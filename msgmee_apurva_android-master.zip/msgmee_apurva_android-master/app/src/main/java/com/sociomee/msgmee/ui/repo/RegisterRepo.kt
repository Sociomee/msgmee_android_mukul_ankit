package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.LoginApiCall
import com.sociomee.msgmee.ui.model.MessageResponse
import retrofit2.Response

class RegisterRepo {

    // api for sending otp
    fun sendOtpEmail(body: HashMap<String, Any>) : MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(LoginApiCall::class.java)
        val call = retrofitService.sendOtpEmail(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }

    fun checkEmailAvailability(body: HashMap<String, Any>) : MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(LoginApiCall::class.java)
        val call = retrofitService.checkEmailAvailability(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }

    fun checkMobileAvailability(body: HashMap<String, Any>) : MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(LoginApiCall::class.java)
        val call = retrofitService.checkMobileAvailability(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }
}