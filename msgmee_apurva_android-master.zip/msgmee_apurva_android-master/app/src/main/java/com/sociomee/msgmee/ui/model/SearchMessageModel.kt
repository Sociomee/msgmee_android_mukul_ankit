package com.sociomee.msgmee.ui.model

import com.google.gson.annotations.SerializedName

data class SearchMessageModel(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("successResult")
        val searchList: ArrayList<SearchMessageData>,
    )
}

data class SearchMessageData(
    @SerializedName("messageId")
    val messageId: String,
    @SerializedName("sequenceNo")
    val sequenceNo: Int
) : Comparable<SearchMessageData> {
    override fun compareTo(other: SearchMessageData): Int = this.sequenceNo.compareTo(other.sequenceNo)
}