package com.sociomee.msgmee.ui.adapter

import android.content.Intent
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import android.widget.SeekBar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.hasankucuk.socialtextview.SocialTextView
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomIconView
import com.sociomee.msgmee.custom.widget.CustomImageView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.activity.ChatMediaViewActivity
import com.sociomee.msgmee.ui.model.*
import com.sociomee.msgmee.utils.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe


//====================================MESSAGE VIEW-HOLDER====================================//
//====================================MESSAGE VIEW-HOLDER====================================//
class MyMessageHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_my_message_forward =
        itemView.findViewById<CustomTextView>(R.id.txt_my_message_forward)
    private val txt_my_message_child =
        itemView.findViewById<SocialTextView>(R.id.txt_my_message_child)
    private val txt_my_message_time =
        itemView.findViewById<CustomTextView>(R.id.txt_my_message_time)

    fun setHolderData(model: ChatModel) {
        txt_my_message_forward.visibility = if (model.isForwarded == 1 && model.isDeletedForAll == 0) {
            View.VISIBLE
        } else {
            View.GONE
        }

        txt_my_message_child.text = if (model.isDeletedForAll == 1) {
            itemView.context.getString(R.string.you_deleted_this_)
        } else {

            model.messageText.withBackgroundSpan(itemView.context)
        }
        txt_my_message_time.text = TimeAgo.getTimeAgo(model.createdAt)
        txt_my_message_forward.text = itemView.context.getString(R.string.forwarded)
    }
}

class MyMessageReplyHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_my_reply_username =
        itemView.findViewById<CustomTextView>(R.id.txt_my_reply_username)
    private val txt_my_reply_message =
        itemView.findViewById<SocialTextView>(R.id.txt_my_reply_message)
    private val txt_my_reply_new_message = itemView.findViewById<SocialTextView>(
        R.id.txt_my_reply_new_message
    )
    private val txt_my_reply_time = itemView.findViewById<CustomTextView>(R.id.txt_my_reply_time)
    private val cl_my_reply = itemView.findViewById<ConstraintLayout>(R.id.cl_my_reply)

    fun setHolderData(model: ChatModel) {
        txt_my_reply_username.text = model.senderUsername
        txt_my_reply_username.text = model.messageJson!!.replyMessageUsername
        txt_my_reply_message.text = model.messageJson.replyMessageText
        txt_my_reply_new_message.text = model.messageText.withBackgroundSpan(itemView.context)
        txt_my_reply_time.text = TimeAgo.getTimeAgo(model.createdAt)

        // detecting reply click
        cl_my_reply.setOnClickListener {
            EventBus.getDefault().post(MessageReplyModel(
                model.messageJson.replyMessageId!!,
                model.messageJson.replyMessageSequence,
            ))
        }
    }
}

class OtherMessageHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_other_message_forward = itemView.findViewById<CustomTextView>(
        R.id.txt_other_message_forward
    )
    private val txt_other_message_child = itemView.findViewById<SocialTextView>(
        R.id.txt_other_message_child
    )
    private val txt_other_message_time =
        itemView.findViewById<CustomTextView>(R.id.txt_other_message_time)
    private val txt_other_name = itemView.findViewById<CustomTextView>(R.id.txt_other_name)

    fun setHolderData(model: ChatModel) {
        txt_other_message_forward.visibility = if (model.isForwarded == 1 && model.isDeletedForAll == 0) {
             View.VISIBLE
        } else {
            View.GONE
        }

        if (model.isOneToOne) {
            txt_other_name.visibility = View.GONE
        } else {
            txt_other_name.visibility = View.VISIBLE
            txt_other_name.text = model.senderUsername
        }

        txt_other_message_child.text = if (model.isDeletedForAll == 1) {
            itemView.context.getString(R.string.this_messages_was_)
        } else {
            model.messageText.withBackgroundSpan(itemView.context)
        }

        txt_other_message_time.text = TimeAgo.getTimeAgo(model.createdAt)
        txt_other_message_forward.text = itemView.context.getString(R.string.forwarded)
    }
}

class OtherMessageReplyHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_other_reply_username = itemView.findViewById<CustomTextView>(
        R.id.txt_other_reply_username
    )
    private val txt_other_reply_message = itemView.findViewById<SocialTextView>(
        R.id.txt_other_reply_message
    )
    private val txt_other_reply_new_message = itemView.findViewById<SocialTextView>(
        R.id.txt_other_reply_new_message
    )
    private val txt_other_reply_time =
        itemView.findViewById<CustomTextView>(R.id.txt_other_reply_time)
    private val txt_other_name = itemView.findViewById<CustomTextView>(R.id.txt_other_name)
    private val cl_other_reply = itemView.findViewById<ConstraintLayout>(R.id.cl_other_reply)

    fun setHolderData(model: ChatModel) {
        txt_other_reply_username.text = model.messageJson!!.replyMessageUsername
        txt_other_reply_message.text = model.messageJson.replyMessageText
        txt_other_reply_new_message.text = model.messageText.withBackgroundSpan(itemView.context)
        txt_other_reply_time.text = TimeAgo.getTimeAgo(model.createdAt)

        if (model.isOneToOne) {
            txt_other_name.visibility = View.GONE
        } else {
            txt_other_name.visibility = View.VISIBLE
            txt_other_name.text = model.senderUsername
        }

        // detecting reply click
        cl_other_reply.setOnClickListener {
            EventBus.getDefault().post(MessageReplyModel(
                model.messageJson.replyMessageId!!,
                model.messageJson.replyMessageSequence,
            ))
        }
    }
}


//====================================MEDIA VIEW-HOLDER====================================//
//====================================MEDIA VIEW-HOLDER====================================//
class MyMediaHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val img_my_media = itemView.findViewById<CustomImageView>(R.id.img_my_media)
    private val img_my_media_play = itemView.findViewById<CustomImageView>(R.id.img_my_media_play)
    private val txt_my_media_time = itemView.findViewById<CustomTextView>(R.id.txt_my_media_time)

    fun setHolderData(model: ChatModel) {
        when (model.messageEnumType) {
            Constants.MessageType.MY_IMAGE -> {
                img_my_media_play.visibility = View.GONE

                Log.v("harsh", "mediaUrl = ${model.messageJson!!.mediaUrl.mediaFullUrl()}")
            }
            Constants.MessageType.MY_VIDEO -> {
                img_my_media_play.visibility = View.VISIBLE
                Glide.with(itemView.context).load(R.drawable.ic_messenger_play)
                    .into(img_my_media_play)
            }
            Constants.MessageType.MY_GIF -> {
                img_my_media_play.visibility = View.VISIBLE
                Glide.with(itemView.context).load(R.drawable.ic_gif).into(img_my_media_play)
            }
            else -> {
            }
        }

        Glide.with(itemView.context).load(model.messageJson!!.mediaUrl.mediaFullUrl())
            .into(img_my_media)
        txt_my_media_time.text = TimeAgo.getTimeAgo(model.createdAt)

        img_my_media.setOnClickListener {
            val intent = Intent(itemView.context, ChatMediaViewActivity::class.java)
            intent.putExtra("chatModel", Constants.myGson.toJson(model))
            itemView.context.startActivity(intent)
        }
    }
}

class MyMediaReplyHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_my_reply_media_time = itemView.findViewById<CustomTextView>(
        R.id.txt_my_reply_media_time
    )
    private val txt_my_reply_media_username = itemView.findViewById<CustomTextView>(
        R.id.txt_my_reply_media_username
    )
    private val txt_my_reply_media_message = itemView.findViewById<CustomTextView>(
        R.id.txt_my_reply_media_message
    )
    private val cl_my_reply_media = itemView.findViewById<ConstraintLayout>(
        R.id.cl_my_reply_media
    )
    private val img_my_reply_media_icon = itemView.findViewById<CustomIconView>(
        R.id.img_my_reply_media_icon
    )
    private val txt_my_reply_media_new_message = itemView.findViewById<SocialTextView>(
        R.id.txt_my_reply_media_new_message
    )
    private val img_my_reply_media = itemView.findViewById<CustomImageView>(
        R.id.img_my_reply_media
    )

    fun setHolderData(model: ChatModel) {
        txt_my_reply_media_message.text = when (model.messageEnumType) {
            Constants.MessageType.MY_IMAGE_REPLY -> {
                Glide.with(itemView.context).load(model.messageJson!!.replyMediaUrl.mediaFullUrl())
                    .into(img_my_reply_media)
                Glide.with(itemView.context).load(R.drawable.ic_image_icon)
                    .into(img_my_reply_media_icon)

                if (model.messageJson.replyMessageText!!.isNotEmpty()) {
                    model.messageJson.replyMessageText
                } else {
                    itemView.context.getString(R.string.image)
                }
            }
            Constants.MessageType.MY_CONTACT_REPLY -> {
                Glide.with(itemView.context).load(model.messageJson!!.replyMediaUrl.mediaFullUrl())
                    .placeholder(R.drawable.profile_placeholder)
                    .into(img_my_reply_media)
                Glide.with(itemView.context).load(R.drawable.ic_person)
                    .into(img_my_reply_media_icon)

                if (model.messageJson.replyMessageText!!.isNotEmpty()) {
                    model.messageJson.replyMessageText
                } else {
                    itemView.context.getString(R.string.contact)
                }
            }
            Constants.MessageType.MY_AUDIO_REPLY -> {
                Glide.with(itemView.context).load(R.drawable.ic_music)
                    .into(img_my_reply_media)
                Glide.with(itemView.context).load(R.drawable.ic_music)
                    .into(img_my_reply_media_icon)

                if (model.messageJson!!.replyMessageText!!.isNotEmpty()) {
                    model.messageJson.replyMessageText
                } else {
                    itemView.context.getString(R.string.audio)
                }
            }
            Constants.MessageType.MY_VIDEO_REPLY -> {
                Glide.with(itemView.context).load(model.messageJson!!.replyMediaUrl.mediaFullUrl())
                    .into(img_my_reply_media)
                Glide.with(itemView.context).load(R.drawable.ic_play)
                    .into(img_my_reply_media_icon)

                if (model.messageJson.replyMessageText!!.isNotEmpty()) {
                    model.messageJson.replyMessageText
                } else {
                    itemView.context.getString(R.string.video)
                }
            }
            Constants.MessageType.MY_GIF_REPLY -> {
                Glide.with(itemView.context).load(model.messageJson!!.replyMediaUrl.mediaFullUrl())
                    .into(img_my_reply_media)
                Glide.with(itemView.context).load(R.drawable.ic_gif)
                    .into(img_my_reply_media_icon)

                if (model.messageJson.replyMessageText!!.isNotEmpty()) {
                    model.messageJson.replyMessageText
                } else {
                    itemView.context.getString(R.string.gif)
                }
            }
            Constants.MessageType.MY_DOC_REPLY -> {
                Glide.with(itemView.context).load(model.messageJson!!.replyMediaUrl.mediaFullUrl())
                    .into(img_my_reply_media)
                Glide.with(itemView.context).load(R.drawable.ic_doc)
                    .into(img_my_reply_media_icon)

                if (model.messageJson.replyMessageText!!.isNotEmpty()) {
                    model.messageJson.replyMessageText
                } else {
                    itemView.context.getString(R.string.document)
                }
            }
            else -> {
                ""
            }
        }

        txt_my_reply_media_username.text = model.messageJson!!.replyMessageUsername
        txt_my_reply_media_new_message.text = model.messageText.withBackgroundSpan(itemView.context)
        txt_my_reply_media_time.text = TimeAgo.getTimeAgo(model.createdAt)

        // detecting reply click
        cl_my_reply_media.setOnClickListener {
            EventBus.getDefault().post(MessageReplyModel(
                model.messageJson.replyMessageId!!,
                model.messageJson.replyMessageSequence,
            ))
        }
    }
}

class MyMediaMessageHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_my_media_forward =
        itemView.findViewById<CustomTextView>(R.id.txt_my_media_forward)
    private val img_my_media_data = itemView.findViewById<CustomImageView>(R.id.img_my_media_data)
    private val img_my_media_play = itemView.findViewById<CustomImageView>(R.id.img_my_media_play)
    private val txt_my_media_message =
        itemView.findViewById<SocialTextView>(R.id.txt_my_media_message)
    private val txt_my_media_reply_time = itemView.findViewById<CustomTextView>(
        R.id.txt_my_media_reply_time
    )

    fun setHolderData(model: ChatModel) {
        when (model.messageEnumType) {
            Constants.MessageType.MY_IMAGE_MESSAGE -> {
                txt_my_media_forward.visibility = View.GONE
                img_my_media_play.visibility = View.GONE
            }
            Constants.MessageType.MY_VIDEO_MESSAGE -> {
                txt_my_media_forward.visibility = View.GONE
                img_my_media_play.visibility = View.VISIBLE

                Glide.with(itemView.context).load(R.drawable.ic_messenger_play)
                    .into(img_my_media_play)
            }
            Constants.MessageType.MY_GIF -> {
                txt_my_media_forward.visibility = View.GONE
                img_my_media_play.visibility = View.VISIBLE

                Glide.with(itemView.context).load(R.drawable.ic_messenger_play)
                    .into(img_my_media_play)
            }
            else -> {
            }
        }

        if (model.isForwarded == 1) {
            txt_my_media_forward.visibility = View.VISIBLE
        } else {
            txt_my_media_forward.visibility = View.GONE
        }

        Glide.with(itemView.context).load(model.messageJson!!.mediaUrl.mediaFullUrl()).into(
            img_my_media_data
        )
        txt_my_media_message.text = model.messageText.withBackgroundSpan(itemView.context)
        txt_my_media_reply_time.text = TimeAgo.getTimeAgo(model.createdAt)
        txt_my_media_forward.text = itemView.context.getString(R.string.forwarded)

        img_my_media_data.setOnClickListener {
            val intent = Intent(itemView.context, ChatMediaViewActivity::class.java)
            intent.putExtra("chatModel", Constants.myGson.toJson(model))
            itemView.context.startActivity(intent)
        }
    }
}

class OtherMediaHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val img_other_media = itemView.findViewById<CustomImageView>(R.id.img_other_media)
    private val img_other_media_play =
        itemView.findViewById<CustomImageView>(R.id.img_other_media_play)
    private val txt_other_media_time =
        itemView.findViewById<CustomTextView>(R.id.txt_other_media_time)

    fun setHolderData(model: ChatModel) {
        when (model.messageEnumType) {
            Constants.MessageType.OTHER_IMAGE -> {
                img_other_media_play.visibility = View.GONE
            }
            Constants.MessageType.OTHER_VIDEO -> {
                Glide.with(itemView.context).load(R.drawable.ic_messenger_play)
                    .into(img_other_media_play)
            }
            Constants.MessageType.OTHER_GIF -> {
                Glide.with(itemView.context).load(R.drawable.ic_gif).into(img_other_media_play)
            }
            else -> {
            }
        }

        Glide.with(itemView.context).load(model.messageJson!!.mediaUrl.mediaFullUrl()).into(
            img_other_media
        )
        txt_other_media_time.text = TimeAgo.getTimeAgo(model.createdAt)

        img_other_media.setOnClickListener {
            val intent = Intent(itemView.context, ChatMediaViewActivity::class.java)
            intent.putExtra("chatModel", Constants.myGson.toJson(model))
            itemView.context.startActivity(intent)
        }
    }
}

class OtherMediaMessageHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_other_media_forward = itemView.findViewById<CustomTextView>(
        R.id.txt_other_media_forward
    )
    private val txt_other_media_reply_time = itemView.findViewById<CustomTextView>(
        R.id.txt_other_media_reply_time
    )
    private val txt_other_media_message = itemView.findViewById<SocialTextView>(
        R.id.txt_other_media_message
    )
    private val img_other_media_play =
        itemView.findViewById<CustomImageView>(R.id.img_other_media_play)
    private val img_other_media = itemView.findViewById<CustomImageView>(R.id.img_other_media)
    private val txt_other_name = itemView.findViewById<CustomTextView>(R.id.txt_other_name)

    fun setHolderData(model: ChatModel) {
        when (model.messageEnumType) {
            Constants.MessageType.OTHER_IMAGE_MESSAGE -> {
                txt_other_media_forward.visibility = View.GONE
                img_other_media_play.visibility = View.GONE
            }
            Constants.MessageType.OTHER_VIDEO_MESSAGE -> {
                txt_other_media_forward.visibility = View.GONE
                img_other_media_play.visibility = View.VISIBLE

                Glide.with(itemView.context).load(R.drawable.ic_messenger_play)
                    .into(img_other_media_play)
            }
            Constants.MessageType.OTHER_GIF -> {
                txt_other_media_forward.visibility = View.GONE
                img_other_media_play.visibility = View.VISIBLE

                Glide.with(itemView.context).load(R.drawable.ic_messenger_play)
                    .into(img_other_media_play)
            }
            else -> {
            }
        }

        if (model.isForwarded == 1) {
            txt_other_media_forward.visibility = View.VISIBLE
        } else {
            txt_other_media_forward.visibility = View.GONE
        }

        if (model.isOneToOne) {
            txt_other_name.visibility = View.GONE
        } else {
            txt_other_name.visibility = View.VISIBLE
            txt_other_name.text = model.senderUsername
        }

        Glide.with(itemView.context).load(model.messageJson!!.mediaUrl.mediaFullUrl()).into(
            img_other_media
        )
        txt_other_media_message.text = model.messageText.withBackgroundSpan(itemView.context)
        txt_other_media_reply_time.text = TimeAgo.getTimeAgo(model.createdAt)
        txt_other_media_forward.text = itemView.context.getString(R.string.forwarded)

        img_other_media.setOnClickListener {
            val intent = Intent(itemView.context, ChatMediaViewActivity::class.java)
            intent.putExtra("chatModel", Constants.myGson.toJson(model))
            itemView.context.startActivity(intent)
        }
    }
}

class OtherMediaReplyHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_other_reply_media_username = itemView.findViewById<CustomTextView>(
        R.id.txt_other_reply_media_username
    )
    private val txt_other_reply_media_message = itemView.findViewById<CustomTextView>(
        R.id.txt_other_reply_media_message
    )
    private val txt_other_reply_media_new_message = itemView.findViewById<SocialTextView>(
        R.id.txt_other_reply_media_new_message
    )
    private val txt_other_reply_media_time = itemView.findViewById<CustomTextView>(
        R.id.txt_other_reply_media_time
    )
    private val img_other_reply_media_icon = itemView.findViewById<CustomIconView>(
        R.id.img_other_reply_media_icon
    )
    private val img_other_reply_media =
        itemView.findViewById<CustomImageView>(R.id.img_other_reply_media)
    private val txt_other_name = itemView.findViewById<CustomTextView>(R.id.txt_other_name)
    private val cl_other_reply_media = itemView.findViewById<ConstraintLayout>(R.id.cl_other_reply_media)

    fun setHolderData(model: ChatModel) {
        txt_other_reply_media_message.text = when (model.messageEnumType) {
            Constants.MessageType.MY_IMAGE_REPLY -> {
                Glide.with(itemView.context).load(model.messageJson!!.replyMediaUrl.mediaFullUrl())
                    .into(img_other_reply_media)
                Glide.with(itemView.context).load(R.drawable.ic_image_icon)
                    .into(img_other_reply_media_icon)

                if (model.messageJson.replyMessageText!!.isNotEmpty()) {
                    model.messageJson.replyMessageText
                } else {
                    itemView.context.getString(R.string.image)
                }
            }
            Constants.MessageType.MY_CONTACT_REPLY -> {
                Glide.with(itemView.context).load(model.messageJson!!.replyMediaUrl.mediaFullUrl())
                    .placeholder(R.drawable.profile_placeholder)
                    .into(img_other_reply_media)
                Glide.with(itemView.context).load(R.drawable.ic_person)
                    .into(img_other_reply_media_icon)

                if (model.messageJson.replyMessageText!!.isNotEmpty()) {
                    model.messageJson.replyMessageText
                } else {
                    itemView.context.getString(R.string.contact)
                }
            }
            Constants.MessageType.MY_AUDIO_REPLY -> {
                Glide.with(itemView.context).load(R.drawable.ic_music)
                    .into(img_other_reply_media)
                Glide.with(itemView.context).load(R.drawable.ic_music)
                    .into(img_other_reply_media_icon)

                if (model.messageJson!!.replyMessageText!!.isNotEmpty()) {
                    model.messageJson.replyMessageText
                } else {
                    itemView.context.getString(R.string.audio)
                }
            }
            Constants.MessageType.MY_VIDEO_REPLY -> {
                Glide.with(itemView.context).load(model.messageJson!!.replyMediaUrl.mediaFullUrl())
                    .into(img_other_reply_media)
                Glide.with(itemView.context).load(R.drawable.ic_play)
                    .into(img_other_reply_media_icon)

                if (model.messageJson.replyMessageText!!.isNotEmpty()) {
                    model.messageJson.replyMessageText
                } else {
                    itemView.context.getString(R.string.video)
                }
            }
            Constants.MessageType.MY_GIF_REPLY -> {
                Glide.with(itemView.context).load(model.messageJson!!.replyMediaUrl.mediaFullUrl())
                    .into(img_other_reply_media)
                Glide.with(itemView.context).load(R.drawable.ic_gif)
                    .into(img_other_reply_media_icon)

                if (model.messageJson.replyMessageText!!.isNotEmpty()) {
                    model.messageJson.replyMessageText
                } else {
                    itemView.context.getString(R.string.gif)
                }
            }
            Constants.MessageType.MY_DOC_REPLY -> {
                Glide.with(itemView.context).load(model.messageJson!!.replyMediaUrl.mediaFullUrl())
                    .into(img_other_reply_media)
                Glide.with(itemView.context).load(R.drawable.ic_doc)
                    .into(img_other_reply_media_icon)

                if (model.messageJson.replyMessageText!!.isNotEmpty()) {
                    model.messageJson.replyMessageText
                } else {
                    itemView.context.getString(R.string.document)
                }
            }
            else -> {
                ""
            }
        }

        if (model.isOneToOne) {
            txt_other_name.visibility = View.GONE
        } else {
            txt_other_name.visibility = View.VISIBLE
            txt_other_name.text = model.senderUsername
        }

        txt_other_reply_media_username.text = model.messageJson!!.replyMessageUsername
        txt_other_reply_media_new_message.text =
            model.messageText.withBackgroundSpan(itemView.context)
        txt_other_reply_media_time.text = TimeAgo.getTimeAgo(model.createdAt)

        // detecting reply click
        cl_other_reply_media.setOnClickListener {
            EventBus.getDefault().post(MessageReplyModel(
                model.messageJson.replyMessageId!!,
                model.messageJson.replyMessageSequence,
            ))
        }
    }
}


//====================================CONTACT VIEW-HOLDER====================================//
//====================================CONTACT VIEW-HOLDER====================================//
class MyContactHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_my_contact_forward =
        itemView.findViewById<CustomTextView>(R.id.txt_my_contact_forward)
    private val txt_my_contact_name =
        itemView.findViewById<CustomTextView>(R.id.txt_my_contact_name)
    private val txt_my_contact_number =
        itemView.findViewById<CustomTextView>(R.id.txt_my_contact_number)
    private val txt_my_contact_add = itemView.findViewById<CustomTextView>(R.id.txt_my_contact_add)
    private val txt_my_contact_time =
        itemView.findViewById<CustomTextView>(R.id.txt_my_contact_time)
    private val txt_my_contact_message =
        itemView.findViewById<SocialTextView>(R.id.txt_my_contact_message)
    private val img_my_contact = itemView.findViewById<CustomImageView>(R.id.img_my_contact)

    fun setHolderData(model: ChatModel) {
        if (model.isForwarded == 1) {
            txt_my_contact_forward.visibility = View.VISIBLE
        } else {
            txt_my_contact_forward.visibility = View.GONE
        }

        if (model.messageText.isNotEmpty()) {
            txt_my_contact_message.text = model.messageText.withBackgroundSpan(itemView.context)
            txt_my_contact_message.visibility = View.VISIBLE
        } else {
            txt_my_contact_message.visibility = View.GONE
        }

        Glide.with(itemView.context).load(model.messageJson!!.mediaUrl.mediaFullUrl())
            .placeholder(R.drawable.profile_placeholder).into(
                img_my_contact
            )
        txt_my_contact_add.text = itemView.context.getString(R.string.add_to_contacts)
        txt_my_contact_name.text = model.messageJson.contactName
        txt_my_contact_number.text = model.messageJson.contactNumber
        txt_my_contact_time.text = TimeAgo.getTimeAgo(model.createdAt)
        txt_my_contact_forward.text = itemView.context.getString(R.string.forwarded)

        txt_my_contact_add.setOnClickListener {
            Constants.saveContact(
                itemView.context,
                model.messageJson.contactName,
                model.messageJson.contactNumber,
                img_my_contact.toBitmap()
            )
        }
    }
}

class OtherContactHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_other_contact_forward = itemView.findViewById<CustomTextView>(
        R.id.txt_other_contact_forward
    )
    private val img_other_contact = itemView.findViewById<CustomImageView>(R.id.img_other_contact)
    private val txt_other_contact_name =
        itemView.findViewById<CustomTextView>(R.id.txt_other_contact_name)
    private val txt_other_contact_number =
        itemView.findViewById<CustomTextView>(R.id.txt_other_contact_number)
    private val txt_other_contact_add =
        itemView.findViewById<CustomTextView>(R.id.txt_other_contact_add)
    private val txt_other_contact_time =
        itemView.findViewById<CustomTextView>(R.id.txt_other_contact_time)
    private val txt_other_contact_message = itemView.findViewById<SocialTextView>(
        R.id.txt_other_contact_message
    )
    private val txt_other_name = itemView.findViewById<CustomTextView>(R.id.txt_other_name)

    fun setHolderData(model: ChatModel) {
        if (model.isForwarded == 1) {
            txt_other_contact_forward.visibility = View.VISIBLE
        } else {
            txt_other_contact_forward.visibility = View.GONE
        }

        if (model.isOneToOne) {
            txt_other_name.visibility = View.GONE
        } else {
            txt_other_name.visibility = View.VISIBLE
            txt_other_name.text = model.senderUsername
        }

        if (model.messageText.isNotEmpty()) {
            txt_other_contact_message.text = model.messageText.withBackgroundSpan(itemView.context)
            txt_other_contact_message.visibility = View.VISIBLE
        } else {
            txt_other_contact_message.visibility = View.GONE
        }

        Glide.with(itemView.context).load(model.messageJson!!.mediaUrl.mediaFullUrl())
            .placeholder(R.drawable.profile_placeholder).into(
                img_other_contact
            )
        txt_other_contact_add.text = itemView.context.getString(R.string.add_to_contacts)
        txt_other_contact_name.text = model.messageJson.contactName
        txt_other_contact_number.text = model.messageJson.contactNumber
        txt_other_contact_time.text = TimeAgo.getTimeAgo(model.createdAt)
        txt_other_contact_forward.text = itemView.context.getString(R.string.forwarded)

        txt_other_contact_add.setOnClickListener {
            Constants.saveContact(
                itemView.context,
                model.messageJson.contactName,
                model.messageJson.contactNumber,
                img_other_contact.toBitmap()
            )
        }
    }
}


//====================================AUDIO VIEW-HOLDER====================================//
//====================================AUDIO VIEW-HOLDER====================================//
class MyAudioHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_my_audio_forward =
        itemView.findViewById<CustomTextView>(R.id.txt_my_audio_forward)
    private val audio_my_seek_bar = itemView.findViewById<SeekBar>(R.id.audio_my_seek_bar)
    private val img_my_audio = itemView.findViewById<CustomImageView>(R.id.img_my_audio)
    private val txt_my_audio_name = itemView.findViewById<CustomTextView>(R.id.txt_my_audio_name)
    private val txt_my_audio_duration =
        itemView.findViewById<CustomTextView>(R.id.txt_my_audio_duration)
    private val txt_my_audio_size = itemView.findViewById<CustomTextView>(R.id.txt_my_audio_size)
    private val txt_my_audio_time = itemView.findViewById<CustomTextView>(R.id.txt_my_audio_time)
    private val pb_my_audio = itemView.findViewById<ProgressBar>(R.id.pb_my_audio)
    private val txt_my_audio_message =
        itemView.findViewById<SocialTextView>(R.id.txt_my_audio_message)
    private var chatModel: ChatModel? = null

    fun setHolderData(model: ChatModel) {
        chatModel = model
        if (model.isForwarded == 1) {
            txt_my_audio_forward.visibility = View.VISIBLE
        } else {
            txt_my_audio_forward.visibility = View.GONE
        }

        if (model.messageText.isNotEmpty()) {
            txt_my_audio_message.text = model.messageText.withBackgroundSpan(itemView.context)
            txt_my_audio_message.visibility = View.VISIBLE
        } else {
            txt_my_audio_message.visibility = View.GONE
        }

        txt_my_audio_duration.text =
            model.messageJson?.mediaDuration ?: itemView.context.getString(R.string.unknown)
        txt_my_audio_name.text =
            model.messageJson?.mediaName ?: itemView.context.getString(R.string.unknown)
        txt_my_audio_time.text = TimeAgo.getTimeAgo(model.createdAt)
        txt_my_audio_size.text =
            model.messageJson?.mediaSize ?: itemView.context.getString(R.string.unknown)
        txt_my_audio_forward.text = itemView.context.getString(R.string.forwarded)

        // processing audio
        img_my_audio.setMediaImage(itemView.context, model.playMedia)
        img_my_audio.setOnClickListener {
            // sending data using event bus
            model.playMedia = !model.playMedia
            EventBus.getDefault().post(
                MediaPlayModel(
                    model, audio_my_seek_bar, pb_my_audio, img_my_audio
                )
            )
            img_my_audio.setMediaImage(itemView.context, model.playMedia)
        }
        audio_my_seek_bar.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seek: SeekBar,
                progress: Int, fromUser: Boolean
            ) {
            }

            override fun onStartTrackingTouch(seek: SeekBar) {}

            override fun onStopTrackingTouch(seek: SeekBar) {
                model.playMedia = true
                EventBus.getDefault().post(
                    MediaPlayModel(
                        model, audio_my_seek_bar, pb_my_audio, img_my_audio, seek.progress
                    )
                )
                img_my_audio.setMediaImage(itemView.context, model.playMedia)
            }
        })
    }

    @Suppress("unused")
    @Subscribe
    fun updateAudioPlayUI(myAudioChange: MyAudioChange) {
        if(chatModel != null && chatModel!!.messageId == myAudioChange.messageId) {
            when (myAudioChange.type) {
                "reset" -> {
                    audio_my_seek_bar.progress = 0
                    pb_my_audio.visibility = View.GONE
                    img_my_audio.visibility = View.VISIBLE
                }
                "loadingChanged" -> {
                    pb_my_audio.visibility =
                        if (myAudioChange.isLoading) View.VISIBLE else View.GONE
                    img_my_audio.visibility =
                        if (myAudioChange.isLoading) View.GONE else View.VISIBLE
                }
                else -> {
                    audio_my_seek_bar.progress = myAudioChange.progress
                }
            }
        }
    }
}

class OtherAudioHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_other_audio_forward = itemView.findViewById<CustomTextView>(
        R.id.txt_other_audio_forward
    )
    private val audio_other_seek_bar =
        itemView.findViewById<SeekBar>(R.id.audio_other_seek_bar)
    private val img_other_audio = itemView.findViewById<CustomImageView>(R.id.img_other_audio)
    private val txt_other_audio_name =
        itemView.findViewById<CustomTextView>(R.id.txt_other_audio_name)
    private val txt_other_audio_duration = itemView.findViewById<CustomTextView>(
        R.id.txt_other_audio_duration
    )
    private val txt_other_audio_size =
        itemView.findViewById<CustomTextView>(R.id.txt_other_audio_size)
    private val txt_other_audio_time =
        itemView.findViewById<CustomTextView>(R.id.txt_other_audio_time)
    private val txt_other_audio_message = itemView.findViewById<SocialTextView>(
        R.id.txt_other_audio_message
    )
    private val txt_other_name = itemView.findViewById<CustomTextView>(R.id.txt_other_name)
    private val pb_other_audio = itemView.findViewById<ProgressBar>(R.id.pb_other_audio)
    private var chatModel: ChatModel? = null

    fun setHolderData(model: ChatModel) {
        chatModel = model
        if (model.isForwarded == 1) {
            txt_other_audio_forward.visibility = View.VISIBLE
        } else {
            txt_other_audio_forward.visibility = View.GONE
        }

        if (model.isOneToOne) {
            txt_other_name.visibility = View.GONE
        } else {
            txt_other_name.visibility = View.VISIBLE
            txt_other_name.text = model.senderUsername
        }

        if (model.messageText.isNotEmpty()) {
            txt_other_audio_message.text = model.messageText.withBackgroundSpan(itemView.context)
            txt_other_audio_message.visibility = View.VISIBLE
        } else {
            txt_other_audio_message.visibility = View.GONE
        }

        txt_other_audio_duration.text =
            model.messageJson?.mediaDuration ?: itemView.context.getString(R.string.unknown)
        txt_other_audio_name.text =
            model.messageJson?.mediaName ?: itemView.context.getString(R.string.unknown)
        txt_other_audio_time.text = TimeAgo.getTimeAgo(model.createdAt)
        txt_other_audio_size.text =
            model.messageJson?.mediaSize ?: itemView.context.getString(R.string.unknown)
        txt_other_audio_forward.text = itemView.context.getString(R.string.forwarded)

        // processing audio
        img_other_audio.setMediaImage(itemView.context, model.playMedia)
        img_other_audio.setOnClickListener {
            // sending data using event bus
            model.playMedia = !model.playMedia
            EventBus.getDefault().post(
                MediaPlayModel(
                    model, audio_other_seek_bar, pb_other_audio, img_other_audio
                )
            )
            img_other_audio.setMediaImage(itemView.context, model.playMedia)
        }
        audio_other_seek_bar.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seek: SeekBar,
                progress: Int, fromUser: Boolean
            ) {
            }

            override fun onStartTrackingTouch(seek: SeekBar) {}

            override fun onStopTrackingTouch(seek: SeekBar) {
                model.playMedia = true
                EventBus.getDefault().post(
                    MediaPlayModel(
                        model, audio_other_seek_bar, pb_other_audio, img_other_audio, seek.progress
                    )
                )
                img_other_audio.setMediaImage(itemView.context, model.playMedia)
            }
        })
    }

    @Suppress("unused")
    @Subscribe
    fun updateAudioPlayUI(myAudioChange: MyAudioChange) {
        if(chatModel != null && chatModel!!.messageId == myAudioChange.messageId) {
            when (myAudioChange.type) {
                "reset" -> {
                    audio_other_seek_bar.progress = 0
                    pb_other_audio.visibility = View.GONE
                    img_other_audio.visibility = View.VISIBLE
                }
                "loadingChanged" -> {
                    pb_other_audio.visibility =
                        if (myAudioChange.isLoading) View.VISIBLE else View.GONE
                    img_other_audio.visibility =
                        if (myAudioChange.isLoading) View.GONE else View.VISIBLE
                }
                else -> {
                    audio_other_seek_bar.progress = myAudioChange.progress
                }
            }
        }
    }
}


//====================================DOC VIEW-HOLDER====================================//
//====================================DOC VIEW-HOLDER====================================//
class MyDocHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_my_doc_forward = itemView.findViewById<CustomTextView>(R.id.txt_my_doc_forward)
    private val txt_my_doc_size = itemView.findViewById<CustomTextView>(R.id.txt_my_doc_size)
    private val txt_my_doc_download =
        itemView.findViewById<CustomTextView>(R.id.txt_my_doc_download)
    private val txt_my_doc_name = itemView.findViewById<CustomTextView>(R.id.txt_my_doc_name)
    private val pb_download = itemView.findViewById<ProgressBar>(R.id.pb_download)
    private val txt_my_doc_message = itemView.findViewById<SocialTextView>(R.id.txt_my_doc_message)
    private val txt_my_doc_time = itemView.findViewById<CustomTextView>(R.id.txt_my_doc_time)
    private val img_my_doc = itemView.findViewById<CustomImageView>(R.id.img_my_doc)

    fun setHolderData(model: ChatModel) {
        if (model.isForwarded == 1) {
            txt_my_doc_forward.visibility = View.VISIBLE
        } else {
            txt_my_doc_forward.visibility = View.GONE
        }

        if (model.messageText.isNotEmpty()) {
            txt_my_doc_message.text = model.messageText.withBackgroundSpan(itemView.context)
            txt_my_doc_message.visibility = View.VISIBLE
        } else {
            txt_my_doc_message.visibility = View.GONE
        }

        if (model.isDownloading) {
            img_my_doc.visibility = View.INVISIBLE
            pb_download.visibility = View.VISIBLE
        } else {
            pb_download.visibility = View.GONE
            img_my_doc.visibility = View.VISIBLE
        }

        pb_download.visibility = View.GONE
        Glide.with(itemView.context).load(R.drawable.ic_doc).into(img_my_doc)
        txt_my_doc_name.text =
            model.messageJson?.mediaName ?: itemView.context.getString(R.string.unknown)
        txt_my_doc_time.text = TimeAgo.getTimeAgo(model.createdAt)
        txt_my_doc_size.text =
            model.messageJson?.mediaSize ?: itemView.context.getString(R.string.unknown)
        txt_my_doc_download.text = itemView.context.getString(R.string.download)
        txt_my_doc_forward.text = itemView.context.getString(R.string.forwarded)

        itemView.setOnClickListener {
            img_my_doc.visibility = View.INVISIBLE
            pb_download.visibility = View.VISIBLE
            pb_download.progress = 1
            model.isDownloading = true
            EventBus.getDefault().post(
                FileDownloadModel(
                    model.messageId,
                    model.messageJson?.mediaName ?: "file",
                    model.messageJson!!.mediaUrl!!,
                    pb_download
                )
            )
        }
    }
}

class OtherDocHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_other_doc_forward =
        itemView.findViewById<CustomTextView>(R.id.txt_other_doc_forward)
    private val txt_other_doc_size = itemView.findViewById<CustomTextView>(R.id.txt_other_doc_size)
    private val txt_other_doc_download =
        itemView.findViewById<CustomTextView>(R.id.txt_other_doc_download)
    private val txt_other_doc_name = itemView.findViewById<CustomTextView>(R.id.txt_other_doc_name)
    private val txt_other_doc_message =
        itemView.findViewById<SocialTextView>(R.id.txt_other_doc_message)
    private val img_other_doc = itemView.findViewById<CustomImageView>(R.id.img_other_doc)
    private val txt_other_doc_time = itemView.findViewById<CustomTextView>(R.id.txt_other_doc_time)
    private val txt_other_name = itemView.findViewById<CustomTextView>(R.id.txt_other_name)
    private val pb_download = itemView.findViewById<ProgressBar>(R.id.pb_download)

    fun setHolderData(model: ChatModel) {
        if (model.isForwarded == 1) {
            txt_other_doc_forward.visibility = View.VISIBLE
        } else {
            txt_other_doc_forward.visibility = View.GONE
        }

        if (model.isOneToOne) {
            txt_other_name.visibility = View.GONE
        } else {
            txt_other_name.visibility = View.VISIBLE
            txt_other_name.text = model.senderUsername
        }

        if (model.messageText.isNotEmpty()) {
            txt_other_doc_message.text = model.messageText.withBackgroundSpan(itemView.context)
            txt_other_doc_message.visibility = View.VISIBLE
        } else {
            txt_other_doc_message.visibility = View.GONE
        }

        Glide.with(itemView.context).load(R.drawable.ic_doc).into(img_other_doc)
        txt_other_doc_name.text =
            model.messageJson?.mediaName ?: itemView.context.getString(R.string.unknown)
        txt_other_doc_time.text = TimeAgo.getTimeAgo(model.createdAt)
        txt_other_doc_size.text =
            model.messageJson?.mediaSize ?: itemView.context.getString(R.string.unknown)
        txt_other_doc_download.text = itemView.context.getString(R.string.download)
        txt_other_doc_forward.text = itemView.context.getString(R.string.forwarded)

        itemView.setOnClickListener {
            img_other_doc.visibility = View.INVISIBLE
            pb_download.visibility = View.VISIBLE
            pb_download.progress = 1
            model.isDownloading = true
            EventBus.getDefault().post(
                FileDownloadModel(
                    model.messageId,
                    model.messageJson?.mediaName ?: "file",
                    model.messageJson!!.mediaUrl!!,
                    pb_download
                )
            )
        }
    }
}


class ChatBubbleHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_chat_detail = itemView.findViewById<CustomTextView>(R.id.txt_chat_bubble)

    fun setHolderData(model: ChatModel) {
        val bubbleMessage = when (model.messageJson!!.type) {
            "leftGroup" -> "${
                Constants.getUsername(
                    itemView.context,
                    model.messageJson.leftUserName
                )
            } ${
                itemView.context.getString(
                    R.string.left_this_group
                )
            }"
            "memberRemoved" -> "${
                Constants.getUsername(
                    itemView.context,
                    model.messageJson.removedByUserName
                )
            } ${
                itemView.context.getString(
                    R.string.added
                )
            } ${Constants.getUsername(itemView.context, model.messageJson.removedUserName)}"
            "addedToGroup" -> "${
                Constants.getUsername(
                    itemView.context,
                    model.messageJson.addedByUserName
                )
            } ${
                itemView.context.getString(
                    R.string.added
                )
            } ${Constants.getUsername(itemView.context, model.messageJson.addedUserName)}"
            "groupCreated" -> "${
                Constants.getUsername(
                    itemView.context,
                    model.messageJson.createdByUserName
                )
            } ${
                itemView.context.getString(
                    R.string.created_this_group
                )
            }"
            "createdBroadcastList" -> itemView.context.getString(R.string.you_created_a_broadcast_)
            else -> ""
        }

        txt_chat_detail.text = bubbleMessage
    }
}


class UnreadBubbleHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    private val txt_unread_bubble = itemView.findViewById<CustomTextView>(R.id.txt_unread_bubble)

    fun setHolderData(model: ChatModel) {
        txt_unread_bubble.text = if (model.messageEnumType == Constants.MessageType.UNREAD_BUBBLE) {
             itemView.context.getString(R.string.unread_messages)
        } else {
            itemView.context.getString(R.string.unread_messages)
        }
    }
}
