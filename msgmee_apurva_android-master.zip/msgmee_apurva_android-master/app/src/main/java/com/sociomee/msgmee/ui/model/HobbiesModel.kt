package com.sociomee.msgmee.ui.model

import com.google.gson.annotations.SerializedName

data class HobbiesModel(
        @SerializedName("data")
        val hobbiesData: HobbiesData,
        @SerializedName("error")
        val error: Boolean,
        @SerializedName("success")
        val success: Boolean
) {
    data class HobbiesData(
            @SerializedName("successResult")
            val successResult: SuccessResult
    ) {

        data class SuccessResult(
                @SerializedName("count")
                val count: Int,
                @SerializedName("rows")
                val hobbyLists: List<HobbyList>
        )

        data class HobbyList(
                @SerializedName("id")
                val id: String,
                @SerializedName("name")
                val name: String,
                var isSelected: Boolean = false
        )
    }
}

