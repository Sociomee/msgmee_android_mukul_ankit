package com.sociomee.msgmee.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.`interface`.LanguageSelectCallback

class UsernameSuggestionAdaptor(private var suggestionList: List<String>,
                                private val languageSelectCallback: LanguageSelectCallback) :
        RecyclerView.Adapter<UsernameSuggestionAdaptor.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
            LayoutInflater.from(parent.context)
                    .inflate(R.layout.user_credential_name_suggestion_child, parent, false))

    override fun getItemCount() = suggestionList.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.txt_suggestion.text = suggestionList[position]

        holder.itemView.setOnClickListener {
            languageSelectCallback.languageSelectCallback(position)
        }
    }

    fun updateData(suggestionData: List<String>) {
        suggestionList = suggestionData
        notifyDataSetChanged()
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txt_suggestion = itemView.findViewById<CustomTextView>(R.id.txt_suggestion)
    }

}