package com.sociomee.msgmee.ui.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.activity.FriendListActivity
import com.sociomee.msgmee.ui.adapter.CallsListAdapter
import com.sociomee.msgmee.ui.model.CallHistoryData
import com.sociomee.msgmee.ui.model.ChatHeadSearched
import com.sociomee.msgmee.ui.viewmodel.CallHistoryVM
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.ScrollListener
import com.sociomee.msgmee.utils.processCallMessage
import kotlinx.android.synthetic.main.chat_head_list_fragment.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe

class CallsListFragment : Fragment(R.layout.chat_head_list_fragment) {

    private val callList = ArrayList<CallHistoryData>()
    private lateinit var callListAdapter : CallsListAdapter
    private lateinit var callHistoryVM: CallHistoryVM
    private var pageIndex = 0
    private var isLastPage = false
    private var isLoading = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setInitialLanguage()
        initData()
        observeData()
        setViewClicks()
    }

    private fun initData() {
        callHistoryVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            CallHistoryVM::class.java
        )

        callListAdapter = CallsListAdapter(callList)
        val layoutManager = LinearLayoutManager(context)
        rl_message_list.layoutManager = layoutManager
        rl_message_list.adapter = callListAdapter
        callListAdapter.notifyDataSetChanged()

        // adding scroll listener for pagination
        rl_message_list.addOnScrollListener(object : ScrollListener(layoutManager) {
            override fun isNewLastPage() = true
            override fun isOldLastPage() = isLastPage
            override fun isLoading() = isLoading
            override fun loadNewItems() {}

            override fun loadOldItems() {
                isLoading = true
                pageIndex++
                fetchCallHistoryList(
                    isRefresh = false,
                    searchText = ""
                )
            }
        })

        // initial view
        cl_empty.visibility = View.GONE
        rl_message_list.visibility = View.VISIBLE
        callListAdapter.notifyDataSetChanged()
        group_multi_select_toolbar.visibility = View.GONE
        Glide.with(context!!).load(R.drawable.ic_call_empty).into(img_empty)
    }

    private fun observeData() {
        callHistoryVM.observeCallHistoryList().observe(this, Observer {
            isLoading = false
            if (it.isRefresh) {
                callList.clear()
            }
            if(it.successResult.callHistoryList.isEmpty()) {
                isLastPage = true
            } else {
                it.successResult.callHistoryList.processCallMessage(context!!)
                isLastPage = false

                callList.addAll(it.successResult.callHistoryList)
            }

            bindData()
        })
        fetchCallHistoryList()

        observeError()
    }

    private fun fetchCallHistoryList(isRefresh: Boolean = true, searchText: String = "") {
        if (isRefresh)
            pageIndex = 0
        val body: HashMap<String, Any> = hashMapOf(
            "searchKey" to searchText,
            "pageIndex" to pageIndex,
            "pageSize" to Constants.globalPageSize
        )
        callHistoryVM.fetchCallHistoryList(
            body,
            isRefresh = isRefresh
        )
    }

    private fun observeError() {
        callHistoryVM.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    (activity as CustomAppCompatActivity).showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    (activity as CustomAppCompatActivity).showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    (activity as CustomAppCompatActivity).showToast("Server Error")
                }
                else -> {
                }
            }
        })
    }

    private fun setViewClicks() {
        txt_add.setOnClickListener {
            val intent = Intent(context, FriendListActivity::class.java)
            intent.putExtra("type", Constants.PeopleSelectType.CALL)
            startActivity(intent)
        }
    }

    private fun bindData() {
        if (callList.size == 0) {
            rl_message_list.visibility = View.GONE
            cl_empty.visibility = View.VISIBLE
            txt_empty_title.text = getString(R.string.no_calls)
            txt_empty_description.text = getString(R.string.you_dont_have_call_)
            txt_add.text = getString(R.string.call_someone)
        } else {
            cl_empty.visibility = View.GONE
            rl_message_list.visibility = View.VISIBLE
            callListAdapter.notifyDataSetChanged()
        }
        group_multi_select_toolbar.visibility = View.GONE
    }

    private fun setInitialLanguage() {

    }

    @Suppress("unused")
    @Subscribe
    fun chatHeadSearched(searchData: ChatHeadSearched) {
        Log.v("harsh", "searchData == ${searchData.searchText}")
        fetchCallHistoryList( searchText = searchData.searchText.trim())
    }

    override fun onStart() {
        super.onStart()
        // fetching chatHead list data
        EventBus.getDefault().register(this)
    }

    override fun onStop() {
        super.onStop()
        EventBus.getDefault().unregister(this)
    }

}