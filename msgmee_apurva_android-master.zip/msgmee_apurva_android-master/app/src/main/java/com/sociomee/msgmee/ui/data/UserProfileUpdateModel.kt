package com.sociomee.msgmee.ui.data


import com.google.gson.annotations.SerializedName

data class UserProfileUpdateModel(
        @SerializedName("data")
    val userProfileUpdateData: UserProfileUpdateData,
        @SerializedName("error")
    val error: Boolean,
        @SerializedName("success")
    val success: Boolean
) {
    data class UserProfileUpdateData(
        @SerializedName("successResult")
        val successResult: String
    )
}