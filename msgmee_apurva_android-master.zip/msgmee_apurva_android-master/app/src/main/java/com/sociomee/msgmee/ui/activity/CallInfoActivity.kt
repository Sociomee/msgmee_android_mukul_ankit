package com.sociomee.msgmee.ui.activity

import android.os.Bundle
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.adapter.CallInfoAdapter
import com.sociomee.msgmee.ui.model.CallHistoryData
import com.sociomee.msgmee.ui.model.StartCallModel
import com.sociomee.msgmee.ui.model.UserDataPassModel
import com.sociomee.msgmee.ui.viewmodel.CallHistoryVM
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.ScrollListener
import com.sociomee.msgmee.utils.processCallMessage
import kotlinx.android.synthetic.main.call_info_activity.*

class CallInfoActivity : CustomAppCompatActivity() {

    private val callList = ArrayList<CallHistoryData>()
    private lateinit var callHistoryVM: CallHistoryVM
    private lateinit var callInfoAdapter: CallInfoAdapter
    private var pageIndex = 0
    private var isLastPage = false
    private var isLoading = false
    private lateinit var userData: UserDataPassModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.call_info_activity)

        val data = intent?.extras?.getString("userData", "") ?: ""
        if(data.isEmpty()){
            showToast()
            finish()
        }
        userData = Constants.myGson.fromJson(data, UserDataPassModel::class.java)

        setViewsClick()
        bindData()
        initData()
        observeData()
    }

    private fun setViewsClick() {
        img_toolbar_back.setOnClickListener {
            onBackPressed()
        }
        img_video_call.setOnClickListener {
            Constants.startCall(
                this, true, StartCallModel(
                    userData.username,
                    userData.username,
                    userData.userId,
                    userData.profileThumb
                )
            )
        }
        img_audio_call.setOnClickListener {
            Constants.startCall(
                this, false, StartCallModel(
                    userData.username,
                    userData.username,
                    userData.userId,
                    userData.profileThumb
                )
            )
        }
        img_message.setOnClickListener {
//            startActivity(ChatActivity::class.java)
        }
    }

    private fun initData() {
        callHistoryVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            CallHistoryVM::class.java
        )
    }

    private fun observeData() {
        callHistoryVM.observeCallHistoryList().observe(this, Observer {
            isLoading = false
            if (it.isRefresh) {
                callList.clear()
            }
            if(it.successResult.callHistoryList.isEmpty()) {
                isLastPage = true
            } else {
                it.successResult.callHistoryList.processCallMessage(this)
                isLastPage = false

                callList.addAll(it.successResult.callHistoryList)
            }

            bindData()
        })
        fetchCallHistoryList()

        observeError()
    }

    private fun fetchCallHistoryList(isRefresh: Boolean = true, searchText: String = "") {
        if (isRefresh)
            pageIndex = 0
        val body: HashMap<String, Any> = hashMapOf(
            "otherUserId" to userData.userId,
            "searchKey" to searchText,
            "pageIndex" to pageIndex,
            "pageSize" to Constants.globalPageSize
        )
        callHistoryVM.fetchCallHistoryList(
            body,
            isRefresh = isRefresh
        )
    }

    private fun observeError() {
        callHistoryVM.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    showToast("Server Error")
                }
                else -> {
                }
            }
        })
    }

    override fun setInitialLanguage() {
        txt_chat_head_name.text = getString(R.string.call_info)
    }

    override fun bindData() {
        txt_call_info_name.text = userData.username
        cv_online_circle.visibility = View.GONE
        Glide.with(this).load(userData.profileThumb).placeholder(R.drawable.profile_placeholder).into(img_messenger_profile)

        callInfoAdapter = CallInfoAdapter(callList)
        val layoutManager = LinearLayoutManager(this)
        rl_call_info.layoutManager = layoutManager
        rl_call_info.adapter = callInfoAdapter

        // adding scroll listener for pagination
        rl_call_info.addOnScrollListener(object : ScrollListener(layoutManager) {
            override fun isNewLastPage() = true
            override fun isOldLastPage() = isLastPage
            override fun isLoading() = isLoading
            override fun loadNewItems() {}

            override fun loadOldItems() {
                isLoading = true
                pageIndex++
                fetchCallHistoryList(
                    isRefresh = false,
                    searchText = ""
                )
            }
        })
    }

}