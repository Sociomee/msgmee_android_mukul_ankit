package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.ApiCall
import com.sociomee.msgmee.ui.model.LanguageList
import com.sociomee.msgmee.ui.model.LanguageModel
import retrofit2.Response

class LanguageRepo {

    fun fetchLanguageList() : MutableLiveData<MyResponse<List<LanguageList>>> {
        val data = MutableLiveData<MyResponse<List<LanguageList>>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.getLanguageList()

        call.enqueue(object : MyCallback<LanguageModel> {
            override fun success(response: Response<LanguageModel>) {
                data.postValue(MyResponse.success(response.body()!!.languageData.successResult.languageList))
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }
        })
        return data
    }

}