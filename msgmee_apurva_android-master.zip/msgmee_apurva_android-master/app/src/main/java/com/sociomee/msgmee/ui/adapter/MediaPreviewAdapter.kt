package com.sociomee.msgmee.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomImageView
import com.sociomee.msgmee.ui.`interface`.SingleItemCallback
import com.sociomee.msgmee.ui.model.MediaPreviewModel
import java.io.File

class MediaPreviewAdapter(private val mediaList: ArrayList<MediaPreviewModel>, private val singleItemCallback: SingleItemCallback) :
    RecyclerView.Adapter<MediaPreviewAdapter.MediaPreviewHolder>() {

    var selectedPosition = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = MediaPreviewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.media_preview_child, parent, false)
    )

    override fun onBindViewHolder(holder: MediaPreviewHolder, position: Int) {
        Glide.with(holder.itemView.context).load(File(mediaList[position].mediaPath))
            .into(holder.img_media_child)

        holder.img_media_child_background.visibility = if (selectedPosition == position) {
            View.VISIBLE
        } else {
            View.GONE
        }

        holder.itemView.setOnClickListener {
            if(selectedPosition != position) {
                selectedPosition = position
                singleItemCallback.itemInteracted(position)
                notifyDataSetChanged()
            }
        }
    }

    override fun getItemCount() = mediaList.size

    class MediaPreviewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val img_media_child = itemView.findViewById<CustomImageView>(R.id.img_media_child)
        val img_media_child_background =
            itemView.findViewById<CustomImageView>(R.id.img_media_child_background)
    }

}