package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.model.MessageResponse
import com.sociomee.msgmee.ui.repo.ResetPasswordRepo

class ResetPasswordViewModel : MyViewModel() {

    private var passwordReset = MutableLiveData<MessageResponse>()
    private lateinit var resetPasswordRepo: ResetPasswordRepo

    // returning LiveData
    fun observeResetPassword() = passwordReset

    fun resetPassword(body: HashMap<String, Any>) {
        if(!this::resetPasswordRepo.isInitialized) {
            resetPasswordRepo = ResetPasswordRepo()
        }
        isLoading.value = true
        resetPasswordRepo.resetPassword(body).observeForever {
            if(it.status == ResponseStatus.SUCCESS) {
                passwordReset.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

}