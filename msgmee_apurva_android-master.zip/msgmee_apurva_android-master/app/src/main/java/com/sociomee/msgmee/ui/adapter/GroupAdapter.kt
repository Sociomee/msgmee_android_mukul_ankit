package com.sociomee.msgmee.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomImageView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.`interface`.GroupInfoInterface
import com.sociomee.msgmee.ui.model.ChatMemberData

class GroupAdapter(
    private val memberList: ArrayList<ChatMemberData>,
    private val groupInfoInterface: GroupInfoInterface
) :
    RecyclerView.Adapter<GroupAdapter.GroupHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = GroupHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.participants_child, parent, false)
    )

    override fun onBindViewHolder(holder: GroupHolder, position: Int) {
        val data = memberList[position]
        holder.txt_group_admin.visibility = if (data.role == "member") View.GONE else View.VISIBLE
        holder.txt_group_admin.text = holder.itemView.context.getString(R.string.group_admin)

        holder.txt_name.text = data.fullName

        Glide.with(holder.itemView.context).load(data.profileImageThumb).placeholder(
            R.drawable.profile_placeholder
        ).into(holder.img_profile)

        holder.itemView.setOnLongClickListener {
            groupInfoInterface.memberLongPressed(position)
            true
        }
    }

    override fun getItemCount() = memberList.size

    class GroupHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txt_group_admin = itemView.findViewById<CustomTextView>(R.id.txt_group_admin)
        val txt_name = itemView.findViewById<CustomTextView>(R.id.txt_name)
        val img_profile = itemView.findViewById<CustomImageView>(R.id.img_profile)
    }
}