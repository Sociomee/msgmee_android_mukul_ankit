package com.sociomee.msgmee.ui.model

data class StartCallModel(
    val username: String,
    val fullName: String,
    val userId: String,
    val profilePicture: String?,
    var callState: String = "initiated"
)