package com.sociomee.msgmee.ui.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomIconView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.`interface`.SingleItemCallback
import com.sociomee.msgmee.ui.activity.PageChatActivity

class PageMessageListAdapter(private val singleItemCallback: SingleItemCallback) : RecyclerView.Adapter<PageMessageListAdapter.MarketListHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = MarketListHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.page_message_child, parent ,false)
    )

    override fun getItemCount() = 10

    override fun onBindViewHolder(holder: MarketListHolder, position: Int) {
        holder.img_last_message.visibility = View.GONE

        holder.txt_message_count.text = "10"
        holder.txt_messages_name.text = "Harsh Barnwal"
        holder.txt_page_name.text = "Stepping stone"

        if(position % 2 == 0) {
            holder.cv_message_circle.visibility = View.GONE
        }

        holder.itemView.setOnClickListener {
            holder.itemView.context.startActivity(
                    Intent(holder.itemView.context, PageChatActivity::class.java))
        }
        holder.itemView.setOnLongClickListener {
            singleItemCallback.itemInteracted(position)
            true
        }
    }

    class MarketListHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val img_last_message = itemView.findViewById<CustomIconView>(R.id.img_last_message)
        val txt_message_count = itemView.findViewById<CustomTextView>(R.id.txt_message_count)
        val txt_messages_name = itemView.findViewById<CustomTextView>(R.id.txt_messages_name)
        val txt_page_name = itemView.findViewById<CustomTextView>(R.id.txt_page_name)
        val cv_message_circle = itemView.findViewById<CardView>(R.id.cv_message_circle)
    }
}