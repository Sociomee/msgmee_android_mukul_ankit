package com.sociomee.msgmee.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sociomee.msgmee.R

class PeopleFilterAdapter(val list:ArrayList<String>) : RecyclerView.Adapter<PeopleFilterAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.search_filter_child,parent,false))

    override fun getItemCount() = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.setData(list[position],position)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txt_content=itemView.findViewById<TextView>(R.id.txt_content)

        fun setData(content:String,position: Int){
            txt_content.text = content
            itemView.setOnClickListener {
                list.removeAt(position)
                notifyDataSetChanged()
            }
        }

    }
}