package com.sociomee.msgmee.ui.activity

import android.os.Bundle
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import kotlinx.android.synthetic.main.outgoing_call_activity.*

class OutgoingCallActivity : CustomAppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.outgoing_call_activity)

        setViewsClick()
    }

    private fun setViewsClick() {
        img_outgoing_call_end.setOnClickListener {
        }
    }

    override fun setInitialLanguage() {
        txt_outgoing_caller_name.text = "Harsh"
        txt_outgoing_call_status.text = getString(R.string.outgoing_audio_call)
    }

    override fun bindData() {

    }
}