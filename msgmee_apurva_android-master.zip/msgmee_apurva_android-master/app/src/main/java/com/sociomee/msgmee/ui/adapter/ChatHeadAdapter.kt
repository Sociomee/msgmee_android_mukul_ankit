package com.sociomee.msgmee.ui.adapter

import android.content.Intent
import android.graphics.Color
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomIconView
import com.sociomee.msgmee.custom.widget.CustomImageView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.`interface`.MultiSelectCallBack
import com.sociomee.msgmee.ui.activity.ChatActivity
import com.sociomee.msgmee.ui.model.ChatHeadData
import com.sociomee.msgmee.ui.model.ChatHeadInfo
import com.sociomee.msgmee.utils.TimeAgo

class ChatHeadAdapter(
    private val chatHeadList: ArrayList<ChatHeadData>,
    private val multiSelectCallBack: MultiSelectCallBack
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var isMultiSelectOpen = false
    var multiSelectCount = 0
    var selectedMessageList = ArrayList<Int>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == 1) {
            MessageListHolder(
                LayoutInflater.from(
                    parent.context
                ).inflate(R.layout.message_list_child, parent, false)
            )
        } else {
            ArchiveChatHolder(
                LayoutInflater.from(
                    parent.context
                ).inflate(R.layout.chat_unread_child, parent, false)
            )
        }
    }

    override fun getItemViewType(position: Int): Int {
        return if (chatHeadList[position].chatHeadType == "archive") 0 else 1
    }

    override fun getItemCount() = chatHeadList.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (chatHeadList[position].chatHeadType == "archive") {
            (holder as ArchiveChatHolder).setHolderData()
        } else {
            val messageListHolder = holder as MessageListHolder
            val data = chatHeadList[position]
            val typedValue = TypedValue()
            var chatHeadName = ""
            var profileThumb = ""
            var chatTypeId = ""
            messageListHolder.itemView.context.theme.resolveAttribute(
                R.attr.titleTextColor,
                typedValue,
                true
            )

            when (data.chatHeadType) {
                "user" -> {
                    profileThumb = data.profileImageThumb
                    chatTypeId = data.otherUserId
                    chatHeadName = data.fullName

                    Glide.with(messageListHolder.itemView.context).load(data.profileImageThumb)
                        .placeholder(R.drawable.profile_placeholder)
                        .into(messageListHolder.img_messenger_profile)
                }
                "group" -> {
                    profileThumb = data.groupImageThumb
                    chatTypeId = data.groupId
                    chatHeadName = data.groupName

                    Glide.with(messageListHolder.itemView.context).load(data.groupImageThumb)
                        .placeholder(R.drawable.profile_placeholder)
                        .into(messageListHolder.img_messenger_profile)
                }
                "broadcast" -> {
                    chatHeadName = data.broadcastListName
                    chatTypeId = data.broadcastId

                    messageListHolder.img_last_message.visibility = View.GONE
                    messageListHolder.cv_online_circle.visibility = View.GONE
                    messageListHolder.cv_message_circle.visibility = View.GONE
                    Glide.with(messageListHolder.itemView.context)
                        .load(R.drawable.ic_broadcast_background)
                        .into(messageListHolder.img_messenger_profile)

                    messageListHolder.txt_last_message.setTextColor(typedValue.data)
                }
            }

            messageListHolder.txt_messages_name.text = chatHeadName
            messageListHolder.txt_message_time.text = TimeAgo.getTimeAgo(data.lastMessageDate)
            messageListHolder.txt_message_count.text = data.unReadCount

            messageListHolder.cv_message_circle.visibility =
                if (data.unReadCount == "0") View.GONE else View.VISIBLE
            messageListHolder.img_pin.visibility =
                if (data.isPinned == 1) View.VISIBLE else View.GONE
            messageListHolder.img_mute.visibility =
                if (data.isMute == 1) View.VISIBLE else View.GONE
            messageListHolder.cv_online_circle.visibility =
                if (data.isOnline == 1) View.VISIBLE else View.GONE

            if (isMultiSelectOpen) {
                holder.itemView.setOnClickListener {
                    chatHeadList[position].isSelected = !chatHeadList[position].isSelected
                    if (chatHeadList[position].isSelected) {
                        multiSelectCount++
                        selectedMessageList.add(position)
                    } else {
                        multiSelectCount--
                        selectedMessageList.remove(position)
                    }
                    if (multiSelectCount == 0)
                        isMultiSelectOpen = false
                    multiSelectCallBack.notifyMultiSelectItemChange(
                        isMultiSelectOpen,
                        multiSelectCount,
                        selectedMessageList
                    )
                    notifyDataSetChanged()
                }
                messageListHolder.itemView.setOnLongClickListener {
                    true
                }
            } else {
                // opening multiSelect
                messageListHolder.itemView.setOnLongClickListener {
                    isMultiSelectOpen = true
                    chatHeadList[position].isSelected = !chatHeadList[position].isSelected
                    multiSelectCount++
                    selectedMessageList.add(position)
                    multiSelectCallBack.notifyMultiSelectItemChange(
                        isMultiSelectOpen,
                        multiSelectCount,
                        selectedMessageList
                    )
                    notifyDataSetChanged()
                    true
                }

                // opening chat screen
                messageListHolder.itemView.setOnClickListener {
                    val chatInfo = ChatHeadInfo(
                        data.chatHeadId,
                        chatHeadName,
                        profileThumb,
                        data.chatHeadType,
                        chatTypeId
                    )
                    val intent = Intent(
                        messageListHolder.itemView.context,
                        ChatActivity::class.java
                    )
                    intent.putExtra("chatHeadData", Gson().toJson(chatInfo))
                    messageListHolder.itemView.context.startActivity(
                        intent
                    )
                }
            }

            if (data.isSelected) {
                messageListHolder.cl_messenger_list_child.setBackgroundColor(
                    ContextCompat.getColor(
                        messageListHolder.itemView.context,
                        R.color.colorWelcomeBackground
                    )
                )
            } else {
                messageListHolder.cl_messenger_list_child.setBackgroundColor(Color.TRANSPARENT)
            }

            if (data.lastMessageDeleted == 1) {
                messageListHolder.txt_last_message.text = messageListHolder.itemView.context.getString(
                    R.string.message_deleted
                )
                messageListHolder.img_last_message.visibility = View.GONE

                messageListHolder.txt_last_message.setTextColor(typedValue.data)
            } else
                when (data.lastMessageType) {
                    "text" -> {
                        messageListHolder.txt_last_message.text = data.lastMessageText
                        messageListHolder.img_last_message.visibility = View.GONE

                        messageListHolder.txt_last_message.setTextColor(typedValue.data)
                    }
                    "image" -> {
                        messageListHolder.txt_last_message.text =
                            messageListHolder.itemView.context.getString(
                                R.string.image
                            )
                        messageListHolder.img_last_message.visibility = View.VISIBLE
                        Glide.with(messageListHolder.itemView.context)
                            .load(R.drawable.messenger_image)
                            .into(messageListHolder.img_last_message)

                        messageListHolder.txt_last_message.setTextColor(typedValue.data)
                    }
                    "video" -> {
                        messageListHolder.txt_last_message.text =
                            messageListHolder.itemView.context.getString(
                                R.string.video
                            )
                        messageListHolder.img_last_message.visibility = View.VISIBLE
                        Glide.with(messageListHolder.itemView.context)
                            .load(R.drawable.messenger_video)
                            .into(messageListHolder.img_last_message)

                        messageListHolder.txt_last_message.setTextColor(typedValue.data)
                    }
                    "audio" -> {
                        messageListHolder.txt_last_message.text =
                            messageListHolder.itemView.context.getString(
                                R.string.audio
                            )
                        messageListHolder.img_last_message.visibility = View.VISIBLE
                        Glide.with(messageListHolder.itemView.context)
                            .load(R.drawable.messenger_music)
                            .into(messageListHolder.img_last_message)

                        messageListHolder.txt_last_message.setTextColor(typedValue.data)
                    }
                    "contact" -> {
                        messageListHolder.txt_last_message.text =
                            messageListHolder.itemView.context.getString(
                                R.string.contact
                            )
                        messageListHolder.img_last_message.visibility = View.VISIBLE
                        Glide.with(messageListHolder.itemView.context)
                            .load(R.drawable.messenger_contact)
                            .into(messageListHolder.img_last_message)

                        messageListHolder.txt_last_message.setTextColor(typedValue.data)
                    }
                    "document" -> {
                        messageListHolder.txt_last_message.text =
                            messageListHolder.itemView.context.getString(
                                R.string.document
                            )
                        messageListHolder.img_last_message.visibility = View.VISIBLE
                        Glide.with(messageListHolder.itemView.context)
                            .load(R.drawable.messenger_contact)
                            .into(messageListHolder.img_last_message)

                        messageListHolder.txt_last_message.setTextColor(typedValue.data)
                    }
                    "post" -> {
                        messageListHolder.txt_last_message.text =
                            messageListHolder.itemView.context.getString(
                                R.string.post
                            )
                        messageListHolder.img_last_message.visibility = View.VISIBLE
                        Glide.with(messageListHolder.itemView.context)
                            .load(R.drawable.messenger_contact)
                            .into(messageListHolder.img_last_message)

                        messageListHolder.txt_last_message.setTextColor(typedValue.data)
                    }
                    "shotz" -> {
                        messageListHolder.txt_last_message.text =
                            messageListHolder.itemView.context.getString(
                                R.string.shotz
                            )
                        messageListHolder.img_last_message.visibility = View.VISIBLE
                        Glide.with(messageListHolder.itemView.context)
                            .load(R.drawable.messenger_contact)
                            .into(messageListHolder.img_last_message)

                        messageListHolder.txt_last_message.setTextColor(typedValue.data)
                    }
                    "story" -> {
                        messageListHolder.txt_last_message.text =
                            messageListHolder.itemView.context.getString(
                                R.string.story
                            )
                        messageListHolder.img_last_message.visibility = View.VISIBLE
                        Glide.with(messageListHolder.itemView.context)
                            .load(R.drawable.messenger_contact)
                            .into(messageListHolder.img_last_message)

                        messageListHolder.txt_last_message.setTextColor(typedValue.data)
                    }
                    "bubble" -> {
                        messageListHolder.txt_last_message.text =
                            messageListHolder.itemView.context.getString(
                                R.string.bubble
                            )
                        messageListHolder.img_last_message.visibility = View.VISIBLE
                        Glide.with(messageListHolder.itemView.context)
                            .load(R.drawable.messenger_contact)
                            .into(messageListHolder.img_last_message)

                        messageListHolder.txt_last_message.setTextColor(typedValue.data)
                    }
                    "reply" -> {
                        messageListHolder.txt_last_message.text =
                            messageListHolder.itemView.context.getString(
                                R.string.reply
                            )
                        messageListHolder.img_last_message.visibility = View.VISIBLE
                        Glide.with(messageListHolder.itemView.context)
                            .load(R.drawable.messenger_contact)
                            .into(messageListHolder.img_last_message)

                        messageListHolder.txt_last_message.setTextColor(typedValue.data)
                    }
                    /*Constant.LastMessageType.BROADCAST -> {
                    val lastMessage = data.lastMessage
                    messageListHolder.txt_last_message.text = lastMessage
                    messageListHolder.img_last_message.visibility = View.GONE
                    messageListHolder.cv_online_circle.visibility = View.GONE
                    messageListHolder.cv_message_circle.visibility = View.GONE
                    Glide.with(messageListHolder.itemView.context).load(R.drawable.ic_broadcast_background)
                            .into(messageListHolder.img_messenger_profile)

                    messageListHolder.txt_last_message.setTextColor(typedValue.data)
                }
                Constant.LastMessageType.GROUP_MESSAGE -> {
                    val lastMessage = "Razdar : ${data.lastMessage}"
                    messageListHolder.txt_last_message.text = lastMessage
                    messageListHolder.img_last_message.visibility = View.GONE

                    messageListHolder.txt_last_message.setTextColor(typedValue.data)
                }
                Constant.LastMessageType.TYPING -> {
                    messageListHolder.txt_last_message.text = messageListHolder.itemView.context.getString(R.string.typing_)
                    messageListHolder.txt_last_message.setTextColor(
                            ContextCompat.getColor(messageListHolder.itemView.context, R.color.dark_green_60))
                    messageListHolder.img_last_message.visibility = View.GONE

                    messageListHolder.txt_last_message.setTextColor(typedValue.data)
                }
                Constant.LastMessageType.GROUP_TYPING -> {
                    val lastMessage = "Harsh : ${messageListHolder.itemView.context.getString(R.string.typing_)}"
                    messageListHolder.txt_last_message.text = lastMessage
                    messageListHolder.img_last_message.visibility = View.GONE

                    messageListHolder.txt_last_message.setTextColor(typedValue.data)
                }
                Constant.LastMessageType.LEFT_GROUP -> {
                    val lastMessage = "${messageListHolder.itemView.context.getString(
                            R.string.you)} : ${messageListHolder.itemView.context.getString(
                            R.string.left_the_group)}"
                    messageListHolder.txt_last_message.text = lastMessage
                    messageListHolder.img_last_message.visibility = View.GONE

                    messageListHolder.txt_last_message.setTextColor(typedValue.data)
                }
                Constant.LastMessageType.MISSED_VIDEO_CALL -> {
                    messageListHolder.txt_last_message.text = messageListHolder.itemView.context.getString(
                            R.string.missed_a_video)
                    messageListHolder.img_last_message.visibility = View.GONE

                    messageListHolder.txt_last_message.setTextColor(
                            ContextCompat.getColor(messageListHolder.itemView.context, R.color.red))
                }
                Constant.LastMessageType.MISSED_AUDIO_CALL -> {
                    messageListHolder.txt_last_message.text = messageListHolder.itemView.context.getString(
                            R.string.missed_a_voice)
                    messageListHolder.img_last_message.visibility = View.GONE

                    messageListHolder.txt_last_message.setTextColor(
                            ContextCompat.getColor(messageListHolder.itemView.context, R.color.red))
                }*/
                }
        }
    }

    fun clearMultiSelect() {
        isMultiSelectOpen = false
        multiSelectCount = 0
        selectedMessageList.clear()
        multiSelectCallBack.notifyMultiSelectItemChange(
            isMultiSelectOpen,
            multiSelectCount,
            selectedMessageList
        )
        chatHeadList.forEach {
            it.isSelected = false
        }
        notifyDataSetChanged()
    }

    class MessageListHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val img_last_message = itemView.findViewById<CustomIconView>(R.id.img_last_message)
        val cv_message_circle = itemView.findViewById<CardView>(R.id.cv_message_circle)
        val cv_online_circle = itemView.findViewById<CardView>(R.id.cv_online_circle)
        val txt_last_message = itemView.findViewById<CustomTextView>(R.id.txt_last_message)
        val txt_messages_name = itemView.findViewById<CustomTextView>(R.id.txt_messages_name)
        val txt_message_time = itemView.findViewById<CustomTextView>(R.id.txt_message_time)
        val txt_message_count = itemView.findViewById<CustomTextView>(R.id.txt_message_count)
        val cl_messenger_list_child = itemView.findViewById<ConstraintLayout>(
            R.id.cl_messenger_list_child
        )
        val img_pin = itemView.findViewById<CustomIconView>(R.id.img_pin)
        val img_mute = itemView.findViewById<CustomIconView>(R.id.img_mute)
        val img_messenger_profile = itemView.findViewById<CustomImageView>(
            R.id.img_messenger_profile
        )
    }

    class ArchiveChatHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val txt_unread_bubble =
            itemView.findViewById<CustomTextView>(R.id.txt_unread_bubble)
        private val view_message = itemView.findViewById<View>(R.id.view_message)

        fun setHolderData() {
            txt_unread_bubble.text = itemView.context.getString(R.string.archived_chats)
            view_message.visibility = View.VISIBLE
        }
    }
}