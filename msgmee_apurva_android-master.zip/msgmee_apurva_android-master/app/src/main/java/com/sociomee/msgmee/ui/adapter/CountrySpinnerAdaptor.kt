package com.sociomee.msgmee.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.ui.data.CountryDataModel

class CountrySpinnerAdaptor(val list:ArrayList<CountryDataModel>) : BaseAdapter() {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val model = list[position]
        val view=LayoutInflater.from(parent!!.context).inflate(R.layout.county_spinner_child,parent,false)
        val tv=view.findViewById<TextView>(R.id.txt_country_code)
        val iv=view.findViewById<ImageView>(R.id.img_flag)

        tv.text=list[position].code
        Glide.with(view.context).load(model.flagURL).placeholder(R.drawable.test_flag).into(iv)
        return view
    }

    override fun getItem(position: Int): Any {
        return list.size
    }

    override fun getItemId(position: Int): Long {
        return 0L
    }

    override fun getCount(): Int {
        return list.size
    }

}

data class CountyCode(val countryCode:String,val drawable:Int)