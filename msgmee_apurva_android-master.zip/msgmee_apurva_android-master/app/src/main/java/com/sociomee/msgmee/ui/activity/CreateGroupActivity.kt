package com.sociomee.msgmee.ui.activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.luck.picture.lib.PictureSelector
import com.luck.picture.lib.config.PictureConfig
import com.luck.picture.lib.entity.LocalMedia
import com.luck.picture.lib.instagram.InsGallery
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.imagePicker.GlideCacheEngine
import com.sociomee.msgmee.imagePicker.GlideEngine
import com.sociomee.msgmee.ui.model.FriendModel
import com.sociomee.msgmee.ui.model.GroupCreateMemberModel
import com.sociomee.msgmee.ui.model.MediaModel
import com.sociomee.msgmee.ui.viewmodel.GroupVM
import com.sociomee.msgmee.ui.viewmodel.MediaUploadVM
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.MyPreferences
import com.yalantis.ucrop_.UCrop
import kotlinx.android.synthetic.main.create_group_activity.*
import kotlinx.android.synthetic.main.custom_toolbar.*
import kotlinx.android.synthetic.main.select_media_dialog.view.*
import java.io.File
import kotlin.collections.ArrayList
import kotlin.collections.HashMap
import androidx.lifecycle.Observer

class CreateGroupActivity : CustomAppCompatActivity() {

    lateinit var peopleList: ArrayList<FriendModel>
    private val REQUIRED_PERMISSIONS = arrayOf(
        "android.permission.CAMERA",
    )
    private val REQUEST_CODE_PERMISSIONS = 101
    private val CAMERA_REQUEST = 102
    lateinit var capturedPhotoPath: String
    var groupImagePath: String? = null
    private var gallerySelectedImage: LocalMedia? = null
    lateinit var groupVM: GroupVM
    lateinit var mediaUploadVM: MediaUploadVM

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.create_group_activity)

        val peopleType = object : TypeToken<ArrayList<FriendModel>>() {}.type
        peopleList = Gson().fromJson(intent!!.extras!!.getString("selectedPeopleList"), peopleType)

        bindData()
        initData()
        observeData()
        setViewsClick()
    }

    private fun observeData() {
        groupVM.observeLoading().observe(this, Observer {
            changeLoadingStatus(it)
        })
        mediaUploadVM.observeLoading().observe(this, Observer {
            changeLoadingStatus(it)
        })
        groupVM.observeGroupCreation().observe(this, Observer {
            if(!it) {
                showToast()
            } else {
                showToast("Group created successfully")
                finish()
            }
        })
        mediaUploadVM.observeMediaUpload().observe(this, Observer {
            createGroup(groupImageUrl = it[0].mediaPath)
        })

        observeError()
    }

    private fun observeError() {
        groupVM.observeError().observe(this, Observer {
            processError(it)
        })
        mediaUploadVM.observeError().observe(this, Observer {
            processError(it)
        })
    }

    private fun processError(it: ResponseStatus?) {
        when (it) {
            ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                showToast("Internet not available")
            }
            ResponseStatus.AUTH_ERROR -> {
                showToast("Auth Error")
            }
            ResponseStatus.SERVER_ERROR -> {
                showToast("Server Error")
            }
            else -> {
            }
        }
    }

    private fun initData() {
        groupVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            GroupVM::class.java
        )
        mediaUploadVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            MediaUploadVM::class.java
        )
    }

    private fun setViewsClick() {
        img_toolbar_back.setOnClickListener {
            onBackPressed()
        }
        cv_group_profile.setOnClickListener {
            openMediaBottomSheet()
        }
        btn_next.setOnClickListener {
            processGroupData()
        }
    }

    private fun processGroupData() {
        if(edt_group_name.text.toString().isEmpty()) {
            txt_error.text = getString(R.string.please_enter_)
            return
        }
        txt_error.text = ""

        if(groupImagePath != null) {
            mediaUploadVM.uploadPathMedia(listOf(MediaModel(groupImagePath!!,
                Constants.SelectedMediaType.IMAGE)), "groupDp")
        } else {
            createGroup()
        }
    }

    private fun createGroup(groupImageUrl: String? = null) {
        val memberList = ArrayList<GroupCreateMemberModel>()

        peopleList.forEach {
            memberList.add(GroupCreateMemberModel(it.id, it.userName))
        }

        val bodyMap: HashMap<String, Any> = hashMapOf(
            "groupName" to edt_group_name.text.toString(),
            "members" to memberList
        )
        if(groupImageUrl != null) {
            bodyMap["imageURL"] = groupImageUrl
        }
        if(edt_location.text.toString().isNotEmpty()) {
            bodyMap["summary"] = edt_location.text.toString()
        }
        groupVM.createChatHead(bodyMap)
    }

    override fun setInitialLanguage() {
        txt_chat_head_name.text = getString(R.string.create_your_group)
        txt_name_your.text = getString(R.string.name_your_group)
        txt_choose_a.text = getString(R.string.choose_a_name__group)
        txt_edit_profile.text = getString(R.string.edit)
        txt_max_char.text = getString(R.string.max_180_char)
        btn_next.text = getString(R.string.next)
        edt_group_name.hint = getString(R.string.enter_your_)
        edt_location.hint = getString(R.string.describe_your_)
        txt_summary.text = getString(R.string.summary)
        val nameText = getString(R.string.name) + "*"
        txt_name.text = nameText
    }

    override fun bindData() {
        val selectedText = "${getString(R.string.members_selected)} : ${peopleList.size}"
        txt_members_selected.text = selectedText
    }

    private fun openMediaBottomSheet() {
        val view = LayoutInflater.from(this).inflate(R.layout.select_media_dialog, null)
        val dialog = BottomSheetDialog(this, R.style.SheetDialog)
        view.txt_select_media_.text = getString(R.string.select_media_)
        view.txt_camera.text = getString(R.string.camera)
        view.txt_gallery.text = getString(R.string.gallery)
        view.txt_take_a_.text = getString(R.string.take_a_)
        dialog.setContentView(view)

        view.card_camera.setOnClickListener {
            dialog.dismiss()
            if (Constants.isPermissionGranted(this, REQUIRED_PERMISSIONS)) {
                dispatchTakePictureIntent()
            } else {
                ActivityCompat.requestPermissions(
                    this,
                    REQUIRED_PERMISSIONS,
                    REQUEST_CODE_PERMISSIONS
                )
            }
        }
        view.card_gallery.setOnClickListener {
            dialog.dismiss()

            // opening InsGallery
            MyPreferences.saveIntInPreference(this, "maxSelect", 1)

            InsGallery.openGalleryForImages(this, GlideEngine.createGlideEngine(),
                GlideCacheEngine.createCacheEngine(), ArrayList<LocalMedia>(),
                PictureConfig.REQUEST_GALLERY_IMAGE_FOR_POST)
        }

        dialog.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            UCrop.of(File(capturedPhotoPath).toUri(), Uri.parse(Constants.createNewFilePath(this, "jpg")))
                .withAspectRatio(1f, 1f).start(this)
        } else if (requestCode == UCrop.REQUEST_CROP) {
            if (resultCode == RESULT_OK) {
                val resultUri = UCrop.getOutput(data!!)
                if (resultUri != null) {
                    groupImagePath = resultUri.path
                    Glide.with(this).load(resultUri).into(img_group_profile)
                }
            }
        } else if (requestCode == PictureConfig.REQUEST_GALLERY_IMAGE_FOR_POST && resultCode == RESULT_OK) {
            gallerySelectedImage = PictureSelector.obtainMultipleResult(data)[0]
            if (gallerySelectedImage != null) {
                val file = File(gallerySelectedImage!!.cutPath)
                UCrop.of(file.toUri(), Uri.parse(Constants.createNewFilePath(this, "jpg")))
                    .withAspectRatio(1f, 1f).start(this)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (Constants.isPermissionGranted(this, REQUIRED_PERMISSIONS)) {
                dispatchTakePictureIntent()
            } else {
                Toast.makeText(this, "Permissions not granted by the user.", Toast.LENGTH_SHORT)
                    .show()
                finish()
            }
        }
    }

    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.also {
                val photoFile = Constants.createFile(this)
                // Continue only if the File was successfully created
                if (photoFile == null) {
                    showToast()
                } else {
                    capturedPhotoPath = photoFile.absolutePath
                    photoFile.also {
                        val photoURI: Uri = FileProvider.getUriForFile(
                            this,
                            "com.example.android.fileprovider",
                            it
                        )
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                        startActivityForResult(takePictureIntent, CAMERA_REQUEST)
                    }
                }
            }
        }
    }
}