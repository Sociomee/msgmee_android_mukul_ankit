package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.model.ChatMemberModel
import com.sociomee.msgmee.ui.repo.BroadcastInfoRepo

class BroadcastInfoVM : MyViewModel() {

    private var broadcastPeopleList = MutableLiveData<ChatMemberModel.Data.SuccessResult>()
    private lateinit var broadcastInfoRepo: BroadcastInfoRepo

    // returning LiveData
    fun observerBroadcastPeopleList() = broadcastPeopleList

    fun fetchGroupPeopleList(body: HashMap<String, Any>, showLoading: Boolean = true) {
        if (!this::broadcastInfoRepo.isInitialized) {
            broadcastInfoRepo = BroadcastInfoRepo()
        }
        if (showLoading)
            isLoading.value = true
        broadcastInfoRepo.fetchBroadcastPeopleList(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                broadcastPeopleList.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

//    fun updateGroupInfo(body: HashMap<String, Any>) {
//        if (!this::groupInfoRepo.isInitialized) {
//            groupInfoRepo = GroupInfoRepo()
//        }
//        isLoading.value = true
//        groupInfoRepo.updateGroupInfo(body).observeForever {
//            if (it.status == ResponseStatus.SUCCESS) {
//                groupUpdated.value = it.data
//            } else {
//                errorListener.value = it.status
//            }
//            isLoading.value = false
//        }
//    }
}