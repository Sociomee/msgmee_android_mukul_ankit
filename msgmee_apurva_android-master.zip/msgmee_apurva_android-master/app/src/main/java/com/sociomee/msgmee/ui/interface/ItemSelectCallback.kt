package com.sociomee.msgmee.ui.`interface`

interface ItemSelectCallback {

    fun itemSelectionChanged(position: Int, id: String, type: String, isSelected: Boolean)

}