package com.sociomee.msgmee.ui.model

import com.google.gson.annotations.SerializedName

data class UserModel(
        @SerializedName("data")
        val userData: UserData,
        @SerializedName("error")
        val error: Boolean,
        @SerializedName("success")
        val success: Boolean
) {
    data class UserData(
            @SerializedName("successResult")
            val profileData: ProfileData
    ) {
        data class ProfileData(
                @SerializedName("addressBy")
                val addressBy: Any,
                @SerializedName("bio")
                val bio: String,
                @SerializedName("coverImage")
                val coverImage: String,
                @SerializedName("dob")
                val dob: String,
                @SerializedName("followersCount")
                val followersCount: Int,
                @SerializedName("followingCount")
                val followingCount: Int,
                @SerializedName("followingStatus")
                val followingStatus: String,
                @SerializedName("fullName")
                val fullName: String,
                @SerializedName("gender")
                val gender: String,
                @SerializedName("id")
                val id: String,
                @SerializedName("maritalStatus")
                val maritalStatus: String,
                @SerializedName("maxPostCount")
                val maxPostCount: Int,
                @SerializedName("maxPostKey")
                val maxPostKey: String,
                @SerializedName("professionId")
                val professionId: String,
                @SerializedName("professionName")
                val professionName: String,
                @SerializedName("profileImage")
                val profileImage: String,
                @SerializedName("profileImageThumb")
                val profileImageThumb: String,
                @SerializedName("speakLanguage")
                val speakLanguage: List<SpeakLanguageList>,
                @SerializedName("userName")
                val userName: String,
                @SerializedName("homeAddress")
                val homeAddress: String,
                @SerializedName("blockByMe")
                val blockByMe: String,
                @SerializedName("notificationOff")
                val notificationOff: String,
                @SerializedName("mutualFollowers")
                val mutualFollowers: MutualFollowers?
        )
            data class SpeakLanguageList(
                    @SerializedName("langId")
                    val langId: String,
                    @SerializedName("name")
                    val name: String
            )data class MutualFollowers(
                @SerializedName("count")
                val count: Int,
                @SerializedName("rows")
                val rows: List<Row>
        ) {
            data class Row(
                    @SerializedName("dob")
                    val dob: String,
                    @SerializedName("fullName")
                    val fullName: String,
                    @SerializedName("gender")
                    val gender: String,
                    @SerializedName("id")
                    val id: String,
                    @SerializedName("profileImage")
                    val profileImage: String,
                    @SerializedName("profileImageThumb")
                    val profileImageThumb: String,
                    @SerializedName("userName")
                    val userName: String
            )
        }



    }
}