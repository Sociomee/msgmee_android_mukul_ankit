package com.sociomee.msgmee.ui.model

data class MessageReplyModel(val replyMessageId: String, val replyMessageSequence: Int)