package com.sociomee.msgmee.ui.`interface`

import com.sociomee.app.ui.profile.data.UserContactModel
import com.sociomee.msgmee.retrofit.MyCall
import com.sociomee.msgmee.ui.data.*
import com.sociomee.msgmee.ui.model.*
import retrofit2.http.Body
import retrofit2.http.POST

interface UserProfileApiCall {

    @POST("/user/getUserProfileById")
    fun getUserData(@Body body: HashMap<String, Any>): MyCall<UserModel>

    @POST("/user/followUnfollow")
    fun userFollow(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/user/unFollow")
    fun userUnFollow(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/user/getUserConnections")
    fun getUserRelation(): MyCall<UserRelationshipModel>

    @POST("/user/addHobbies")
    fun addUserHobbies(@Body body: HashMap<String, Any>): MyCall<AddUserHobbiesModel>

     @POST("/user/addInterests")
     fun addUserInterest(@Body body: HashMap<String, Any>): MyCall<UserAddInterestModel>

    @POST("admin/getAllHobbies")
    fun getHobbiesList(): MyCall<HobbiesModel>

    @POST("/admin/getAllMaritalStatus")
    fun getMaritalStatus(): MyCall<MaritalStatusModel>

    @POST("/admin/getAllSpeakLanguages")
    fun getAllSpeakLanguage(): MyCall<UserSpeakLanguageModel>

    @POST("/user/update")
    fun updateUserProfile(@Body body: HashMap<String, Any>): MyCall<UserProfileUpdateModel>

//    @POST("/user/updateUserSpeakLanguage")
//    fun updateUserSpeakLanguage(@Body body: HashMap<String, Any>): MyCall<UserUpdateSpeakLanguageModel>

    @POST("/user/userUnDndUser")
    fun userTurnOffNotification(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/user/userDndUser")
    fun userTurnOnNotification(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/admin/getReportOptions")
    fun getUserReportList(@Body body: HashMap<String, Any>): MyCall<UserReportModel>

    @POST("/user/reportUser")
    fun reportUser(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/user/searchUserFollowers")
    fun getSearchUserFollowers(@Body body: HashMap<String, Any>): MyCall<SearchUserFollowersModel>

    @POST("/user/getContacts")
    fun getUserContact(@Body body: HashMap<String, Any>): MyCall<UserContactModel>

    @POST("/user/searchUserFollowings")
    fun getSearchUserFollowings(@Body body: HashMap<String, Any>): MyCall<FollowingUserModel>

    @POST("/contact/byUserId")
    fun getUserContact(): MyCall<UserContactModel>

    @POST("/public/sendOtp")
    fun sendOtp(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/user/addContact")
    fun addContact(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/user/blockUser")
    fun blockUser(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/user/unblockUser/")
    fun unBlockUser(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/user/getInterests")
    fun getUserInterest(@Body body: HashMap<String, Any>): MyCall<UserInterestModel>

    @POST("/user/getHobbies")
    fun getUserHobbies(@Body body: HashMap<String, Any>): MyCall<UserHobbiesModel>

    @POST("/user/getUserFollowings")
    fun getFollowingUserList(@Body body: HashMap<String, Any>): MyCall<FollowingUserModel>

    @POST("/user/getUserFollowers")
    fun getFollowersUserList(@Body body: HashMap<String, Any>): MyCall<FollowingUserModel>

    @POST("/user/update/")
    fun updateUserDetails(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/admin/getAllProfessions")
    fun userProfession(@Body body: HashMap<String, Any>): MyCall<UserProfessionListModel>

    @POST("/post/getAllUserPosts")
    fun getAllMediaPosts(@Body body: HashMap<String, Any>): MyCall<AllMediaPostModel>

//    @POST("/post/getAllUserPosts")
//    fun getVideoMediaPosts(@Body body: HashMap<String, Any>): MyCall<VideoMediaPostModel>
//
//    @POST("/post/getAllUserPosts")
//    fun getImageMediaPosts(@Body body: HashMap<String, Any>): MyCall<ImageMediaPostModel>
//
//    @POST("/post/getAllUserPosts")
//    fun getArticleMediaPosts(@Body body: HashMap<String, Any>): MyCall<ArticleMediaPostModel>
//
//    @POST("/post/getAllUserPosts")
//    fun getShotzMediaPosts(@Body body: HashMap<String, Any>): MyCall<ShotzMediaPostModel>
//
//    @POST("/post/getAllUserPosts")
//    fun getMarketPlacePosts(@Body body: HashMap<String, Any>): MyCall<ProfileMarketPlaceModel>

    @POST("/post/getAllUserPosts")
    fun getSchedulePosts(@Body body: HashMap<String, Any>): MyCall<AllMediaPostModel>

    @POST("/post/getAllUserPosts")
    fun getPodCastPost(@Body body: HashMap<String, Any>): MyCall<AllMediaPostModel>

//    @POST("/post/getAllUserPosts")
//    fun getTextPost(@Body body: HashMap<String, Any>): MyCall<ProfileTextMediaModel>
}