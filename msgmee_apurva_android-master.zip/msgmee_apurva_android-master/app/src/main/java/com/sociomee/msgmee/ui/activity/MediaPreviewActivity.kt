package com.sociomee.msgmee.ui.activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.google.android.exoplayer2.*
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory
import com.google.android.exoplayer2.util.Util
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.ui.`interface`.SingleItemCallback
import com.sociomee.msgmee.ui.adapter.MediaPreviewAdapter
import com.sociomee.msgmee.ui.model.MediaPreviewModel
import com.sociomee.msgmee.utils.Constants
import kotlinx.android.synthetic.main.photos_preview_activity.*
import java.io.File

class MediaPreviewActivity : CustomAppCompatActivity(), SingleItemCallback {

    lateinit var mediaList: ArrayList<MediaPreviewModel>
    lateinit var mediaPreviewAdapter: MediaPreviewAdapter
    var selectedItemPosition = 0
    var exoplayer: SimpleExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.photos_preview_activity)

        mediaList =
            intent!!.extras!!.getParcelableArrayList<MediaPreviewModel>("mediaList") as ArrayList<MediaPreviewModel>

        bindData()
        setViewsClick()
    }

    private fun setViewsClick() {
        img_toolbar_back.setOnClickListener {
            onBackPressed()
        }
        txt_done.setOnClickListener {
            sendMediaBack()
        }
        cv_send.setOnClickListener {
            sendMediaBack()
        }
    }

    private fun sendMediaBack() {
        val intent = Intent()
        intent.putParcelableArrayListExtra("mediaList", mediaList)
        setResult(RESULT_OK, intent)
        finish()
    }

    override fun setInitialLanguage() {
        txt_done.text = getString(R.string.send)
        edt_chat.hint = getString(R.string.type_your_message)
    }

    override fun bindData() {
        mediaPreviewAdapter = MediaPreviewAdapter(mediaList, this)
        rl_media.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rl_media.adapter = mediaPreviewAdapter
        mediaPreviewAdapter.notifyDataSetChanged()

        updateView()

        edt_chat.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun afterTextChanged(p0: Editable?) {}

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                mediaList[selectedItemPosition].mediaMessage = edt_chat.text.toString().trim()
            }
        })
    }

    private fun updateView() {
        releasePlayer()

        if (mediaList[selectedItemPosition].mediaType == Constants.SelectedMediaType.IMAGE) {
            img_preview.visibility = View.VISIBLE
            exo_video_preview.visibility = View.GONE
            Glide.with(this).load(File(mediaList[selectedItemPosition].mediaPath)).into(img_preview)
        } else {
            img_preview.visibility = View.GONE
            exo_video_preview.visibility = View.VISIBLE

            initializePlayer()
        }
        edt_chat.setText(mediaList[selectedItemPosition].mediaMessage)
    }

    private fun initializePlayer() {
        if (exoplayer == null) {
            exoplayer = ExoPlayerFactory.newSimpleInstance(
                this,
                DefaultRenderersFactory(this), DefaultTrackSelector(),
                DefaultLoadControl()
            )
        }
        exo_video_preview.player = exoplayer
        exo_video_preview.requestFocus()
        exo_video_preview.useController = false

        val dataSourceFactory = DefaultDataSourceFactory(
            this,
            Util.getUserAgent(this, "messenger")
        )
        val mediaSource = ProgressiveMediaSource.Factory(dataSourceFactory)
            .createMediaSource(Uri.parse(mediaList[selectedItemPosition].mediaPath))

        exoplayer!!.prepare(mediaSource)
        exo_video_preview.player = exoplayer

        exoplayer!!.repeatMode = Player.REPEAT_MODE_ONE
    }

    override fun itemInteracted(position: Int) {
        selectedItemPosition = position
        updateView()
    }

    override fun onResume() {
        super.onResume()
        exoplayer?.playWhenReady = true
    }

    override fun onPause() {
        super.onPause()
        exoplayer?.playWhenReady = false
    }

    private fun releasePlayer() {
        exoplayer?.stop()
        exoplayer?.release()
    }

    override fun onDestroy() {
        releasePlayer()
        super.onDestroy()
    }
}