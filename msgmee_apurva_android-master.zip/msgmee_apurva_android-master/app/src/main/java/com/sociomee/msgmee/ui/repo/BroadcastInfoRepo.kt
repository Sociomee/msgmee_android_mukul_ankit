package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.ApiCall
import com.sociomee.msgmee.ui.model.*
import retrofit2.Response

class BroadcastInfoRepo {

    fun fetchBroadcastPeopleList(body: HashMap<String, Any>): MutableLiveData<MyResponse<ChatMemberModel.Data.SuccessResult>> {
        val data = MutableLiveData<MyResponse<ChatMemberModel.Data.SuccessResult>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.fetchBroadcastPeopleList(body)

        call.enqueue(object: MyCallback<ChatMemberModel> {
            override fun success(response: Response<ChatMemberModel>) {
                data.postValue(MyResponse.success(response.body()!!.data.successResult))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }
        })
        return data
    }

    fun updateGroupInfo(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.updateGroupInfo(body)

        call.enqueue(object: MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }
        })
        return data
    }

}