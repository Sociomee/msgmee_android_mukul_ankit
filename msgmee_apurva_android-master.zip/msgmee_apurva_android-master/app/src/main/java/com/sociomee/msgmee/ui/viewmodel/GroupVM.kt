package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.repo.GroupRepo

class GroupVM: MyViewModel() {

    private var createChatHead = MutableLiveData<Boolean>()
    private lateinit var groupRepo: GroupRepo

    // returning live data
    fun observeGroupCreation() = createChatHead

    fun createChatHead(body: HashMap<String, Any>) {
        if(!this::groupRepo.isInitialized) {
            groupRepo = GroupRepo()
        }
        isLoading.value = true
        groupRepo.createGroup(body).observeForever{
            if(it.status == ResponseStatus.SUCCESS) {
                createChatHead.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

}