package com.sociomee.msgmee.ui.model


import com.google.gson.annotations.SerializedName

data class MessageResponse(
        @SerializedName("data")
        val messageData: MessageData,
        @SerializedName("error")
        val error: Boolean,
        @SerializedName("success")
        val success: Boolean
)

data class MessageData(
        @SerializedName("successResult")
        val messageSuccessData: String,
        @SerializedName("errorResult")
        val errorSuccessData: String
)
