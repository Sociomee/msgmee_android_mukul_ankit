package com.sociomee.msgmee.ui.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.google.gson.Gson
import com.huawei.multimedia.audiokit.utils.Constant
import com.sociomee.msgmee.MsgMee
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.`interface`.LanguageSelectCallback
import com.sociomee.msgmee.ui.activity.SignUpActivity
import com.sociomee.msgmee.ui.adapter.UsernameSuggestionAdaptor
import com.sociomee.msgmee.ui.data.AuthModel
import com.sociomee.msgmee.ui.model.LanguageList
import com.sociomee.msgmee.ui.viewmodel.AuthSharedViewModel
import com.sociomee.msgmee.ui.viewmodel.CreateAccountViewModel
import com.sociomee.msgmee.utils.*
import com.sociomee.msgmee.utils.Constants.Companion.userInfo
import kotlinx.android.synthetic.main.user_credentials_fragment.*
import kotlinx.android.synthetic.main.user_credentials_fragment.btn_continue
import kotlinx.android.synthetic.main.user_credentials_fragment.img_toolbar_back

class UserCredentialsFragment : Fragment(R.layout.user_credentials_fragment),
        LanguageSelectCallback {

    lateinit var createAccountViewModel: CreateAccountViewModel
    lateinit var authSharedViewModel: AuthSharedViewModel
    private var suggestionFullList: List<List<String>> = ArrayList()
    private var suggestionList: List<String> = ArrayList()
    lateinit var suggestionAdaptor: UsernameSuggestionAdaptor
    private lateinit var selectedLanguage: LanguageList
    private var languageList = ArrayList<LanguageList>()
    var conditionAccepted = false
    var currentChunkIndex = 0
    lateinit var savedAuth : AuthModel
    private var languageId = ""
    private var langId = ""

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        langId = MyPreferences.getFromPreferences(context!!, Constants.languageId) ?: ""

        btn_continue.setOnClickListener {
            (activity as SignUpActivity).changeFragment(
                    AuthenticationUtil.SignupFragmentType.BIRTHDAY, "UserBirthdateFragment")
        }

        img_toolbar_back.setOnClickListener {
            (activity as SignUpActivity).onBackPress()
        }

        setInitialLanguage()

        initData()
        observeData()
        setViewsClick()
    }

    private fun setViewsClick() {
        cb_i_accept.setOnCheckedChangeListener { _, isChecked ->
            conditionAccepted = isChecked
        }
        btn_continue.setOnClickListener {
            registerNow()
        }
        txt_next_suggestion.setOnClickListener {
            if (currentChunkIndex < suggestionFullList.size - 1) {
                currentChunkIndex++
                suggestionList = suggestionFullList[currentChunkIndex]
                suggestionAdaptor.updateData(suggestionList)
            } else {
                txt_next_suggestion.visibility = View.GONE
            }
        }
    }

    private fun registerNow() {
        if (etd_full_name.text.isNullOrEmpty()) {
            (activity as CustomAppCompatActivity).showToast(getString(R.string.please_enter_full_))
        } else if (etd_username.text.isNullOrEmpty()) {
            (activity as CustomAppCompatActivity).showToast(getString(R.string.please_enter_username_))
        } else if (savedAuth.type == "password" && !etd_password.text.toString().isValidPassword()) {
            (activity as CustomAppCompatActivity).showToast(getString(R.string.min_password_error_))
        } else if (!conditionAccepted) {
            (activity as CustomAppCompatActivity).showToast(getString(R.string.review_terms_))
        } else {
            locationFound()
        }
    }

    private fun initData() {
        createAccountViewModel = ViewModelProvider(this,
                ViewModelProvider.NewInstanceFactory()).get(CreateAccountViewModel::class.java)
        authSharedViewModel = ViewModelProvider(requireActivity(),
                ViewModelProvider.NewInstanceFactory()).get(
                AuthSharedViewModel::class.java
        )
    }

    private fun observeData() {
        authSharedViewModel.observeSavedAuth().observe(viewLifecycleOwner, Observer {
            savedAuth = it

            if(savedAuth.type == "google" || savedAuth.type == "apple") {
                txt_enter_password.visibility = View.GONE
                txt_min_8_char.visibility = View.GONE
                etd_full_name.setText(savedAuth.socialLoginData!!.name)
            }
        })
        createAccountViewModel.observeLoading().observe(this, Observer {
            (activity as CustomAppCompatActivity).changeLoadingStatus(it)
        })
        createAccountViewModel.observeCreateAccountData().observe(this, Observer {
            when {
                it.success -> {
                    // saving user data in shared preferences
                    MyPreferences.saveStringInPreference(context!!, Constants.userDataKey, Gson().toJson(it.data.successResult))
                    Constants.userInfo = it.data.successResult

                    // initializing socket after successful signUp
                    MsgMee.initializeSocketAndListenEvents()

                    (activity as SignUpActivity).changeFragment(
                            AuthenticationUtil.SignupFragmentType.BIRTHDAY, "UserBirthdateFragment")
                }
                it.data.errorResult.message == "userNameExists" -> {
                    showUsernameSuggestion(it.data.errorResult.userNameList)
                }
                else -> {
                    (activity as CustomAppCompatActivity).showToast("Server Error")
                }
            }
        })

        // observing errors
        observeError()
    }

    private fun showUsernameSuggestion(suggestionData: List<String>) {
        img_info.visibility = View.VISIBLE
        txt_username_error.visibility = View.VISIBLE
        txt_suggestions.visibility = View.VISIBLE
        rv_name_suggestions.visibility = View.VISIBLE
        txt_next_suggestion.visibility = View.VISIBLE

        // showing first 6 suggestions
        suggestionFullList = suggestionData.chunked(6)
        suggestionList = suggestionFullList[currentChunkIndex]
        suggestionAdaptor = UsernameSuggestionAdaptor(suggestionList, this)

        rv_name_suggestions.layoutManager = GridLayoutManager(context!!, 2)
        rv_name_suggestions.adapter = suggestionAdaptor
    }

    private fun observeError() {
        createAccountViewModel.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    (activity as CustomAppCompatActivity).showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    (activity as CustomAppCompatActivity).showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    (activity as CustomAppCompatActivity).showToast("Server Error")
                }
                else -> {
                }
            }
        })
    }

    fun setInitialLanguage() {
        txt_max_char_.text = getString(R.string.max_64_characters)
        txt_enter_name.text =getString(R.string.setup_profile)
        txt_type_full_name.hint = getString(R.string.enter_your_full_)
        txt_choose_your.text = getString(R.string.choose_your_user_)
        txt_desired_name.hint = getString(R.string.enter_desired_)
        txt_16_characters.text = getString(R.string._16_characters)
        txt_enter_password.hint = getString(R.string.enter_your_password)
        txt_min_8_char.text = getString(R.string.min_6_char)
        txt_help_your_.text = getString(R.string.help_your_friends_)
        cb_i_accept.text = getString(R.string.i_accept_)
        txt_term_and_.text = getString(R.string.terms_amp_)
        btn_continue.text = getString(R.string.continue_btn)
        txt_username_error.text = getString(R.string.username_not_available)
        txt_next_suggestion.text = getString(R.string.next_suggestion)
        txt_suggestions.text = "${getString(R.string.suggestions)} : "

        img_info.visibility = View.GONE
        txt_username_error.visibility = View.GONE
        txt_suggestions.visibility = View.GONE
        txt_next_suggestion.visibility = View.GONE
        rv_name_suggestions.visibility = View.GONE
    }

    override fun languageSelectCallback(index: Int) {
        etd_username.setText(suggestionList[index])
//        selectedLanguage = languageList[index]
//        languageId = selectedLanguage.id

    }

    private fun locationFound() {
        val savedLocation = Constants.getSavedLocation(context!!)
        val bodyMap = HashMap<String, Any>()
        bodyMap["mobile"] = if (savedAuth.isEmail) "" else savedAuth.enteredCredential
        bodyMap["email"] = if (savedAuth.isEmail) savedAuth.enteredCredential else ""
        bodyMap["fullName"] = etd_full_name.text.toString()
        bodyMap["userName"] = etd_username.text.toString()
        bodyMap["password"] = etd_password.text.toString()
        bodyMap["loginMode"] = savedAuth.type
        bodyMap["platform"] = "android"
        bodyMap["ipAddress"] = ""
        bodyMap["deviceId"] = ""
        bodyMap["languagId"] = langId
        bodyMap["deviceInfo"] = getDeviceInformation(context!!)
        bodyMap["locationLAT"] = savedLocation.lat
        bodyMap["locationLONG"] = savedLocation.lng
        createAccountViewModel.createAccount(bodyMap)
    }
}