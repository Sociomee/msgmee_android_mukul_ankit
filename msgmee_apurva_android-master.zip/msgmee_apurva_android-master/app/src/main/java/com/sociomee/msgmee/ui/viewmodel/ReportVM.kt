package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.model.ReportList
import com.sociomee.msgmee.ui.repo.ReportRepo

class ReportVM : MyViewModel() {

    private var userReportList = MutableLiveData<ArrayList<ReportList>>()
    private var reportUser = MutableLiveData<Boolean>()
    private lateinit var reportRepo: ReportRepo

    // returning LiveData
    fun observeUserReportList() = userReportList
    fun observeReportUser() = reportUser

    fun reportUser(body: HashMap<String, Any>) {
        if (!this::reportRepo.isInitialized) {
            reportRepo = ReportRepo()
        }
        isLoading.value = true

        reportRepo.reportUser(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                reportUser.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

    fun getReportUserListData(body: HashMap<String, Any>) {
        if (!this::reportRepo.isInitialized) {
            reportRepo = ReportRepo()
        }
        isLoading.value = true
        reportRepo.fetchUserReportListData(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                userReportList.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }
}