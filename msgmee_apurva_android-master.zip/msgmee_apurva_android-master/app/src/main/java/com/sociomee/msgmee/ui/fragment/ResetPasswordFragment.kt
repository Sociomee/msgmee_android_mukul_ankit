package com.sociomee.msgmee.ui.fragment

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.activity.ForgotPasswordActivity
import com.sociomee.msgmee.ui.data.AuthModel
import com.sociomee.msgmee.ui.viewmodel.AuthSharedViewModel
import com.sociomee.msgmee.ui.viewmodel.ResetPasswordViewModel
import com.sociomee.msgmee.utils.isValidPassword
import kotlinx.android.synthetic.main.reset_password_fragment.*
import kotlinx.android.synthetic.main.reset_password_fragment.img_toolbar_back


class ResetPasswordFragment : Fragment(R.layout.reset_password_fragment) {

    lateinit var resetPasswordViewModel: ResetPasswordViewModel
    lateinit var authSharedViewModel: AuthSharedViewModel
    lateinit var savedAuth: AuthModel
    var isLogoutAll = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setInitialLanguage()
        setViewsClick()
        initData()
        observeData()
    }

    private fun initData() {
        resetPasswordViewModel = ViewModelProvider(this,
                ViewModelProvider.NewInstanceFactory()).get(ResetPasswordViewModel::class.java)
        authSharedViewModel = ViewModelProvider(requireActivity(),
                ViewModelProvider.NewInstanceFactory()).get(AuthSharedViewModel::class.java)
    }

    private fun observeData() {
        authSharedViewModel.observeSavedAuth().observe(viewLifecycleOwner, Observer {
            savedAuth = it
        })
        resetPasswordViewModel.observeLoading().observe(this, Observer {
            (activity as CustomAppCompatActivity).changeLoadingStatus(it)
        })
        resetPasswordViewModel.observeResetPassword().observe(this, Observer {
            when {
                it.success -> {
                    if(activity is ForgotPasswordActivity){
                        (activity as ForgotPasswordActivity).changeFragment(
                            PasswordChangedSuccessFragment(),
                            "PasswordChangedSuccessFragment")
                    }
                }
                it.messageData.errorSuccessData == "userNotExists" -> {
                    if(savedAuth.isEmail) {
                        (activity as CustomAppCompatActivity).showToast(getString(R.string.email_not_exists))
                    } else {
                        (activity as CustomAppCompatActivity).showToast(getString(R.string.mobile_not_exists))
                    }
                }
                else -> {
                    (activity as CustomAppCompatActivity).showToast(getString(R.string.something_went_wrong_))
                }
            }
        })

        // observing errors
        observeError()
    }

    private fun observeError() {
        resetPasswordViewModel.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    (activity as CustomAppCompatActivity).showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    (activity as CustomAppCompatActivity).showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    (activity as CustomAppCompatActivity).showToast("Server Error")
                }
                else -> {
                }
            }
        })
    }

    private fun setViewsClick() {
        btn_set_password.setOnClickListener {
            val password = edt_new_password.text.toString()
            val confirmPassword = edt_confirm_password.text.toString()
            if (!password.isValidPassword()) {
                txt_error.text = getString(R.string.min_password_error_)
                ll_error.visibility = View.VISIBLE
            } else if (!confirmPassword.isValidPassword() || password != confirmPassword) {
                txt_error.text = getString(R.string.confirm_password_error)
                ll_error.visibility = View.VISIBLE
            } else {
                ll_error.visibility = View.GONE

                val bodyMap = HashMap<String, Any>().apply {
                    put("isEmail", savedAuth.isEmail)
                    put("loginId", savedAuth.enteredCredential)
                    put("password", password)
                    put("logoutAll", isLogoutAll)
                }

                resetPasswordViewModel.resetPassword(bodyMap)
            }
        }
        img_toolbar_back.setOnClickListener {
            (activity as ForgotPasswordActivity).onBackPressed()
        }
        reset_checkBox.setOnCheckedChangeListener { _, isChecked ->
            isLogoutAll = isChecked
        }
    }

    private fun setInitialLanguage() {
        txt_new_password.hint = getString(R.string.new_password)
        txt_confirm_password.hint = getString(R.string.confirm_password)
        txt_reset_password.text = getString(R.string.reset_password)
        txt_password_must_.text = getString(R.string.password_must_contain_)
        reset_checkBox.text = getString(R.string.log_me_out_)
        txt_create_a_new_.text = getString(R.string.create_a_new_)
        btn_set_password.text = getString(R.string.set_password)

        ll_error.visibility = View.GONE
    }
}