package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.model.GroupInfoData
import com.sociomee.msgmee.ui.model.ChatMemberData
import com.sociomee.msgmee.ui.repo.GroupInfoRepo

class GroupInfoVM : MyViewModel() {

    private var groupInfoData = MutableLiveData<GroupInfoData>()
    private var groupPeopleList = MutableLiveData<List<ChatMemberData>>()
    private var groupUpdated = MutableLiveData<Boolean>()
    private var memberRoleChanged = MutableLiveData<Boolean>()
    private var leaveGroup = MutableLiveData<Boolean>()
    private var userRemoved = MutableLiveData<Boolean>()
    private lateinit var groupInfoRepo: GroupInfoRepo

    // returning LiveData
    fun observerGroupInfo() = groupInfoData
    fun observerGroupPeopleList() = groupPeopleList
    fun observerGroupUpdate() = groupUpdated
    fun observerMemberRoleChange() = memberRoleChanged
    fun observerGroupLeft() = leaveGroup
    fun observerUserRemoved() = userRemoved

    fun fetchGroupInfo(body: HashMap<String, Any>, showLoading: Boolean = true) {
        if (!this::groupInfoRepo.isInitialized) {
            groupInfoRepo = GroupInfoRepo()
        }
        if (showLoading)
            isLoading.value = true
        groupInfoRepo.fetchGroupInfo(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                groupInfoData.value = it.data!!
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

    fun fetchGroupPeopleList(body: HashMap<String, Any>, showLoading: Boolean = true) {
        if (!this::groupInfoRepo.isInitialized) {
            groupInfoRepo = GroupInfoRepo()
        }
        if (showLoading)
            isLoading.value = true
        groupInfoRepo.fetchGroupPeopleList(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                groupPeopleList.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

    fun updateGroupInfo(body: HashMap<String, Any>) {
        if (!this::groupInfoRepo.isInitialized) {
            groupInfoRepo = GroupInfoRepo()
        }
        isLoading.value = true
        groupInfoRepo.updateGroupInfo(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                groupUpdated.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

    fun changeGroupMemberRole(body: HashMap<String, Any>) {
        if (!this::groupInfoRepo.isInitialized) {
            groupInfoRepo = GroupInfoRepo()
        }
        isLoading.value = true
        groupInfoRepo.changeGroupMemberRole(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                memberRoleChanged.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

    fun leaveGroup(body: HashMap<String, Any>) {
        if (!this::groupInfoRepo.isInitialized) {
            groupInfoRepo = GroupInfoRepo()
        }
        isLoading.value = true
        groupInfoRepo.leaveGroup(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                leaveGroup.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

    fun removeUserFromGroup(body: HashMap<String, Any>) {
        if (!this::groupInfoRepo.isInitialized) {
            groupInfoRepo = GroupInfoRepo()
        }
        isLoading.value = true
        groupInfoRepo.removeUserFromGroup(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                userRemoved.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }
}