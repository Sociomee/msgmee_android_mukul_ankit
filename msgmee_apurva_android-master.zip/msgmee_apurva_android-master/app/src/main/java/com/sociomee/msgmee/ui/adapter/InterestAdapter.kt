package com.sociomee.msgmee.ui.adapter

import android.content.res.ColorStateList
import android.graphics.Color
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.sociomee.msgmee.ui.data.InterestModel
import com.sociomee.msgmee.R
import com.sociomee.msgmee.ui.`interface`.AddItemCallback

class InterestAdapter(val list: ArrayList<InterestModel.InterestList>,
                      private val interestSelectCallback: AddItemCallback) : RecyclerView.Adapter<InterestAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            ViewHolder(LayoutInflater.from(parent.context)
                    .inflate(R.layout.suggested_category_child, parent, false))

    override fun getItemCount() = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {


                holder.txt_category.text = list[position].name

                holder.txt_category.setTextColor(Color.WHITE)

                val selectedColor = TypedValue()
                holder.txt_category.backgroundTintList = ColorStateList.valueOf(selectedColor.data)
                holder.itemView.context.theme.resolveAttribute(R.attr.colorSecondary, selectedColor, true)
                val unselectedColor = TypedValue()
                holder.itemView.context.theme.resolveAttribute(R.attr.itemBackground, unselectedColor, true)
                val titleTextColor = TypedValue()
                holder.itemView.context.theme.resolveAttribute(R.attr.titleTextColor, titleTextColor, true)

                if (list[position].isSelected) {
                    holder.txt_category.backgroundTintList = ColorStateList.valueOf(selectedColor.data)
                    holder.txt_category.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.white))
                } else {
                    holder.txt_category.backgroundTintList = ColorStateList.valueOf(unselectedColor.data)
                    holder.txt_category.setTextColor(ColorStateList.valueOf(titleTextColor.data))
                }

                holder.itemView.setOnClickListener {
                    list[position].isSelected = !list[position].isSelected
                    interestSelectCallback.itemChanged(position,list[position].isSelected)
                    notifyDataSetChanged()
                }


    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var txt_category = itemView.findViewById<TextView>(R.id.txt_category)

    }
}
