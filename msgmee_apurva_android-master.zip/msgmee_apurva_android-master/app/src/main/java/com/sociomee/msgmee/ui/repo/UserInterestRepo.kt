package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.UserProfileApiCall
import com.sociomee.msgmee.ui.model.UserAddInterestModel
import com.sociomee.msgmee.ui.model.UserInterestModel
import retrofit2.Response

class UserInterestRepo {
    fun fetchUserInterestData(body : HashMap<String,Any>): MutableLiveData<MyResponse<List<UserInterestModel.UserInterestData.UserInterestList>>> {
        val data = MutableLiveData<MyResponse<List<UserInterestModel.UserInterestData.UserInterestList>>>()
        val retrofitService = MyRetrofit.getRetrofitService(UserProfileApiCall::class.java)
        val call = retrofitService.getUserInterest(body)

        call.enqueue(object : MyCallback<UserInterestModel> {
            override fun success(response: Response<UserInterestModel>) {
              data.postValue(MyResponse.success(response.body()!!.userInterestData.successResult.userInterestLists))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }
        })
        return data
    }

    fun fetchAddUserInterestData(body : HashMap<String,Any>) :MutableLiveData<MyResponse<UserAddInterestModel>> {

        val data = MutableLiveData<MyResponse<UserAddInterestModel>>()
        val retrofitService = MyRetrofit.getRetrofitService(UserProfileApiCall::class.java)
        val call = retrofitService.addUserInterest(body)

        call.enqueue(object : MyCallback<UserAddInterestModel> {
            override fun success(response: Response<UserAddInterestModel>) {
                data.postValue(MyResponse.success(response.body()))
            }
            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }
            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }
            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }
        })

        return data
    }
}