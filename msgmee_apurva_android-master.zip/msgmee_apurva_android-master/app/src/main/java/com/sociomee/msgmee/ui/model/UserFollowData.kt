package com.sociomee.msgmee.ui.model


import com.google.gson.annotations.SerializedName

data class UserFollowData(
        @SerializedName("data")
    val `data`: Data,
        @SerializedName("error")
    val error: Boolean,
        @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("successResult")
        val successResult: String
    )
}