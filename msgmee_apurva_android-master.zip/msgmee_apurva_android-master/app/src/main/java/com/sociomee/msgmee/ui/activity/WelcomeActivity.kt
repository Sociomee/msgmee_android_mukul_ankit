package com.sociomee.msgmee.ui.activity

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.OAuthProvider
import com.google.gson.Gson
import com.sociomee.msgmee.MsgMee
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.`interface`.LanguageSelectCallback
import com.sociomee.msgmee.ui.adapter.ChooseLanguageAdapter
import com.sociomee.msgmee.ui.model.LanguageList
import com.sociomee.msgmee.ui.viewmodel.LanguageViewModel
import com.sociomee.msgmee.ui.viewmodel.LoginViewModel
import com.sociomee.msgmee.utils.*
import kotlinx.android.synthetic.main.login_activity.*
import kotlinx.android.synthetic.main.welcome_activity.*
import kotlinx.android.synthetic.main.welcome_activity.ll_language
import kotlinx.android.synthetic.main.welcome_activity.txt_apple
import kotlinx.android.synthetic.main.welcome_activity.txt_google
import kotlinx.android.synthetic.main.welcome_activity.txt_language

class WelcomeActivity : CustomAppCompatActivity(), LanguageSelectCallback {

    lateinit var languageViewModel: LanguageViewModel
    var languageList = ArrayList<LanguageList>()
    lateinit var selectedLanguage: LanguageList
    lateinit var chooseLanguageAdapter: ChooseLanguageAdapter
    lateinit var dialog: BottomSheetDialog
    private lateinit var gso: GoogleSignInOptions
    private lateinit var googleSignInClient: GoogleSignInClient
    private var enteredDetail = ""
    private var loginType = ""
    private var isEmail = true
    private lateinit var loginViewModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.welcome_activity)

        ll_language.setOnClickListener {
            showLanguageBottomDialog()
        }

        card_signUp.setOnClickListener {
            startActivity(SignUpActivity::class.java)
        }

        card_login.setOnClickListener {
            startActivity(LoginActivity::class.java)
        }
        card_google_login.setOnClickListener {
            loginType = "google"
            isEmail = true
            val signInIntent: Intent = googleSignInClient.signInIntent
            startActivityForResult(signInIntent, GOOGLE_SIGN_IN)
        }
        card_apple_login.setOnClickListener {
            loginType = "apple"
            isEmail = true
            loginWithApple()
        }
        setupGoogleSignIn()
        initData()
        observeData()
        logOutGoogleSignIn()

    }

    private fun initData() {
        languageViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
                LanguageViewModel::class.java)
        languageViewModel.getLanguageList()
        languageList = ArrayList()
        chooseLanguageAdapter = ChooseLanguageAdapter(languageList, this)
        loginViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
                LoginViewModel::class.java
        )
    }

    private fun showLanguageBottomDialog() {
        val view = LayoutInflater.from(this).inflate(R.layout.choose_language_bottom_sheet, null)
        dialog = BottomSheetDialog(this, R.style.SheetDialog)
        dialog.setContentView(view)
        val recyclerView = view.findViewById<RecyclerView>(R.id.rv_choose_language)
        val manager = LinearLayoutManager(this)
        recyclerView.layoutManager = manager
        recyclerView.adapter = chooseLanguageAdapter
        dialog.show()
        recyclerView.addItemDecoration(DividerItemDecoration(this, manager.orientation))
    }

    override fun setInitialLanguage() {
        txt_language.text = getString(R.string.choose_language)
        txt_discover_the_.text = getString(R.string.discover_the_)
        txt_log_in.text = getString(R.string.login)
        txt_sign_up.text = getString(R.string.signup)
        txt_google.text = getString(R.string.continue_with_google)
        txt_apple.text = getString(R.string.continue_with_apple)
        txt_by_sign_in.text = getString(R.string.by_signing_)

        txt_by_sign_in.hide()
        ll_language.hide()

    }

    override fun bindData() {
    }

    private fun observeData() {
        languageViewModel.observeLanguageList().observe(this, Observer {
            languageList.addAll(it)
        })
        loginViewModel.observeLoading().observe(this, Observer {
            if (it) {
                showLoadingDialog()
            } else {
                hideLoadingDialog()
            }
        })
        loginViewModel.observeLoginUser().observe(this, Observer {
            if (it.success) {
                val intent = Intent(this, MessengerActivity::class.java)
                intent.putExtra("type", "profileOwn")
                startActivity(intent)

                // saving user data in shared preferences
                MyPreferences.saveStringInPreference(
                        this, Constants.userDataKey, Gson().toJson(
                        it.data.userInfoModel
                )
                )
                Constants.userInfo = it.data.userInfoModel

                // initializing socket after successful login
                MsgMee.initializeSocketAndListenEvents()

                finish()
            } else {
                when (it.data.errorResult) {
                    "userNotExists" -> {
                        if (isEmail) {
                            txt_invalid_email_.text = getString(R.string.email_not_exits)
                        } else {
                            txt_invalid_email_.text = getString(R.string.mobile_not_exits)
                        }
                        ll_error_message.show()
                    }
                    "incorrectPassword" -> {
                        txt_invalid_email_.text = getString(R.string.password_incorrect)
                        ll_error_message.show()
                    }
                    "incorrectLoginMode" -> {
                        txt_invalid_email_.text = getString(R.string.incorrect_login_mode)
                        ll_error_message.show()
                    }
                    else -> {
                        txt_invalid_email_.setText(R.string.something_went_wrong_)
                        ll_error_message.show()
                    }
                }
            }
        })

        // observing errors
        observeError()
    }

    private fun observeError() {
        languageViewModel.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    showToast("Server Error")
                }
                else -> {
                }
            }
        })
    }

    override fun languageSelectCallback(index: Int) {
        selectedLanguage = languageList[index]

        txt_language.text = selectedLanguage.name
        dialog.dismiss()
    }

    private fun logOutGoogleSignIn() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestIdToken(getString(R.string.default_web_client_id))
                .build()
        val googleSignInClient = GoogleSignIn.getClient(this, gso)
        googleSignInClient.signOut()
    }

    override fun onStart() {
        super.onStart()
        logOutGoogleSignIn()
    }
    private fun setupGoogleSignIn() {
        gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestIdToken(getString(R.string.default_web_client_id))
                .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == GOOGLE_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            handleSignInResult(task)
        }
    }
    private fun loginNow() {
        val savedLocation = Constants.getSavedLocation(this)
        if (!isEmail) {
            enteredDetail = "+91 $enteredDetail"
        }
        val body = HashMap<String, Any>().apply {
            put("loginId", enteredDetail)
            put("password", "")
            put("type", if (isEmail) "email" else "mobile")
            put("loginMode", loginType)
            put("platform", "android")
            put("ipAddress", "")
            put("deviceId", Settings.Secure.getString(contentResolver,
                    Settings.Secure.ANDROID_ID))
            put("fcmToken", MyPreferences.getFcmToken(this@WelcomeActivity))
            put("deviceInfo", getDeviceInformation(this@WelcomeActivity))
            put("locationLAT", savedLocation.lat)
            put("locationLONG", savedLocation.lng)
        }
        loginViewModel.loginUser(body)
    }
    private fun handleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account = completedTask.getResult(ApiException::class.java)
            if (account == null) {
                showToast(getString(R.string.something_went_wrong_))
                return
            }

            // Signed in successfully, show authenticated UI.
            enteredDetail = account.email.toString()
            loginNow()
        } catch (e: ApiException) {
            showToast(getString(R.string.something_went_wrong_))
            Log.w("harsh", "signInResult:failed code=" + e.statusCode)
        }
    }
    protected fun loginWithApple(){
        val provider = OAuthProvider.newBuilder("apple.com")
        provider.setScopes(arrayOf("email", "name").toMutableList())
        provider.addCustomParameter("locale", "en")
        val auth=FirebaseAuth.getInstance()
        val pending =auth.pendingAuthResult
        var is_pending=false;
        if (pending != null) {
            pending.addOnSuccessListener { authResult ->
                Log.d(TAG, "checkPending:onSuccess:$authResult")
                is_pending=true
                // Get the user profile with authResult.getUser() and
                // authResult.getAdditionalUserInfo(), and the ID
                // token from Apple with authResult.getCredential().
            }.addOnFailureListener { e ->
                Log.w(TAG, "checkPending:onFailure", e)
                is_pending=false
            }
        } else {
            Log.d(TAG, "pending: null")
            is_pending=false
        }
        if(!is_pending){
            auth.startActivityForSignInWithProvider(this, provider.build())
                    .addOnSuccessListener { authResult ->
                        // Sign-in successful!
                        Log.d(TAG, "activitySignIn:onSuccess:${authResult.user}")
                        val user = authResult.user
                        Log.i("url", user.toString())
                        // ...
                    }
                    .addOnFailureListener { e ->
                        Log.w(TAG, "activitySignIn:onFailure", e)
                    }
        }
    }
}
