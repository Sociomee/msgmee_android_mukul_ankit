package com.sociomee.msgmee.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.sociomee.msgmee.R
import com.sociomee.msgmee.ui.`interface`.MultiSelectCallBack
import com.sociomee.msgmee.ui.model.ChatModel
import com.sociomee.msgmee.utils.Constants

class ChatAdapter(private val chatList: ArrayList<ChatModel>,
                  private val multiSelectCallBack: MultiSelectCallBack) :
        RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var isMultiSelectOpen = false
    private var multiSelectCount = 0
    private var selectedMessageList = ArrayList<Int>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when(viewType) {
            // own message
            Constants.MessageType.MY_MESSAGE.ordinal -> {
                MyMessageHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_my_message_child, parent, false))
            }

            // other message
            Constants.MessageType.OTHER_MESSAGE.ordinal -> {
                OtherMessageHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_other_message_child, parent, false))
            }

            // own message replied
            Constants.MessageType.MY_MESSAGE_REPLY.ordinal -> {
                MyMessageReplyHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_my_message_reply_child, parent, false))
            }

            // other message replied
            Constants.MessageType.OTHER_MESSAGE_REPLY.ordinal -> {
                OtherMessageReplyHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_other_message_reply_child, parent, false))
            }

            // own media (Image, Video, GIF)
            Constants.MessageType.MY_IMAGE.ordinal, Constants.MessageType.MY_VIDEO.ordinal, Constants.MessageType.MY_GIF.ordinal -> {
                MyMediaHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_my_media_child, parent, false))
            }

            // other media (Image, Video, GIF)
            Constants.MessageType.OTHER_IMAGE.ordinal, Constants.MessageType.OTHER_VIDEO.ordinal, Constants.MessageType.OTHER_GIF.ordinal -> {
                OtherMediaHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_other_media_child, parent, false))
            }

            // own media reply (Image, Video, Audio, Contact, Doc, GIF)
            Constants.MessageType.MY_IMAGE_REPLY.ordinal, Constants.MessageType.MY_CONTACT_REPLY.ordinal,
            Constants.MessageType.MY_AUDIO_REPLY.ordinal, Constants.MessageType.MY_VIDEO_REPLY.ordinal,
            Constants.MessageType.MY_GIF_REPLY.ordinal, Constants.MessageType.MY_DOC_REPLY.ordinal -> {
                MyMediaReplyHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_my_media_reply_child, parent, false))
            }

            // other media reply (Image, Video, Audio, Contact, Doc, GIF)
            Constants.MessageType.OTHER_IMAGE_REPLY.ordinal, Constants.MessageType.OTHER_CONTACT_REPLY.ordinal,
            Constants.MessageType.OTHER_AUDIO_REPLY.ordinal, Constants.MessageType.OTHER_VIDEO_REPLY.ordinal,
            Constants.MessageType.OTHER_GIF_REPLY.ordinal, Constants.MessageType.OTHER_DOC_REPLY.ordinal -> {
                OtherMediaReplyHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_other_media_reply_child, parent, false))
            }

            // own media (with message)
            Constants.MessageType.MY_IMAGE_MESSAGE.ordinal, Constants.MessageType.MY_VIDEO_MESSAGE.ordinal -> {
                MyMediaMessageHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_my_media_data_child, parent, false))
            }

            // other media (with message)
            Constants.MessageType.OTHER_IMAGE_MESSAGE.ordinal, Constants.MessageType.OTHER_VIDEO_MESSAGE.ordinal -> {
                OtherMediaMessageHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_other_media_data_child, parent, false))
            }

            // own contact
            Constants.MessageType.MY_CONTACT.ordinal -> {
                MyContactHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_my_contact, parent, false))
            }

            // other contact
            Constants.MessageType.OTHER_CONTACT.ordinal -> {
                OtherContactHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_other_contact, parent, false))
            }

            // own audio (forward, with and without message)
            Constants.MessageType.MY_AUDIO.ordinal -> {
                MyAudioHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_my_audio, parent, false))
            }

            // other audio (forward, with and without message)
            Constants.MessageType.OTHER_AUDIO.ordinal -> {
                OtherAudioHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_other_audio, parent, false))
            }

            // own doc with forward
            Constants.MessageType.MY_DOC.ordinal -> {
                MyDocHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_my_doc, parent, false))
            }

            // other doc with forward
            Constants.MessageType.OTHER_DOC.ordinal -> {
                OtherDocHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_other_doc, parent, false))
            }

            // chat detail
            Constants.MessageType.OTHER_DOC.ordinal, Constants.MessageType.CHAT_BUBBLE.ordinal -> {
                ChatBubbleHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_bubble_child, parent, false))
            }

            // chat detail
            Constants.MessageType.UNREAD_BUBBLE.ordinal, Constants.MessageType.MESSAGE_TYPE_ERROR.ordinal -> {
                UnreadBubbleHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_unread_child, parent, false))
            }
            else -> {
                MyMessageHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_my_message_child, parent, false))
            }
        }
    }

    override fun getItemCount() = chatList.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        // for multi-select
        if (isMultiSelectOpen) {
            holder.itemView.setOnClickListener {
                if(chatList[position].messageEnumType != Constants.MessageType.CHAT_BUBBLE
                    && chatList[position].messageEnumType != Constants.MessageType.UNREAD_BUBBLE) {
                    chatList[position].isSelected = !chatList[position].isSelected
                    if (chatList[position].isSelected) {
                        multiSelectCount++
                        selectedMessageList.add(position)
                    } else {
                        multiSelectCount--
                        selectedMessageList.remove(position)
                    }
                    if (multiSelectCount == 0)
                        isMultiSelectOpen = false
                    multiSelectCallBack.notifyMultiSelectItemChange(
                        isMultiSelectOpen,
                        multiSelectCount,
                        selectedMessageList
                    )
                    notifyDataSetChanged()
                }
            }
            holder.itemView.setOnLongClickListener {
                true
            }
        } else {
            holder.itemView.setOnLongClickListener {
                if(chatList[position].messageEnumType != Constants.MessageType.CHAT_BUBBLE
                    && chatList[position].messageEnumType != Constants.MessageType.UNREAD_BUBBLE) {
                    isMultiSelectOpen = true
                    chatList[position].isSelected = !chatList[position].isSelected
                    multiSelectCount++
                    selectedMessageList.add(position)
                    multiSelectCallBack.notifyMultiSelectItemChange(
                        isMultiSelectOpen,
                        multiSelectCount,
                        selectedMessageList
                    )
                    notifyDataSetChanged()
                }
                true
            }
            holder.itemView.setOnClickListener {

            }
        }
        if(chatList[position].isSelected) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(holder.itemView.context, R.color.lite_green_60))
        } else {
            holder.itemView.setBackgroundColor(0x00000000)
        }

        when(holder) {
            is MyMessageHolder -> holder.setHolderData(chatList[position])
            is MyMessageReplyHolder -> holder.setHolderData(chatList[position])
            is OtherMessageHolder -> holder.setHolderData(chatList[position])
            is OtherMessageReplyHolder -> holder.setHolderData(chatList[position])
            is MyMediaHolder -> holder.setHolderData(chatList[position])
            is MyMediaReplyHolder -> holder.setHolderData(chatList[position])
            is MyMediaMessageHolder -> holder.setHolderData(chatList[position])
            is OtherMediaMessageHolder -> holder.setHolderData(chatList[position])
            is OtherMediaHolder -> holder.setHolderData(chatList[position])
            is OtherMediaReplyHolder -> holder.setHolderData(chatList[position])
            is MyContactHolder -> holder.setHolderData(chatList[position])
            is OtherContactHolder -> holder.setHolderData(chatList[position])
            is MyAudioHolder -> holder.setHolderData(chatList[position])
            is OtherAudioHolder -> holder.setHolderData(chatList[position])
            is MyDocHolder -> holder.setHolderData(chatList[position])
            is OtherDocHolder -> holder.setHolderData(chatList[position])
            is ChatBubbleHolder -> holder.setHolderData(chatList[position])
            is UnreadBubbleHolder -> holder.setHolderData(chatList[position])
        }
    }

    fun clearMultiSelect() {
        isMultiSelectOpen = false
        multiSelectCount = 0
        selectedMessageList.clear()
        for(i in chatList.indices) {
            chatList[i].isSelected = false
        }
        multiSelectCallBack.notifyMultiSelectItemChange(isMultiSelectOpen, multiSelectCount, selectedMessageList)
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int {
        return chatList[position].messageEnumType.ordinal
    }
}