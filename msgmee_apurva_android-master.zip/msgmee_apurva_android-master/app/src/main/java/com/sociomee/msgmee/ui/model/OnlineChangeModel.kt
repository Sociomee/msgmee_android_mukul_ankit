package com.sociomee.msgmee.ui.model

data class OnlineChangeModel(
    val userId: String,
    val username: String,
    val isOnline: Boolean
)