package com.sociomee.msgmee.ui.model

data class UserDataPassModel(val username: String, val profileThumb: String?, val userId: String)