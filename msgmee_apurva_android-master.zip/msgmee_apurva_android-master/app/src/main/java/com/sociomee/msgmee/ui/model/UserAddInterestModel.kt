package com.sociomee.msgmee.ui.model

import com.google.gson.annotations.SerializedName

data class UserAddInterestModel(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("successResult")
        val successResult: List<Any>
    )
}