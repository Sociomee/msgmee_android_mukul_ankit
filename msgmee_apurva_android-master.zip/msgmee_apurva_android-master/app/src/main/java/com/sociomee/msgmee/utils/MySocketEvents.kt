package com.sociomee.msgmee.utils

import android.util.Log
import com.google.gson.reflect.TypeToken
import com.sociomee.msgmee.MsgMee
import com.sociomee.msgmee.ui.model.*
import io.socket.client.Ack
import io.socket.emitter.Emitter
import org.greenrobot.eventbus.EventBus
import org.json.JSONObject


class MySocketEvents {

    companion object {

        var isSocketConnected = false
        var socketTimeout: Long = 1000 * 30 // 30 sec

        // socket listen events
        const val EVENT_CONNECT = "connect"
        const val EVENT_DISCONNECT = "disconnect"
        const val EVENT_CONNECT_ERROR = "connect_error"
        const val EVENT_CONNECT_TIMEOUT = "connect_timeout"
        const val EVENT_RECONNECT = "reconnect"
        const val EVENT_RECONNECT_ATTEMPT = "reconnect_attempt"
        const val EVENT_RECONNECTING = "reconnecting"
        const val EVENT_RECONNECT_ERROR = "reconnect_error"
        const val EVENT_RECONNECT_FAILED = "reconnect_failed"
        const val EVENT_USER_ONLINE = "userOnline"
        const val EVENT_USER_OFFLINE = "userOffline"
        const val EVENT_MESSAGE_READ = "messageRead"
        const val EVENT_MESSAGE_DELETED = "messageDeleted"
        const val EVENT_CALL_STATE_UPDATE = "memberCallStateChanged"
        const val EVENT_CALL_MEMBER_ADDED = "memberAdded"


        // socket emit events
        private const val WHO_AM_I = "whoAmI"
        const val EVENT_ONLINE = "online"
        const val EVENT_OFFLINE = "offline"


        // socket emit and listen both events
        const val EVENT_SERVER_TIME = "serverTime"
        const val EVENT_NEW_MESSAGE = "message"
        const val EVENT_TYPING = "userTyping"
        const val EVENT_CALL_DETAIL = "getCallRoomMembers"


        // socket emitter callbacks
        val onConnect = Emitter.Listener {
            Log.v("harshSocket", "socket connected successfully == ${it.size}")
            isSocketConnected = true

            // checking server time
            MsgMee.getSocket().emit(EVENT_SERVER_TIME, "harsh")

            MsgMee.getSocket().emit(WHO_AM_I, "this is payload", Ack { ackData ->
                Log.v("harshSocket", "whoAmI ack == ${ackData.size}")
            })

            // emitting user goes online
            MsgMee.getSocket().emit(EVENT_ONLINE)
        }

        val onDisconnect = Emitter.Listener {
            Log.v("harshSocket", "socket disconnected == ${it.size}")
            isSocketConnected = false
        }

        val onConnectError = Emitter.Listener {
            Log.v("harshSocket", "socket connect error == ${it.size}")
        }

        val onConnectTimeout = Emitter.Listener {
            Log.v("harshSocket", "socket connect timeout == ${it.size}")
        }

        val onReconnect = Emitter.Listener {
            Log.v("harshSocket", "socket reconnect == ${it.size}")
        }

        val onReconnectAttempt = Emitter.Listener {
            Log.v("harshSocket", "socket reconnect attempt == ${it.size}")
        }

        val onReconnecting = Emitter.Listener {
            Log.v("harshSocket", "socket reconnecting == ${it.size}")
        }

        val onReconnectError = Emitter.Listener {
            Log.v("harshSocket", "socket reconnect error == ${it.size}")
        }

        val onReconnectFailed = Emitter.Listener {
            Log.v("harshSocket", "socket reconnect failed == ${it.size}")
        }

        val serverTime = Emitter.Listener {
            Log.v("harshSocket", "socket server time == ${it.size}")
        }

        val userTyping = Emitter.Listener {
            val data = it[0] as JSONObject
            Log.v("harshSocket", "socket server time == ${it.size}")
            EventBus.getDefault().post(
                TypingModel(
                    (data["typingUser"] as JSONObject)["userName"] as String,
                    (data["typingUser"] as JSONObject)["id"] as String,
                    (data["chatHead"] as JSONObject)["chatHeadId"] as String
                )
            )
        }

        val messageDeleted = Emitter.Listener {
            Log.v("harshSocket", "socket messageDeleted time == ${it.size}")
            val data = it[0] as JSONObject
            val messageIdType = object : TypeToken<ArrayList<String>>() {}.type
            val messageIds: ArrayList<String> = Constants.myGson.fromJson(
                data["messageIds"].toString(),
                messageIdType
            )
            EventBus.getDefault().post(
                MessageDeleteModel(
                    true,
                    null,
                    messageIds,
                    (data["chatHead"] as JSONObject)["chatHeadId"] as String
                )
            )
        }

        val userOnline = Emitter.Listener {
            Log.v("harshSocket", "userOnline == ${it.size}")
            val data = it[0] as JSONObject
            EventBus.getDefault().post(
                OnlineChangeModel(
                    data["id"] as String,
                    data["userName"] as String,
                    true
                )
            )
        }

        val userOffline = Emitter.Listener {
            Log.v("harshSocket", "userOffline time == ${it.size}")
            val data = it[0] as JSONObject
            EventBus.getDefault().post(
                OnlineChangeModel(
                    data["id"] as String,
                    data["userName"] as String,
                    false
                )
            )
        }

        val newMessage = Emitter.Listener {
            try {
                val data = it[0] as JSONObject
                Log.v("harshSocket", "newMessage == ${it.size}")

                val messageType = object : TypeToken<ArrayList<ChatModel>>() {}.type

                val chatHeadData = Constants.myGson.fromJson(
                    data["chatHead"].toString(),
                    ChatHeadData::class.java
                )

                val messageList: ArrayList<ChatModel> = Constants.myGson.fromJson(
                    data["messages"].toString(),
                    messageType
                )
                // adding chatHeadId to messages
                messageList.forEach { model ->
                    model.chatHeadId = chatHeadData.chatHeadId
                }


                // now posting data using event bus
                if (messageList.size > 0)
                    EventBus.getDefault().post(messageList)
                EventBus.getDefault().post(chatHeadData)

            } catch (e: Exception) {
                Log.v("harshSocket", "newMessage error == ${e.message}")
            }
        }

        val callStateUpdate = Emitter.Listener {
            try {
                val data = it[0] as JSONObject
                Log.v("harshSocket", "callStateUpdate == $it")

                // now posting data using event bus
                EventBus.getDefault().post(CallStateUpdateModel(data["memberId"] as String, data["newState"] as String))
            } catch (e: Exception) {
                Log.v("harshSocket", "newMessage error == ${e.message}")
            }
        }

        val callMemberAdded = Emitter.Listener {
            try {
                val data = it[0] as JSONObject
                Log.v("harshSocket", "callStateUpdate == $it")

                // now posting data using event bus
                val model = Constants.myGson.fromJson(data.toString(), CallNewUserModel::class.java)
                EventBus.getDefault().post(model)
            } catch (e: Exception) {
                Log.v("harshSocket", "newMessage error == ${e.message}")
            }
        }
    }

}