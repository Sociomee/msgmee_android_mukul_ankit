package com.sociomee.msgmee.ui.model

import com.sociomee.msgmee.utils.Constants

data class MessageDemoModel(val message : String, val messageType: Constants.MessageType,
                            val messageTime : String, val senderName : String, val replyText : String, var isSelected : Boolean = false)