package com.sociomee.msgmee.ui.activity

import android.os.Bundle
import androidx.fragment.app.Fragment
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.ui.fragment.ForgotPasswordFragment

class ForgotPasswordActivity : CustomAppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.forgot_password_activity)
        supportFragmentManager
                .beginTransaction()
                .replace(R.id.forgot_container, ForgotPasswordFragment(),"ForgotPassword")
                .commit()
    }

    fun changeFragment(fragment :Fragment,fragmentName:String){
        supportFragmentManager
                .beginTransaction()
                .setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left,R.anim.enter_from_left, R.anim.exit_to_right)
                .replace(R.id.forgot_container, fragment,"ForgotPassword")
                .commit()
    }

    override fun setInitialLanguage() {

    }

    override fun bindData() {

    }
}