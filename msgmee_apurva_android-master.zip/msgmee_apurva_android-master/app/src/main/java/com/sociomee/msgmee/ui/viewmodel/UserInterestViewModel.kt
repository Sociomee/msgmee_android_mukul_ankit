package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.model.UserAddInterestModel
import com.sociomee.msgmee.ui.model.UserInterestModel
import com.sociomee.msgmee.ui.repo.UserInterestRepo

class UserInterestViewModel : MyViewModel() {
    private var userInterestList = MutableLiveData<List<UserInterestModel.UserInterestData.UserInterestList>>()
    private lateinit var userInterestRepo: UserInterestRepo

    var userAddInterestModel = MutableLiveData<UserAddInterestModel>()
    lateinit var userAddInterestRepo : UserInterestRepo

    // returning LiveData
    fun observeUserInterestList() = userInterestList

    fun observeUserAddInterests() = userAddInterestModel

    fun getUserInterestList(body:HashMap<String,Any>){
        if (!this::userInterestRepo.isInitialized){
            userInterestRepo = UserInterestRepo()
        }
        isLoading.value = true
        userInterestRepo.fetchUserInterestData(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS){
                userInterestList.value = it.data
            }else{
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

    fun userAddInterest(body:HashMap<String,Any>){
        if (!this::userAddInterestRepo.isInitialized){
            userAddInterestRepo = UserInterestRepo()
        }
        isLoading.value = true
        userAddInterestRepo.fetchAddUserInterestData(body).observeForever {
            if (it.status==ResponseStatus.SUCCESS){
                userAddInterestModel.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }
}