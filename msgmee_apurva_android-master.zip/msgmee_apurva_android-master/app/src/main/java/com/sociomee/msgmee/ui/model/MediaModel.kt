package com.sociomee.msgmee.ui.model

import android.net.Uri
import com.sociomee.msgmee.utils.Constants

data class MediaModel(
    val mediaPath: String,
    val mediaType: Constants.SelectedMediaType,
    val mediaUri: Uri? = null
)