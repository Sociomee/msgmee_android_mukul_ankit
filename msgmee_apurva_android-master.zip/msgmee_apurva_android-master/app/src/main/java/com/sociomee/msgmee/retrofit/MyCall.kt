package com.sociomee.msgmee.retrofit

interface MyCall<T> {

    fun cancel()

    fun enqueue(callback: MyCallback<T>)

}