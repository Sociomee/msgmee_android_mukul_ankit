package com.sociomee.msgmee.ui.`interface`

interface AddItemCallback {

    fun itemChanged(position : Int, isChecked : Boolean)

    fun itemRemoved(position: Int)
}