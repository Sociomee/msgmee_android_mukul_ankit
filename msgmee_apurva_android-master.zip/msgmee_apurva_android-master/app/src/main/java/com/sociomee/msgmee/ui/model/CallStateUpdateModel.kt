package com.sociomee.msgmee.ui.model

data class CallStateUpdateModel(val memberId: String, val newState: String)