package com.sociomee.msgmee.ui.model


import com.google.gson.annotations.SerializedName

data class GroupInfoModel(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("successResult")
        val groupInfoModel: GroupInfoData
    )
}
data class GroupInfoData(
    @SerializedName("groupId")
    val groupId: String,
    @SerializedName("groupImageURL")
    val groupImageURL: String?,
    @SerializedName("groupName")
    val groupName: String,
    @SerializedName("groupSummary")
    val groupSummary: String?,
    @SerializedName("groupThumbURL")
    val groupThumbURL: String?,
    @SerializedName("isMute")
    val isMute: Int,
    @SerializedName("membersCount")
    val membersCount: Int,
    @SerializedName("role")
    val role: String
)