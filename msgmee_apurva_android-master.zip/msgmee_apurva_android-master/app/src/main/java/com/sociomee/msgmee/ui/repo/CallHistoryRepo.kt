package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.ApiCall
import com.sociomee.msgmee.ui.model.CallHistoryModel
import retrofit2.Response

class CallHistoryRepo {

    fun fetchCallHistoryList(body: HashMap<String, Any>): MutableLiveData<MyResponse<CallHistoryModel.Data>> {
        val data = MutableLiveData<MyResponse<CallHistoryModel.Data>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.fetchCallHistory(body)

        call.enqueue(object : MyCallback<CallHistoryModel> {
            override fun success(response: Response<CallHistoryModel>) {
                data.postValue(MyResponse.success(response.body()!!.data))
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

        })
        return data
    }

    fun fetchUserCallHistoryList(body: HashMap<String, Any>): MutableLiveData<MyResponse<CallHistoryModel.Data>> {
        val data = MutableLiveData<MyResponse<CallHistoryModel.Data>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.fetchUserCallHistoryList(body)

        call.enqueue(object : MyCallback<CallHistoryModel> {
            override fun success(response: Response<CallHistoryModel>) {
                data.postValue(MyResponse.success(response.body()!!.data))
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

        })
        return data
    }

}