package com.sociomee.msgmee.utils

import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.*
import java.net.HttpURLConnection
import java.net.URL

class DownloadFile {

    fun downloadFile(
        messageId: String,
        parentFolder: String,
        fileName: String,
        fileServerPath: String,
        processCallback: (String, Int) -> Unit,
        downloadCompleteCallback: (String, Boolean) -> Unit
    ) {
        val downloadThread = Thread() {
            kotlin.run {
                Looper.prepare()

                val downloadHandler = Handler(Looper.myLooper()!!)
                downloadHandler.post {

                    var success = false
                    var fileOutput: FileOutputStream? = null
                    var inputStream: InputStream? = null

                    try {
                        val url = URL(fileServerPath)
                        val urlConnection = url.openConnection() as HttpURLConnection
                        //            urlConnection.setRequestMethod("GET");
                        //            urlConnection.setDoOutput(false);
                        urlConnection.connect()

                        // input stream to read file - with 8k buffer
                        val file = File(parentFolder + fileName)
                        file.createNewFile()
                        fileOutput = FileOutputStream(file)
                        inputStream = urlConnection.inputStream
                        val buffer = ByteArray(1024)
                        var bufferLength: Int
                        var read = 0
                        val total = urlConnection.contentLength
                        while (inputStream.read(buffer).also { bufferLength = it } > 0) {
                            fileOutput.write(buffer, 0, bufferLength)
                            read += bufferLength
                            if (total > 0) {
                                val progress = (100 * (read / total.toFloat())).toInt()
                                processCallback(messageId, progress)
                            }
                        }
                        success = true
                        Log.v("harshDownload", "download end reached")
                    } catch (e: IOException) {
                        Log.v("harshDownload", "download catch error == ${e.message}")
                        e.printStackTrace()
                    } finally {
                        fileOutput?.close()
                        inputStream?.close()
                    }
                    Log.v("harshDownload", "success == $success")
                    downloadCompleteCallback(messageId, success)

                    Looper.myLooper()?.quit()
                }
                Looper.loop()
            }
        }
        downloadThread.start()
    }
}