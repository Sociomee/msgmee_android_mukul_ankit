package com.sociomee.msgmee.ui.model

data class MyAudioChange(val messageId: String, val type: String, val progress: Int = 0, val isLoading: Boolean = false)