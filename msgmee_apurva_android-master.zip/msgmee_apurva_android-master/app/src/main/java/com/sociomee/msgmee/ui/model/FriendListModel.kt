package com.sociomee.msgmee.ui.model


import com.google.gson.annotations.SerializedName

data class FriendListModel(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("successResult")
        val successResult: SuccessResult
    ) {
        data class SuccessResult(
            @SerializedName("count")
            val count: Int,
            @SerializedName("rows")
            val rows: List<FriendModel>,
            var isRefresh: Boolean = true
        )
    }
}

data class FriendModel(
    @SerializedName("fullName")
    val fullName: String,
    @SerializedName("gender")
    val gender: String,
    @SerializedName("id")
    val id: String,
    @SerializedName("profileImageThumb")
    val profileImageThumb: String?,
    @SerializedName("userName")
    val userName: String,
    @SerializedName("chatHeadId")
    val chatHeadId: String,
    @SerializedName("sequenceNo")
    val userSequenceNo: Int,
    var isSelected: Boolean = false,
    var isInCall: Boolean = false
)