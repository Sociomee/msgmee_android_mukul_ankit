package com.sociomee.msgmee.ui.model

import android.widget.ProgressBar
import android.widget.SeekBar
import com.sociomee.msgmee.custom.widget.CustomImageView

data class MediaPlayModel(
    val chatModel: ChatModel,
    val seekBar: SeekBar,
    val loadingBar: ProgressBar,
    val imgPlayPause: CustomImageView,
    val playPercentage: Int = 0
)