package com.sociomee.msgmee.utils

class AuthenticationUtil {

    enum class SignupFragmentType {
        USER_CONTACT,
        OTP,
        BIRTHDAY,
        CREDENTIAL,
        INTEREST
    }

    enum class OtpType(val type: String)  {
        SIGNUP("signup"),
        RESET_PASSWORD("resetPassword"),
        FORGOT_PASSWORD("forgotPassword"),
        ADD_CONTACT("addContact"),
    }

}