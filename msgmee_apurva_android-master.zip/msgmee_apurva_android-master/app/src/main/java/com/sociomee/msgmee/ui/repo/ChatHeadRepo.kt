package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.ApiCall
import com.sociomee.msgmee.ui.model.ChatHeadModel
import com.sociomee.msgmee.ui.model.MessageResponse
import retrofit2.Response

class ChatHeadRepo {

    fun fetchChatHeadList(body: HashMap<String, Any>): MutableLiveData<MyResponse<ChatHeadModel.Data.SuccessResult>> {
        val data = MutableLiveData<MyResponse<ChatHeadModel.Data.SuccessResult>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.fetchChatHead(body)

        call.enqueue(object : MyCallback<ChatHeadModel> {
            override fun success(response: Response<ChatHeadModel>) {
                data.postValue(MyResponse.success(response.body()!!.data.successResult))
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }
        })
        return data
    }

    fun changeChatArchive(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.changeChatHeadArchive(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }
        })
        return data
    }

    fun changeChatHeadPin(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.changeChatHeadPin(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }
        })
        return data
    }

    fun changeChatHeadMute(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.changeChatHeadMute(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }
        })
        return data
    }

    fun deleteChatHeads(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.deleteChatHeads(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }
        })
        return data
    }

}