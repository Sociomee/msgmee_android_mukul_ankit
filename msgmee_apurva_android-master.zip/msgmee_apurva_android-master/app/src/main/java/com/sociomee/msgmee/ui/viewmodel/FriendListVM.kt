package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.model.FriendListModel
import com.sociomee.msgmee.ui.repo.FriendListRepo

class FriendListVM: MyViewModel() {

    private var friendList = MutableLiveData<FriendListModel.Data.SuccessResult>()
    private var createChatHead = MutableLiveData<Boolean>()
    private var broadcastCreated = MutableLiveData<Boolean>()
    private var friendsAddedToGroup = MutableLiveData<Boolean>()
    private lateinit var friendListRepo: FriendListRepo

    // returning LiveData
    fun observeFriendList() = friendList
    fun observeChatHeadCreation() = createChatHead
    fun observeBroadcastCreation() = broadcastCreated
    fun observeFriendAddToGroup() = friendsAddedToGroup

    fun fetchFriendList(body: HashMap<String, Any>, isRefresh: Boolean) {
        if (!this::friendListRepo.isInitialized) {
            friendListRepo = FriendListRepo()
        }
        isLoading.value = true
        friendListRepo.fetchFriendList(body).observeForever{
            if(it.status == ResponseStatus.SUCCESS) {
                it.data!!.isRefresh = isRefresh
                friendList.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

    fun fetchGroupNonMemberList(body: HashMap<String, Any>, isRefresh: Boolean) {
        if (!this::friendListRepo.isInitialized) {
            friendListRepo = FriendListRepo()
        }
        isLoading.value = true
        friendListRepo.fetchFriendList(body, isGroupNonMemberList = true).observeForever{
            if(it.status == ResponseStatus.SUCCESS) {
                it.data!!.isRefresh = isRefresh
                friendList.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

    fun createChatHead(body: HashMap<String, Any>) {
        isLoading.value = true
        friendListRepo.createChatHead(body).observeForever{
            if(it.status == ResponseStatus.SUCCESS) {
                createChatHead.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

    fun createBroadcast(body: HashMap<String, Any>) {
        isLoading.value = true
        friendListRepo.createBroadcast(body).observeForever{
            if(it.status == ResponseStatus.SUCCESS) {
                broadcastCreated.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

    fun addFriendsToGroup(body: HashMap<String, Any>) {
        isLoading.value = true
        friendListRepo.addFriendsToGroup(body).observeForever{
            if(it.status == ResponseStatus.SUCCESS) {
                friendsAddedToGroup.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }
}