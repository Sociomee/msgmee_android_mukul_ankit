package com.sociomee.msgmee.ui.model


import com.google.gson.annotations.SerializedName

data class MessageNotificationModel(
    @SerializedName("chatHeadId")
    val chatHeadId: String,
    @SerializedName("chatHeadSequenceNo")
    val chatHeadSequenceNo: Int,
    @SerializedName("chatHeadType")
    val chatHeadType: String,
    @SerializedName("chatName")
    val chatName: String,
    @SerializedName("chatProfile")
    val chatProfile: String?,
    @SerializedName("chatTypeId")
    val chatTypeId: String,
    @SerializedName("messageList")
    val messageList: List<MessageNotificationData>
)
data class MessageNotificationData(
    @SerializedName("imageUrl")
    val imageUrl: String?,
    @SerializedName("isDeletedForAll")
    val isDeletedForAll: Int,
    @SerializedName("messageId")
    val messageId: String,
    @SerializedName("messageText")
    val messageText: String,
    @SerializedName("messageType")
    val messageType: String,
    @SerializedName("senderFullName")
    val senderFullName: String,
    @SerializedName("senderProfilePicture")
    val senderProfilePicture: String?,
    @SerializedName("senderUserId")
    val senderUserId: String,
    @SerializedName("senderUsername")
    val senderUsername: String
)