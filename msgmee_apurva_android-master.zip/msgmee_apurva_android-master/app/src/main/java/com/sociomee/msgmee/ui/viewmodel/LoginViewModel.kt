package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.retrofit.model.IPModel
import com.sociomee.msgmee.ui.model.UserDataModel
import com.sociomee.msgmee.ui.repo.LoginRepo

class LoginViewModel : MyViewModel() {

    var location = MutableLiveData<IPModel>()
    var loginModel = MutableLiveData<UserDataModel>()
    private lateinit var loginRepo: LoginRepo

    // returning LiveData
    fun observeLoginUser() = loginModel

    fun loginUser(body: HashMap<String, Any>) {
        if (!this::loginRepo.isInitialized) {
            loginRepo = LoginRepo()
        }
        isLoading.value = true
        loginRepo.loginUser(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                loginModel.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }
}