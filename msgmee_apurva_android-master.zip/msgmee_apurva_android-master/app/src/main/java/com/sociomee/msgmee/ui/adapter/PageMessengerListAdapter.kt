package com.sociomee.msgmee.ui.adapter

import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomTextView

class PageMessengerListAdapter : RecyclerView.Adapter<PageMessengerListAdapter.MarketListHolder>() {

    var selectedPosition = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = MarketListHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.page_messenger_list, parent ,false)
    )

    override fun getItemCount() = 10

    override fun onBindViewHolder(holder: MarketListHolder, position: Int) {
        val data = "Page $position"
        holder.txt_page.text = data

        val typedValue = TypedValue()
        holder.itemView.context.theme.resolveAttribute(R.attr.titleTextColor, typedValue, true)

        if(selectedPosition == position) {
            holder.txt_page.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.lite_green_100))
            holder.bottom_line.visibility = View.VISIBLE
        } else {
            holder.bottom_line.visibility = View.GONE
            holder.txt_page.setTextColor(typedValue.data)
        }

        holder.itemView.setOnClickListener {
            selectedPosition = position
            notifyDataSetChanged()
        }
    }

    class MarketListHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txt_page = itemView.findViewById<CustomTextView>(R.id.txt_page)
        val bottom_line = itemView.findViewById<View>(R.id.bottom_line)
    }
}