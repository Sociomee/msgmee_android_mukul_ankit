package com.sociomee.msgmee.ui.model


import com.google.gson.annotations.SerializedName

data class ChatHeadResponse(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("successResult")
        val successResult: List<ChatHeadInfoModel>
    )
}

data class ChatHeadInfoModel(
    @SerializedName("broadcastId")
    val broadcastId: String,
    @SerializedName("broadcastListName")
    val broadcastListName: String,
    @SerializedName("broadcastMembersCount")
    val broadcastMembersCount: Int,
    @SerializedName("chatHeadId")
    val chatHeadId: String,
    @SerializedName("chatHeadType")
    val chatHeadType: String,
    @SerializedName("fullName")
    val fullName: String,
    @SerializedName("groupId")
    val groupId: String,
    @SerializedName("groupImageThumb")
    var groupImageThumb: String?,
    @SerializedName("groupMembersCount")
    val groupMembersCount: Int,
    @SerializedName("groupName")
    var groupName: String,
    @SerializedName("isMute")
    val isMute: Int,
    @SerializedName("isOnline")
    var isOnline: Int,
    @SerializedName("isPinned")
    val isPinned: Int,
    @SerializedName("lastMessageDate")
    val lastMessageDate: String,
    @SerializedName("lastMessageId")
    val lastMessageId: String,
    @SerializedName("lastMessageText")
    val lastMessageText: String,
    @SerializedName("lastMessageType")
    val lastMessageType: String,
    @SerializedName("otherUserId")
    val otherUserId: String,
    @SerializedName("profileImageThumb")
    val profileImageThumb: String,
    @SerializedName("userId")
    val userId: String,
    @SerializedName("userLastActivity")
    val userLastActivity: String,
    @SerializedName("isBlockedByMe")
    val isBlockedByMe: Int? = 0,
    @SerializedName("isBlockedByOther")
    val isBlockedByOther: Int? = 0,
    @SerializedName("isGroupMember")
    val isGroupMember: Int? = 0
)