package com.sociomee.msgmee.ui.repo

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.ui.data.CreateAccountModel
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.LoginApiCall
import retrofit2.Response

class CreateAccountRepo {

    fun createAccount(body: HashMap<String, Any>): MutableLiveData<MyResponse<CreateAccountModel>> {
        val data = MutableLiveData<MyResponse<CreateAccountModel>>()
        val retrofitService = MyRetrofit.getRetrofitService(LoginApiCall::class.java)
        val call = retrofitService.createAccount(body)

        call.enqueue(object: MyCallback<CreateAccountModel> {
            override fun success(response: Response<CreateAccountModel>) {
                data.postValue(MyResponse.success(response.body()))
            }

            override fun serverError() {
                Log.v("harshAPI", "server error")
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }

}