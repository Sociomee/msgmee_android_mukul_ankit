package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.LoginApiCall
import com.sociomee.msgmee.ui.model.MessageResponse
import retrofit2.Response

class UserUpdateRepo {

    fun updateUser(body: HashMap<String, Any>) : MutableLiveData<MyResponse<Boolean>>{
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(LoginApiCall::class.java)
        val call = retrofitService.userUpdate(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(true))
                }
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }
        })

        return data
    }
}