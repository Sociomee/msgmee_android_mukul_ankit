package com.sociomee.msgmee.ui.model

data class ChatHeadInfo(
    var chatHeadId: String?,
    var chatName: String,
    var chatProfile: String?,
    val chatHeadType: String,
    val chatTypeId: String,
    val chatHeadSequence: Int = 0
)