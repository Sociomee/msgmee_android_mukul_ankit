package com.sociomee.msgmee.ui.`interface`

import com.sociomee.msgmee.retrofit.MyCall
import com.sociomee.msgmee.ui.model.*
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface ApiCall {

    @POST("/public/getAllAppLanguages")
    fun getLanguageList(): MyCall<LanguageModel>

    @POST("/public/userEmailAvailable")
    fun checkEmailAvailability(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/public/userMobileAvailable")
    fun checkMobileAvailability(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/public/login")
    fun loginUser(@Body body: HashMap<String, Any>): MyCall<UserDataModel>

    @POST("/user/update")
    fun userUpdate(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/getFriendsList")
    fun fetchFriendList(@Body body: HashMap<String, Any>): MyCall<FriendListModel>

    @POST("/messenger/createUserChatHead")
    fun createChatHead(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/getChatHeadList")
    fun fetchChatHead(@Body body: HashMap<String, Any>): MyCall<ChatHeadModel>

    @POST("/messenger/getChatHeadById")
    fun getChatHeadById(@Body body: HashMap<String, Any>): MyCall<ChatHeadResponse>

    @POST("/messenger/createGroup")
    fun createGroup(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/setChatHeadPin")
    fun changeChatHeadPin(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/setChatHeadMute")
    fun changeChatHeadMute(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/deleteChatHeads")
    fun deleteChatHeads(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/createBroadcastList")
    fun createBroadcast(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/sendMessage")
    fun sendMessageToChatHead(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/sendUserMessage")
    fun sendMessageToUser(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/getChatHeadMessages")
    fun fetchChatHeadMessages(@Body body: HashMap<String, Any>): MyCall<ChatDataModel>

    @POST("/messenger/getGroupById")
    fun fetchGroupInfo(@Body body: HashMap<String, Any>): MyCall<GroupInfoModel>

    @POST("/messenger/getGroupMembers")
    fun fetchGroupPeopleList(@Body body: HashMap<String, Any>): MyCall<ChatMemberModel>

    @POST("/messenger/updateGroup")
    fun updateGroupInfo(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/getBroadcastMembers")
    fun fetchBroadcastPeopleList(@Body body: HashMap<String, Any>): MyCall<ChatMemberModel>

    @POST("/messenger/getGroupMembersToAdd")
    fun fetchGroupNonMemberList(@Body body: HashMap<String, Any>): MyCall<FriendListModel>

    @POST("/messenger/changeGroupMembersRole")
    fun changeGroupMemberRole(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/leaveGroup")
    fun leaveGroup(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/removeUsersFromGroup")
    fun removeUserFromGroup(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/addUsersInGroup")
    fun addFriendsToGroup(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/deleteMessagesForMe")
    fun deleteMessagesForMe(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/deleteMessagesForAll")
    fun deleteMessagesForAll(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/clearChatHead")
    fun clearChatHead(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/user/reportUser")
    fun reportUser(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/admin/getReportOptions")
    fun getUserReportList(@Body body: HashMap<String, Any>): MyCall<UserReportModel>

    @POST("/messenger/searchChatHeadMessages")
    fun searchMessages(@Body body: HashMap<String, Any>): MyCall<SearchMessageModel>

    @POST("/messenger/setChatHeadArchive")
    fun changeChatHeadArchive(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/getForwardToList")
    fun fetchForwardToList(@Body body: HashMap<String, Any>): MyCall<ForwardToModel>

    @POST("/messenger/forwardMessages")
    fun forwardMessages(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/test/insertTestData")
    fun testApi(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/initiateCall")
    fun initiateCall(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/updateMemberCallState")
    fun updateCallState(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/updateMemberCallState")
    fun acceptCall(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/updateMemberCallState")
    fun declineCall(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/addToCall")
    fun addUserInCall(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/endCall")
    fun removeUserFromCall(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/messenger/getAllCallHistory")
    fun fetchCallHistory(@Body body: HashMap<String, Any>): MyCall<CallHistoryModel>

    @POST("/messenger/getUserCallHistory")
    fun fetchUserCallHistoryList(@Body body: HashMap<String, Any>): MyCall<CallHistoryModel>

    @POST("/messenger/missedCall")
    fun addMissedCall(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/user/update/")
    fun updateUserDetails(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/user/logOut")
    fun logOutUser(): MyCall<MessageResponse>
}