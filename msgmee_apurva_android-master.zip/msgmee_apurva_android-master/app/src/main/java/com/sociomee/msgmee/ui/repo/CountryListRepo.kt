package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.LoginApiCall
import com.sociomee.msgmee.ui.data.CountryDataModel
import com.sociomee.msgmee.ui.data.CountryListModel
import retrofit2.Response

class CountryListRepo {

    fun getCountryList(): MutableLiveData<MyResponse<ArrayList<CountryDataModel>>> {
        val data = MutableLiveData<MyResponse<ArrayList<CountryDataModel>>>()
        val retrofitService = MyRetrofit.getRetrofitService(LoginApiCall::class.java)
        val call = retrofitService.getCountryList()

        call.enqueue(object : MyCallback<CountryListModel> {
            override fun success(response: Response<CountryListModel>) {
                data.postValue(MyResponse.success(response.body()!!.data.row.countryList))
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }
        })

        return data
    }
}