package com.sociomee.msgmee.ui.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.`interface`.LanguageSelectCallback
import com.sociomee.msgmee.ui.activity.ForgotPasswordActivity
import com.sociomee.msgmee.ui.activity.SignUpActivity
import com.sociomee.msgmee.ui.adapter.ChooseLanguageAdapter
import com.sociomee.msgmee.ui.adapter.CountrySpinnerAdaptor
import com.sociomee.msgmee.ui.data.AuthModel
import com.sociomee.msgmee.ui.data.CountryDataModel
import com.sociomee.msgmee.ui.model.LanguageList
import com.sociomee.msgmee.ui.viewmodel.AuthSharedViewModel
import com.sociomee.msgmee.ui.viewmodel.CountryListVM
import com.sociomee.msgmee.ui.viewmodel.LanguageViewModel
import com.sociomee.msgmee.ui.viewmodel.RegisterViewModel
import com.sociomee.msgmee.utils.AuthenticationUtil
import com.sociomee.msgmee.utils.hide
import com.sociomee.msgmee.utils.isValidEmail
import com.sociomee.msgmee.utils.isValidMobile
import kotlinx.android.synthetic.main.forgot_password_fragment.*
import kotlinx.android.synthetic.main.forgot_password_fragment.countryCodeSpinner
import kotlinx.android.synthetic.main.forgot_password_fragment.ll_language
import kotlinx.android.synthetic.main.forgot_password_fragment.txt_apple
import kotlinx.android.synthetic.main.forgot_password_fragment.txt_choose_your_
import kotlinx.android.synthetic.main.forgot_password_fragment.txt_get_started
import kotlinx.android.synthetic.main.forgot_password_fragment.txt_language
import kotlinx.android.synthetic.main.forgot_password_fragment.txt_user_notice

class ForgotPasswordFragment : Fragment(R.layout.forgot_password_fragment), LanguageSelectCallback {

    lateinit var languageViewModel: LanguageViewModel
    var languageList = ArrayList<LanguageList>()
    private lateinit var authSharedViewModel: AuthSharedViewModel
    lateinit var selectedLanguage: LanguageList
    lateinit var chooseLanguageAdapter: ChooseLanguageAdapter
    lateinit var dialog: BottomSheetDialog
    private lateinit var registerViewModel: RegisterViewModel
    var enteredRegisterDetail = ""
    var isEmail = true
    private lateinit var countryListVM: CountryListVM
    private lateinit var countryAdapter: CountrySpinnerAdaptor
    private var selectedCountry: CountryDataModel? = null
    private var countryList = ArrayList<CountryDataModel>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setInitialLanguage()

        ll_language.hide()

        initData()
        observeData()
        setViewsClick()
    }

    private fun initData() {
        authSharedViewModel = ViewModelProvider(requireActivity(),
                ViewModelProvider.NewInstanceFactory()).get(
                AuthSharedViewModel::class.java
        )
        languageViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
                LanguageViewModel::class.java)
        registerViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
                RegisterViewModel::class.java)
        countryListVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
                CountryListVM::class.java)

        languageList = ArrayList()
        chooseLanguageAdapter = ChooseLanguageAdapter(languageList, this)
        languageViewModel.getLanguageList()
        countryListVM.getCountryList()
    }

    private fun showLanguageBottomDialog() {
        val view = LayoutInflater.from(context!!)
                .inflate(R.layout.choose_language_bottom_sheet, null)
        dialog = BottomSheetDialog(context!!, R.style.SheetDialog)
        dialog.setContentView(view)
        val recyclerView = view.findViewById<RecyclerView>(R.id.rv_choose_language)
        val manager = LinearLayoutManager(context!!)
        recyclerView.layoutManager = manager
        recyclerView.adapter = chooseLanguageAdapter
        dialog.show()
        recyclerView.addItemDecoration(DividerItemDecoration(context!!, manager.orientation))
    }

    private fun observeData() {
        languageViewModel.observeLanguageList().observe(this, Observer {
            languageList.addAll(it)
        })
        registerViewModel.observeLoading().observe(this, Observer {
            (activity as CustomAppCompatActivity).changeLoadingStatus(it!!)
        })
        registerViewModel.observeLoginIdAvailability().observe(this, Observer {
            if (!it) {
                ll_error.visibility = View.GONE

                // now sending otp
                val bodyMap = HashMap<String, Any>().apply {
                    put("isEmail", isEmail)
                    put("type", AuthenticationUtil.OtpType.FORGOT_PASSWORD.type)
                    if (isEmail) {
                        put("email", enteredRegisterDetail)
                    } else {
                        put("mobile", enteredRegisterDetail)
                    }
                }
                registerViewModel.sendOtp(bodyMap)
                authSharedViewModel.saveAuth(AuthModel(isEmail, enteredRegisterDetail, "password"))
            } else {
                ll_error.visibility = View.VISIBLE
                if(isEmail) {
                    txt_error.text = getString(R.string.email_not_)
                } else {
                    txt_error.text = getString(R.string.mobile_not_)
                }
            }
        })
        registerViewModel.observeOtpSent().observe(this, Observer {
            if (!it) {
                ll_error.visibility = View.VISIBLE
                txt_error.text = getString(R.string.something_went_wrong_)
            } else {
                (activity as ForgotPasswordActivity).changeFragment(
                        OtpFragment(), "otpFragment")
                authSharedViewModel.saveAuth(AuthModel(isEmail, enteredRegisterDetail, "password"))
            }
        })
        countryListVM.observeCountryList().observe(this, Observer {
            countryList.addAll(it)

            countryAdapter = CountrySpinnerAdaptor(countryList)
            countryCodeSpinner.adapter = countryAdapter
            selectedCountry = countryList[0]
        })

        // observing errors
        observeError()
    }

    private fun observeError() {
        registerViewModel.observeError().observe(this, Observer {
            handleError(it)
        })
        languageViewModel.observeError().observe(this, Observer {
            handleError(it)
        })
    }

    private fun handleError(status: ResponseStatus) {
        when (status) {
            ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                (activity as CustomAppCompatActivity).showToast("Internet not available")
            }
            ResponseStatus.AUTH_ERROR -> {
                (activity as CustomAppCompatActivity).showToast("Auth Error")
            }
            ResponseStatus.SERVER_ERROR -> {
                (activity as CustomAppCompatActivity).showToast("Server Error")
            }
            else -> {
            }
        }
    }

    override fun languageSelectCallback(index: Int) {
        selectedLanguage = languageList[index]

        txt_language.text = selectedLanguage.name
        dialog.dismiss()
    }

    private fun setViewsClick() {
        ll_language.setOnClickListener {
            showLanguageBottomDialog()
        }
//        btn_send.setOnClickListener {
//            (activity as ForgotPasswordActivity).changeFragment(OtpFragment(), "OtpFragment")
//        }
        txt_get_started.setOnClickListener {
            startActivity(Intent(context!!, SignUpActivity::class.java))
            activity!!.finish()
        }
        img_toolbar_back.setOnClickListener {
            (activity as ForgotPasswordActivity).onBackPressed()
        }

        btn_send.setOnClickListener {
            enteredRegisterDetail = edt_new_password.text.toString()
            when {
                enteredRegisterDetail.isValidEmail() -> {
                    ll_error.visibility = View.GONE
                    isEmail = true
                    registerViewModel.checkEmailAvailability(
                            hashMapOf("email" to enteredRegisterDetail), isForgot = true)
                }
                enteredRegisterDetail.isValidMobile() -> {
                    // concatenating country code
//                    val countryCode = selectedCountry?.code ?: "+91"
                    val countryCode = "+91"
                    enteredRegisterDetail = "$countryCode $enteredRegisterDetail"

                    ll_error.visibility = View.GONE
                    isEmail = false
                    registerViewModel.checkMobileAvailability(
                            hashMapOf("mobile" to enteredRegisterDetail), isForgot = true)
                }
                else -> {
                    ll_error.visibility = View.VISIBLE
                    txt_error.text = getString(R.string.please_enter_valid_)
                }
            }
        }
        countryCodeSpinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                selectedCountry = countryList[position]
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {}
        }
    }

    private fun setInitialLanguage() {
        txt_forgot_.text = getString(R.string.forgot_password)
        txt_we_will_.text = getString(R.string.we_will_)
        btn_send.text = getString(R.string.send)
        txt_dont_.text = getString(R.string.don_t_have_)
        txt_get_started.text = getString(R.string.get_started)
        txt_or_.text = getString(R.string.or)
        txt_login_id.text =getString(R.string.continue_with_google)
        txt_apple.text =getString(R.string.continue_with_apple)
        txt_privacy_.text = getString(R.string.privacy_policy)
        txt_user_notice.text = getString(R.string.user_notice)
        txt_new_password.hint = getString(R.string.enter_your_email_)
        txt_error.text = getString(R.string.enter_correct_email_id)
        txt_choose_your_.text = getString(R.string.choose_your_country)
        ll_error.visibility = View.GONE
    }
}