package com.sociomee.msgmee.ui.activity

import android.os.Bundle
import androidx.fragment.app.Fragment
import com.sociomee.msgmee.R

import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.ui.fragment.*
import com.sociomee.msgmee.utils.AuthenticationUtil

class SignUpActivity : CustomAppCompatActivity() {

    private lateinit var userContactDetailFragment: UserContactDetailFragment
    private lateinit var otpFragment: OtpFragment
    private lateinit var userBirthdateFragment: UserBirthdateFragment
    private lateinit var userCredentialsFragment: UserCredentialsFragment
    private lateinit var chooseInterestFragment: ChooseInterestFragment
    private lateinit var currentFragment: Fragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sign_up_activity)

        changeFragment(AuthenticationUtil.SignupFragmentType.USER_CONTACT, "UserContactDetail")
    }

    fun changeFragment(fragmentType: AuthenticationUtil.SignupFragmentType, fragmentName: String) {
        when(fragmentType) {
            AuthenticationUtil.SignupFragmentType.BIRTHDAY -> {
                if(!this::userBirthdateFragment.isInitialized) {
                    userBirthdateFragment = UserBirthdateFragment()
                }
                currentFragment = userBirthdateFragment
            }
            AuthenticationUtil.SignupFragmentType.USER_CONTACT -> {
                if(!this::userContactDetailFragment.isInitialized) {
                    userContactDetailFragment = UserContactDetailFragment()
                }
                currentFragment = userContactDetailFragment
            }
            AuthenticationUtil.SignupFragmentType.OTP -> {
                if(!this::otpFragment.isInitialized) {
                    otpFragment = OtpFragment()
                }
                currentFragment = otpFragment
            }
            AuthenticationUtil.SignupFragmentType.CREDENTIAL -> {
                if(!this::userCredentialsFragment.isInitialized) {
                    userCredentialsFragment = UserCredentialsFragment()
                }
                currentFragment = userCredentialsFragment
            }
            AuthenticationUtil.SignupFragmentType.INTEREST -> {
                if(!this::chooseInterestFragment.isInitialized) {
                    chooseInterestFragment = ChooseInterestFragment()
                }
                currentFragment = chooseInterestFragment
            }
        }

        supportFragmentManager
                .beginTransaction()
                .setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left, R.anim.enter_from_left, R.anim.exit_to_right)
                .replace(R.id.fl_sign_up, currentFragment, fragmentName)
//                .addToBackStack(fragmentName)
                .commit()
    }

    fun onBackPress() {
        val count = supportFragmentManager.backStackEntryCount
        if (count == 0) {
            super.onBackPressed()
        } else {
            supportFragmentManager.popBackStack()
        }
    }

    override fun onBackPressed() {
        when (currentFragment) {
            userContactDetailFragment -> {
                super.onBackPressed()
            }
            else -> {
                changeFragment(AuthenticationUtil.SignupFragmentType.USER_CONTACT,"UserContactDetail")
            }
//            otpFragment -> {
//            }
//            userCredentialsFragment -> {
//                changeFragment(AuthenticationUtil.SignupFragmentType.USER_CONTACT, "otpFragment")
//            }
//            userBirthdateFragment -> {
//                changeFragment(AuthenticationUtil.SignupFragmentType.USER_CONTACT, "UserCredentialsFragment")
//            }
//            chooseInterestFragment -> {
//                changeFragment(AuthenticationUtil.SignupFragmentType.USER_CONTACT,"UserBirthdateFragment")
//            }
        }
    }

    override fun setInitialLanguage() {

    }

    override fun bindData() {

    }
}