package com.sociomee.msgmee.ui.activity

import android.os.Bundle
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.adapter.BroadcastMemberAdapter
import com.sociomee.msgmee.ui.model.ChatMemberData
import com.sociomee.msgmee.ui.viewmodel.BroadcastInfoVM
import com.sociomee.msgmee.utils.Constants
import kotlinx.android.synthetic.main.broadcast_info_activity.*
import kotlinx.android.synthetic.main.custom_toolbar.*
import kotlinx.android.synthetic.main.custom_toolbar.txt_chat_head_name

class BroadcastInfoActivity : CustomAppCompatActivity() {

    private lateinit var broadcastAdapter: BroadcastMemberAdapter
    private var broadcastMemberList = ArrayList<ChatMemberData>()
    private lateinit var broadcastInfoVM: BroadcastInfoVM
    private var broadcastId = ""
    private var pageIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.broadcast_info_activity)

        broadcastId = intent!!.extras!!.getString("broadcastId", "")

        initData()
        observeData()
        bindData()
        setViewsClick()
    }

    private fun initData() {
        broadcastInfoVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            BroadcastInfoVM::class.java
        )
    }

    private fun observeData() {
        broadcastInfoVM.observeLoading().observe(this, Observer {
            changeLoadingStatus(it)
        })
        broadcastInfoVM.observerBroadcastPeopleList().observe(this, Observer {
            val participantsCount = "${it.count} ${getString(R.string.participants)}"
            txt_participant_count.text = participantsCount

            broadcastMemberList.addAll(it.rows)

            broadcastAdapter.notifyDataSetChanged()
        })

        // fetching group info
        fetchBroadcastData()

        observeError()
    }

    private fun fetchBroadcastData(showLoading: Boolean = true) {
        val bodyMap: HashMap<String, Any> = hashMapOf(
            "broadcastId" to broadcastId,
            "pageIndex" to pageIndex,
            "pageSize" to Constants.globalPageSize
        )
        broadcastInfoVM.fetchGroupPeopleList(bodyMap, showLoading)
    }

    private fun observeError() {
        broadcastInfoVM.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    showToast("Server Error")
                }
                else -> {
                }
            }
        })
    }

    private fun setViewsClick() {
        img_toolbar_back.setOnClickListener {
            onBackPressed()
        }
    }

    override fun setInitialLanguage() {
        txt_chat_head_name.text = getString(R.string.message_broadcast)
        txt_add_participant.text = getString(R.string.add_participants)

        txt_add_participant.visibility = View.GONE
    }

    override fun bindData() {
        broadcastAdapter = BroadcastMemberAdapter(broadcastMemberList)
        rl_broadcast.layoutManager = LinearLayoutManager(this)
        rl_broadcast.adapter = broadcastAdapter
        broadcastAdapter.notifyDataSetChanged()
    }
}