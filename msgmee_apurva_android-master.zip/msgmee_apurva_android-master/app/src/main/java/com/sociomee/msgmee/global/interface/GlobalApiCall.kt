package com.sociomee.msgmee.global.`interface`

import com.sociomee.msgmee.global.model.MediaUploadModel
import com.sociomee.msgmee.retrofit.MyCall
import okhttp3.RequestBody
import retrofit2.http.Body
import retrofit2.http.POST

interface GlobalApiCall {

    @POST("/admin/uploadFile")
    fun uploadMedia(@Body body: RequestBody): MyCall<MediaUploadModel>

}