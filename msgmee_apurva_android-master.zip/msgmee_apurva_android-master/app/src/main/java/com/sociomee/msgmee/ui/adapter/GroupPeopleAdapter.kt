package com.sociomee.msgmee.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomImageView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.`interface`.SingleItemCallback
import com.sociomee.msgmee.ui.model.FriendModel
import com.sociomee.msgmee.utils.Constants

class GroupPeopleAdapter(
    private val list: ArrayList<FriendModel>,
    private val selectType: Constants.PeopleSelectType,
    private val singleItemCallback: SingleItemCallback
) :
    RecyclerView.Adapter<GroupPeopleAdapter.GroupPeopleHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = GroupPeopleHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.group_people_child, parent, false)
    )

    override fun getItemCount() = list.size

    override fun onBindViewHolder(holder: GroupPeopleHolder, position: Int) {
        holder.cb_people_child.setOnCheckedChangeListener { _, isChecked ->
            list[position].isSelected = isChecked
            singleItemCallback.itemInteracted(position)
        }
        holder.cb_people_child.isChecked = list[position].isSelected

        holder.txt_calls_name.text = list[position].fullName

        Glide.with(holder.itemView.context).load(list[position].profileImageThumb)
            .placeholder(R.drawable.profile_placeholder).into(holder.img_messenger_profile)

        if(selectType == Constants.PeopleSelectType.SINGLE || selectType == Constants.PeopleSelectType.CALL) {
            holder.cb_people_child.visibility = View.GONE
            holder.itemView.setOnClickListener {
                singleItemCallback.itemInteracted(position)
            }
        }
    }

    class GroupPeopleHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txt_calls_name = itemView.findViewById<CustomTextView>(R.id.txt_calls_name)
        val cb_people_child = itemView.findViewById<CheckBox>(R.id.cb_people_child)
        val img_messenger_profile =
            itemView.findViewById<CustomImageView>(R.id.img_messenger_profile)
    }
}