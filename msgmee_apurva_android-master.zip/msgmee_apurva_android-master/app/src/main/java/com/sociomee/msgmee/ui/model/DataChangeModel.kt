package com.sociomee.msgmee.ui.model

data class DataChangeModel(val position: Int, val changed: Boolean)