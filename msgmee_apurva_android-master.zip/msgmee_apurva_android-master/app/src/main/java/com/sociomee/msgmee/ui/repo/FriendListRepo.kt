package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.ApiCall
import com.sociomee.msgmee.ui.model.FriendListModel
import com.sociomee.msgmee.ui.model.MessageResponse
import retrofit2.Response

class FriendListRepo {

    fun fetchFriendList(body: HashMap<String, Any>, isGroupNonMemberList: Boolean = false) : MutableLiveData<MyResponse<FriendListModel.Data.SuccessResult>> {
        val data = MutableLiveData<MyResponse<FriendListModel.Data.SuccessResult>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = if(isGroupNonMemberList) retrofitService.fetchGroupNonMemberList(body) else retrofitService.fetchFriendList(body)

        call.enqueue(object : MyCallback<FriendListModel> {
            override fun success(response: Response<FriendListModel>) {
                data.postValue(MyResponse.success(response.body()!!.data.successResult))
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }
        })
        return data
    }

    fun createChatHead(body: HashMap<String, Any>) : MutableLiveData<MyResponse<Boolean>>{
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.createChatHead(body)

        call.enqueue(object : MyCallback<MessageResponse>{
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {

                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }

    fun createBroadcast(body: HashMap<String, Any>) : MutableLiveData<MyResponse<Boolean>>{
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.createBroadcast(body)

        call.enqueue(object : MyCallback<MessageResponse>{
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }

    fun addFriendsToGroup(body: HashMap<String, Any>) : MutableLiveData<MyResponse<Boolean>>{
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.addFriendsToGroup(body)

        call.enqueue(object : MyCallback<MessageResponse>{
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }

}