package com.sociomee.msgmee.ui.activity

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.gson.Gson
import com.sociomee.msgmee.MsgMee
import com.sociomee.msgmee.ui.adapter.ChooseLanguageAdapter
import com.sociomee.msgmee.ui.adapter.CountrySpinnerAdaptor
import com.sociomee.msgmee.ui.adapter.CountyCode
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.`interface`.LanguageSelectCallback
import com.sociomee.msgmee.ui.viewmodel.LoginViewModel
import com.sociomee.msgmee.ui.model.LanguageList
import com.sociomee.msgmee.ui.viewmodel.LanguageViewModel
import com.sociomee.msgmee.utils.*
import kotlinx.android.synthetic.main.login_activity.*
import kotlinx.android.synthetic.main.login_dialog.view.*
import androidx.lifecycle.Observer
import com.sociomee.msgmee.ui.data.CountryDataModel
import com.sociomee.msgmee.ui.viewmodel.CountryListVM
import kotlinx.android.synthetic.main.login_activity.countryCodeSpinner
import kotlinx.android.synthetic.main.login_activity.ll_language
import kotlinx.android.synthetic.main.login_activity.txt_apple
import kotlinx.android.synthetic.main.login_activity.txt_choose_your_
import kotlinx.android.synthetic.main.login_activity.txt_language
import kotlinx.android.synthetic.main.login_activity.txt_login
import kotlinx.android.synthetic.main.login_activity.txt_or
import kotlinx.android.synthetic.main.user_contact_detail_fragment.*

const val GOOGLE_SIGN_IN = 10

class LoginActivity : CustomAppCompatActivity(), LanguageSelectCallback {

    private var isBlocked = true
    private var languageList = ArrayList<LanguageList>()
    private lateinit var languageViewModel: LanguageViewModel
    private lateinit var loginViewModel: LoginViewModel
    private lateinit var chooseLanguageAdapter: ChooseLanguageAdapter
    private lateinit var selectedLanguage: LanguageList
    private lateinit var dialog: BottomSheetDialog
    private lateinit var gso: GoogleSignInOptions
    private lateinit var googleSignInClient: GoogleSignInClient
    private var enteredDetail = ""
    private var loginType = ""
    private var isEmail = true
    private lateinit var countryListVM: CountryListVM
    private var countryList = ArrayList<CountryDataModel>()
    private lateinit var countryAdapter: CountrySpinnerAdaptor
    private var selectedCountry: CountryDataModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_activity)

        setupGoogleSignIn()

        initData()
        setViewsClick()

    }

    private fun setupGoogleSignIn() {
        gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestIdToken(getString(R.string.default_web_client_id))
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)
    }

    private fun setViewsClick() {
        ll_google.setOnClickListener {
            loginType = "google"
            isEmail = true
            val signInIntent: Intent = googleSignInClient.signInIntent
            startActivityForResult(signInIntent, GOOGLE_SIGN_IN)
        }
        ll_apple.setOnClickListener {
            loginType = "apple"
            isEmail = true
        }
        img_back.setOnClickListener {
            onBackPressed()
        }
        txt_get_started.setOnClickListener {
            startActivity(SignUpActivity::class.java)
            finish()
        }
        txt_login_with.setOnClickListener{
            startActivity(ForgotPasswordActivity::class.java)
            finish()
        }
    }

    private fun initData() {
        languageViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            LanguageViewModel::class.java
        )
        loginViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            LoginViewModel::class.java
        )
        countryListVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            CountryListVM::class.java)
        languageViewModel.getLanguageList()
        countryListVM.getCountryList()

//        countryCodeSpinner.adapter = CountrySpinnerAdaptor(list)
        chooseLanguageAdapter = ChooseLanguageAdapter(languageList, this)
        observeData()
        clickListeners()
    }

    private fun clickListeners() {
        btn_login.setOnClickListener {
            if (!edt_password.text.toString().isValidPassword()) {
                txt_invalid_email_.setText(R.string.password_should_be_)
                ll_error_message.show()
                return@setOnClickListener
            }

            enteredDetail = edt_email_number.text.toString().trim()
            when {
                enteredDetail.isValidEmail() -> {
                    ll_error_message.visibility = View.GONE
                    isEmail = true
                    loginType = "password"
                    ll_error_message.hide()
                    loginNow()
                }
                enteredDetail.isValidMobile() -> {
                    ll_error_message.visibility = View.GONE
                    isEmail = false
                    loginType = "password"
                    ll_error_message.hide()
                    loginNow()
                }
                else -> {
                    txt_invalid_email_.setText(R.string.invalid_email_)
                    ll_error_message.show()
                }
            }
        }
    }

    @SuppressLint("HardwareIds")
    private fun loginNow() {
        val savedLocation = Constants.getSavedLocation(this)
        if (!isEmail) {
            enteredDetail = "+91 $enteredDetail"
        }
        val body = HashMap<String, Any>().apply {
            put("loginId", enteredDetail)
            put("password", edt_password.text.toString())
            put("type", if (isEmail) "email" else "mobile")
            put("loginMode", loginType)
            put("platform", "android")
            put("ipAddress", "")
            put("deviceId", Settings.Secure.getString(contentResolver,
                Settings.Secure.ANDROID_ID))
            put("fcmToken", MyPreferences.getFcmToken(this@LoginActivity))
            put("deviceInfo", getDeviceInformation(this@LoginActivity))
            put("locationLAT", savedLocation.lat)
            put("locationLONG", savedLocation.lng)
        }
        loginViewModel.loginUser(body)
    }

    private fun observeData() {
        languageViewModel.observeLoading().observe(this, Observer {
            if (it) {
                showLoadingDialog()
            } else {
                hideLoadingDialog()
            }
        })

        loginViewModel.observeLoading().observe(this, Observer {
            if (it) {
                showLoadingDialog()
            } else {
                hideLoadingDialog()
            }
        })
        languageViewModel.observeLanguageList().observe(this, Observer {
            languageList.addAll(it)
        })
        loginViewModel.observeLoginUser().observe(this, Observer {
            if (it.success) {
                val intent = Intent(this, MessengerActivity::class.java)
                intent.putExtra("type", "profileOwn")
                startActivity(intent)

                // saving user data in shared preferences
                MyPreferences.saveStringInPreference(
                    this, Constants.userDataKey, Gson().toJson(
                        it.data.userInfoModel
                    )
                )
                Constants.userInfo = it.data.userInfoModel

                // initializing socket after successful login
                MsgMee.initializeSocketAndListenEvents()

                finish()
            } else {
                when (it.data.errorResult) {
                    "userNotExists" -> {
                        if (isEmail) {
                            txt_invalid_email_.text = getString(R.string.email_not_exits)
                        } else {
                            txt_invalid_email_.text = getString(R.string.mobile_not_exits)
                        }
                        ll_error_message.show()
                    }
                    "incorrectPassword" -> {
                        txt_invalid_email_.text = getString(R.string.password_incorrect)
                        ll_error_message.show()
                    }
                    "incorrectLoginMode" -> {
                        txt_invalid_email_.text = getString(R.string.incorrect_login_mode)
                        ll_error_message.show()
                    }
                    else -> {
                        txt_invalid_email_.setText(R.string.something_went_wrong_)
                        ll_error_message.show()
                    }
                }
            }
        })
        countryListVM.observeCountryList().observe(this, Observer {
            countryList.addAll(it)

            countryAdapter = CountrySpinnerAdaptor(countryList)
            countryCodeSpinner.adapter = countryAdapter
            selectedCountry = countryList[0]
        })

        // observing errors
        observeError()
    }

    private fun observeError() {
        languageViewModel.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    showToast("Server Error")
                }
                else -> {

                }
            }
        })
        countryListVM.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    showToast("Server Error")
                }
                else -> {

                }
            }
        })
    }

    override fun setInitialLanguage() {
        txt_language.text = getString(R.string.change_language)
        txt_login.text = getString(R.string.welcome_back)
        txt_login_with.text=getString(R.string.forgot_password).plus("?")
//        txt_forget_password.text = getString(R.string.forgot_password).plus("?")
        btn_login.text = getString(R.string.login)
        txt_dont_have_.text = getString(R.string.dont_have_)
        txt_get_started.text = getString(R.string.get_started)
        txt_or.text = getString(R.string.or)
        txt_apple.text = getString(R.string.apple)
        txt_google.text = getString(R.string.google)
        txt_privecy_policy.text = getString(R.string.privecy_policy)
        txt_user_notice.text = getString(R.string.user_notice)
        txt_choose_your_.text = getString(R.string.choose_your_)
        txt_dot.text = getString(R.string.dot)
        txt_invalid_email_.text = getString(R.string.invalid_email_)
        txt_emai_number.hint = getString(R.string.email_mobile_)
        txt_password.hint = getString(R.string.password)

        ll_language.setOnClickListener {
            showLanguageBottomDialog()
        }
    }

    private fun showBlockedUserDialog() {
        val view = LayoutInflater.from(this).inflate(R.layout.login_dialog, null)
        val dialog = AlertDialog.Builder(this, R.style.CustomAlertDialog).setView(view)
        val alertDialog = dialog.show()
        view.txt_your_account_.setText(R.string.your_account_)
        view.txt_please_contact_.setText(R.string.please_contact_)
        view.btn_ok.setText(R.string.ok)

        view.btn_ok.setOnClickListener {
            alertDialog.dismiss()
        }
    }

    override fun bindData() {

    }

    private fun showLanguageBottomDialog() {
        val view = LayoutInflater.from(this).inflate(R.layout.choose_language_bottom_sheet, null)
        dialog = BottomSheetDialog(this, R.style.SheetDialog)
        dialog.setContentView(view)
        val recyclerView = view.findViewById<RecyclerView>(R.id.rv_choose_language)
        val list = ArrayList<String>()
        for (i in 0..20) {
            list.add("Language $i")
        }
        val manager = LinearLayoutManager(this)
        recyclerView.layoutManager = manager
        recyclerView.adapter = chooseLanguageAdapter
        dialog.show()
        recyclerView.addItemDecoration(DividerItemDecoration(this, manager.orientation))
    }

    override fun languageSelectCallback(index: Int) {
        selectedLanguage = languageList[index]
        txt_language.text = selectedLanguage.name
        dialog.dismiss()
    }

    private fun handleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account = completedTask.getResult(ApiException::class.java)
            if (account == null) {
                showToast(getString(R.string.something_went_wrong_))
                return
            }

            // Signed in successfully, show authenticated UI.
            enteredDetail = account.email.toString()
            loginNow()
        } catch (e: ApiException) {
            showToast(getString(R.string.something_went_wrong_))
            Log.w("harsh", "signInResult:failed code=" + e.statusCode)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == GOOGLE_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            val task: Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            handleSignInResult(task)
        }
    }
}