package com.sociomee.msgmee.ui.model

import com.google.gson.annotations.SerializedName

data class ChatHeadModel(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("successResult")
        val successResult: SuccessResult,
    ) {
        data class SuccessResult(
            @SerializedName("count")
            val count: Int,
            @SerializedName("rows")
            val chatHeadList: List<ChatHeadData>,
            var isRefresh: Boolean = true,
            var showArchive: Boolean = true
        )
    }
}
data class ChatHeadData(
    @SerializedName("broadcastId")
    val broadcastId: String,
    @SerializedName("broadcastListName")
    val broadcastListName: String,
    @SerializedName("chatHeadId")
    val chatHeadId: String,
    @SerializedName("chatHeadType")
    val chatHeadType: String,
    @SerializedName("fullName")
    val fullName: String,
    @SerializedName("groupId")
    val groupId: String,
    @SerializedName("groupImageThumb")
    val groupImageThumb: String,
    @SerializedName("groupName")
    val groupName: String,
    @SerializedName("isMute")
    var isMute: Int,
    @SerializedName("isOnline")
    var isOnline: Int,
    @SerializedName("isPinned")
    var isPinned: Int,
    @SerializedName("lastMessageDate")
    val lastMessageDate: String,
    @SerializedName("lastMessageId")
    val lastMessageId: String,
    @SerializedName("lastMessageJson")
    val lastMessageJson: LastMessageData?,
    @SerializedName("lastMessageText")
    val lastMessageText: String,
    @SerializedName("lastMessageType")
    val lastMessageType: String,
    @SerializedName("otherUserId")
    val otherUserId: String,
    @SerializedName("profileImageThumb")
    val profileImageThumb: String,
    @SerializedName("unReadCount")
    val unReadCount: String,
    @SerializedName("blockedByMe")
    val blockedByMe: Int,
    @SerializedName("blockedByOther")
    val blockedByOther: Int,
    @SerializedName("groupDeleted")
    val groupDeleted: Int,
    @SerializedName("isGroupMember")
    val isGroupMember: Int,
    @SerializedName("isArchived")
    val isArchived: Int = 1,
    @SerializedName("lastmessageDeleted")
    val lastMessageDeleted: Int = 0,
    var isSelected: Boolean = false
) {
    data class LastMessageData(
        @SerializedName("addedByUserId")
        val addedByUserId: String,
        @SerializedName("addedByUserName")
        val addedByUserName: String,
        @SerializedName("addedUserId")
        val addedUserId: String,
        @SerializedName("addedUserName")
        val addedUserName: String,
        @SerializedName("type")
        val type: String
    )

    companion object {
        fun createArchiveHead(): ChatHeadData {
            return ChatHeadData(
                "",
                "",
                "",
                "archive",
                "",
                "",
                "",
                "",
                0,
                0,
                0,
                "",
                "",
                null,
                "",
                "",
                "",
                "",
                "",
                0,
                0,
                0,
                0,
                0,
                0,
                false
            )
        }
    }
}