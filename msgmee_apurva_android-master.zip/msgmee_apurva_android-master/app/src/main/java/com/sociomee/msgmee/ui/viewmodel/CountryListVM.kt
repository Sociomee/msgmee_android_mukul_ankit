package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData


import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.data.CountryDataModel
import com.sociomee.msgmee.ui.repo.CountryListRepo

class CountryListVM : MyViewModel() {

    private var countryList = MutableLiveData<ArrayList<CountryDataModel>>()
    private lateinit var countryListRepo: CountryListRepo

    // returning LiveData
    fun observeCountryList() = countryList

    fun getCountryList() {
        if (!this::countryListRepo.isInitialized) {
            countryListRepo = CountryListRepo()
        }
        isLoading.value = true
        countryListRepo.getCountryList().observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                countryList.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }
}