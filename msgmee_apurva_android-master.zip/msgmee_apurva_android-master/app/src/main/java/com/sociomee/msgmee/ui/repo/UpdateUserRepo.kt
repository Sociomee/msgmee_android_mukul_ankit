package com.sociomee.msgmee.ui.repo

import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.ApiCall
import com.sociomee.msgmee.ui.model.MessageResponse
import retrofit2.Response

class UpdateUserRepo {

    companion object {
        fun updateUserDetails(body : HashMap<String, Any>) {
            val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
            val call = retrofitService.updateUserDetails(body)
            call.enqueue(object: MyCallback<MessageResponse> {
                override fun success(response: Response<MessageResponse>) {}
                override fun serverError() {}
                override fun networkError() {}
                override fun authError() {}
            })
        }

        fun logOutUser() {
            val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
            val call = retrofitService.logOutUser()
            call.enqueue(object: MyCallback<MessageResponse> {
                override fun success(response: Response<MessageResponse>) {}
                override fun serverError() {}
                override fun networkError() {}
                override fun authError() {}
            })
        }
    }

}