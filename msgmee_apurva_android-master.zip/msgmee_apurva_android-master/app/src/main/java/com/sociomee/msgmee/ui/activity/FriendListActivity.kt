package com.sociomee.msgmee.ui.activity

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.slider.LabelFormatter
import com.google.android.material.slider.Slider
import com.google.android.material.textview.MaterialTextView
import com.google.gson.Gson
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.`interface`.SingleItemCallback
import com.sociomee.msgmee.ui.adapter.GroupPeopleAdapter
import com.sociomee.msgmee.ui.adapter.PeopleFilterAdapter
import com.sociomee.msgmee.ui.model.ChatHeadInfo
import com.sociomee.msgmee.ui.model.FriendModel
import com.sociomee.msgmee.ui.viewmodel.FriendListVM
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.ScrollListener
import kotlinx.android.synthetic.main.friend_list_activity.*
import java.util.*
import kotlin.collections.ArrayList
import com.xiaofeng.flowlayoutmanager.Alignment
import com.xiaofeng.flowlayoutmanager.FlowLayoutManager
import kotlinx.android.synthetic.main.friend_list_activity.edt_search
import kotlinx.android.synthetic.main.friend_list_activity.img_toolbar_back
import kotlinx.android.synthetic.main.friend_list_activity.txt_chat_head_name
import kotlinx.android.synthetic.main.friend_list_activity.txt_done
import kotlin.collections.HashMap
import androidx.lifecycle.Observer
import com.sociomee.msgmee.ui.model.StartCallModel

val listACTLocation = arrayListOf("delhi", "agra", "mumbai", "lucknow", "kolkata")
val listACTInterest = arrayListOf("books", "reading", "driving", "arabic", "belle")
val listOfRange = arrayListOf(
    "50",
    "100",
    "200",
    "300",
    "500",
    "700",
    "900",
    "1200",
    "1500",
    "1800",
    "2000",
    "3000",
    "5000",
    "8000",
    "12000",
    "15000"
)
const val infinite = "∞"

fun setLabelSlider(slider: Slider, index: Int, ll_values: LinearLayout) {
    val position = index * 3
    slider.setLabelFormatter(LabelFormatter { value: Float ->
        //It is just an example
        if (value == 1.0f) return@LabelFormatter listOfRange[position]
        if (value == 2.0f) return@LabelFormatter listOfRange[position + 1]
        if (value == 3.0f) return@LabelFormatter listOfRange[position + 2]
        if (value == 4.0f) return@LabelFormatter listOfRange[position + 3]
        if (value == 5.0f) return@LabelFormatter infinite
        String.format(Locale.US, "%.0f", value)
    })
    for (i in 0 until ll_values.childCount - 1) {
        val ll = ll_values.getChildAt(i) as LinearLayout
        val txt = ll.getChildAt(1) as TextView
        txt.text = listOfRange[position + i]
    }
}

class FriendListActivity : CustomAppCompatActivity(), SingleItemCallback {

    private var peopleSelectType = Constants.PeopleSelectType.SINGLE
    private var indexSliderPeople = 0
    private var valueSliderPeople = 5f
    private val listSelectedLocationPeople = ArrayList<String>()
    private val listSelectedInterestPeople = ArrayList<String>()
    private val listSelectedMusicPeople = ArrayList<String>()
    private val listSelectedMoviesPeople = ArrayList<String>()
    private val listSelectedBooksPeople = ArrayList<String>()
    private lateinit var friendListVM: FriendListVM
    private var peopleList = ArrayList<FriendModel>()
    private lateinit var adapter: GroupPeopleAdapter
    private var pageIndex = 0
    private var groupId = ""
    private var searchText: String = ""
    private var isLastPage = false
    private var isLoading = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.friend_list_activity)

        if (intent != null && intent.extras != null) {
            peopleSelectType = intent.extras!!.getSerializable(
                "type"
            ) as Constants.PeopleSelectType
            groupId = intent.extras!!.getString("groupId", "")
        }

        bindData()
        observeData()
        setViewsClick()
    }

    private fun observeData() {
        friendListVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            FriendListVM::class.java
        )
        friendListVM.observeLoading().observe(this, Observer {
            changeLoadingStatus(it)
        })
        friendListVM.observeFriendList().observe(this, Observer { newList ->
            isLastPage = if (newList.rows.isEmpty()) {
                true
            } else {
                if (newList.isRefresh) {
                    peopleList.clear()
                }
                newList.rows.forEach {
                    if (!peopleList.contains(it)) {
                        peopleList.add(it)
                    }
                }
                adapter.notifyDataSetChanged()
                false
            }
            isLoading = false
        })
        friendListVM.observeChatHeadCreation().observe(this, Observer {
            if (it) {
                showToast("Chat Head created successfully")
                finish()
            } else {
                showToast()
            }
        })
        friendListVM.observeBroadcastCreation().observe(this, Observer {
            if (it) {
                showToast(getString(R.string.broadcast_created_))
                finish()
            } else {
                showToast()
            }
        })
        friendListVM.observeFriendAddToGroup().observe(this, Observer {
            if (it) {
                setResult(RESULT_OK)
                finish()
            } else {
                showToast()
            }
        })
        // fetching friend list data
        callAPI()

        observeError()
    }

    private fun callAPI(isRefresh: Boolean = true, searchText: String = "") {
        if (isRefresh)
            pageIndex = 0
        val body: HashMap<String, Any> = hashMapOf(
            "searchKey" to searchText,
            "pageIndex" to pageIndex,
            "pageSize" to Constants.globalPageSize,
        )

        if (peopleSelectType == Constants.PeopleSelectType.GROUP_ADD_PEOPLE) {
            body["groupId"] = groupId
            friendListVM.fetchGroupNonMemberList(body, isRefresh)
        } else {
            friendListVM.fetchFriendList(body, isRefresh)
        }
    }

    private fun observeError() {
        friendListVM.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    showToast("Server Error")
                }
                else -> {
                }
            }
        })
    }

    private fun setViewsClick() {
        img_toolbar_back.setOnClickListener {
            onBackPressed()
        }
        txt_done.setOnClickListener {
            takeDoneAction()
        }
        txt_new_group.setOnClickListener {
            peopleSelectType = Constants.PeopleSelectType.GROUP
            bindData()
            setViewsClick()
        }
        txt_broadcast.setOnClickListener {
            peopleSelectType = Constants.PeopleSelectType.BROADCAST
            bindData()
            setViewsClick()
        }
        img_search_setting.setOnClickListener {
            showPeopleFilter()
        }
        edt_search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                searchText = edt_search.text.toString().trim()
                callAPI(true, searchText)
                return@setOnEditorActionListener true
            }
            return@setOnEditorActionListener false
        }
    }

    private fun takeDoneAction() {
        val selectedPeopleList = peopleList.filter {
            it.isSelected
        }
        if (peopleSelectType == Constants.PeopleSelectType.GROUP) {
            if (selectedPeopleList.isEmpty()) {
                showToast(getString(R.string.select_min_group_))
            } else {
                val intent = Intent(this, CreateGroupActivity::class.java)
                intent.putExtra("selectedPeopleList", Gson().toJson(selectedPeopleList))
                startActivity(intent)
                finish()
            }
        } else if (peopleSelectType == Constants.PeopleSelectType.BROADCAST) {
            if (selectedPeopleList.size < 2) {
                showToast(getString(R.string.select_min_broadcast_))
            } else {
                val broadCastPeople = ArrayList<String>()
                selectedPeopleList.forEach {
                    broadCastPeople.add(it.id)
                }
                val bodyMap: HashMap<String, Any> = hashMapOf(
                    "broadcastName" to "${selectedPeopleList[0].userName} ${getString(R.string.and)} ${selectedPeopleList.size - 1} ${
                    getString(
                        R.string.others
                    )
                    }",
                    "memberIds" to broadCastPeople
                )
                friendListVM.createBroadcast(bodyMap)
            }
        } else if (peopleSelectType == Constants.PeopleSelectType.GROUP_ADD_PEOPLE) {
            val newPeople = ArrayList<HashMap<String, String>>()
            selectedPeopleList.forEach {
                newPeople.add(
                    hashMapOf(
                        "memberId" to it.id,
                        "memberName" to it.userName
                    )
                )
            }
            val bodyMap: HashMap<String, Any> = hashMapOf(
                "groupId" to groupId,
                "members" to newPeople
            )
            friendListVM.addFriendsToGroup(bodyMap)
        }
    }

    override fun setInitialLanguage() {
        txt_done.text = getString(R.string.done)
        edt_search.hint = getString(R.string.search_people)
    }

    override fun bindData() {
        when (peopleSelectType) {
            Constants.PeopleSelectType.SINGLE -> {
                txt_chat_head_name.text = getString(R.string.new_message)
                txt_new_group.text = getString(R.string.new_group)
                txt_broadcast.text = getString(R.string.broadcast)
                txt_done.visibility = View.GONE
            }
            Constants.PeopleSelectType.GROUP -> {
                txt_chat_head_name.text = getString(R.string.new_group)
                txt_done.text = getString(R.string.done)
                txt_done.visibility = View.VISIBLE
                txt_new_group.visibility = View.GONE
                txt_broadcast.visibility = View.GONE
                img_group_view.visibility = View.GONE
                img_broadcast_view.visibility = View.GONE
            }
            Constants.PeopleSelectType.BROADCAST -> {
                txt_chat_head_name.text = getString(R.string.new_broadcast)
                txt_done.text = getString(R.string.done)
                txt_done.visibility = View.VISIBLE
                txt_new_group.visibility = View.GONE
                txt_broadcast.visibility = View.GONE
                img_group_view.visibility = View.GONE
                img_broadcast_view.visibility = View.GONE
            }
            Constants.PeopleSelectType.GROUP_ADD_PEOPLE -> {
                txt_chat_head_name.text = getString(R.string.add_participants)
                txt_done.text = getString(R.string.done)
                txt_done.visibility = View.VISIBLE
                txt_new_group.visibility = View.GONE
                txt_broadcast.visibility = View.GONE
                img_group_view.visibility = View.GONE
                img_broadcast_view.visibility = View.GONE
            }
            Constants.PeopleSelectType.CALL -> {
                txt_chat_head_name.text = getString(R.string.new_call)
                txt_new_group.visibility = View.GONE
                txt_broadcast.visibility = View.GONE
                img_group_view.visibility = View.GONE
                txt_done.visibility = View.GONE
            }
        }

        txt_selected_people_count.visibility = View.GONE
        view87.visibility = View.GONE

        // setting adapter
        adapter = GroupPeopleAdapter(peopleList, peopleSelectType, this)
        val layoutManager = LinearLayoutManager(this)
        rl_people_list.layoutManager = layoutManager
        rl_people_list.adapter = adapter
        adapter.notifyDataSetChanged()

        // for pagination
        rl_people_list.addOnScrollListener(object : ScrollListener(layoutManager) {
            override fun isNewLastPage() = true
            override fun isOldLastPage() = isLastPage
            override fun isLoading() = isLoading
            override fun loadNewItems() {}

            override fun loadOldItems() {
                isLoading = true
                pageIndex++
                callAPI(false, "")
            }
        })
    }

    override fun itemInteracted(position: Int) {
        if (peopleSelectType == Constants.PeopleSelectType.SINGLE) {
            val selectedPeople = peopleList[position]
            val chatInfo = ChatHeadInfo(
                selectedPeople.chatHeadId,
                selectedPeople.fullName,
                selectedPeople.profileImageThumb,
                "user",
                selectedPeople.id
            )
            val intent = Intent(this, ChatActivity::class.java)
            intent.putExtra("chatHeadData", Gson().toJson(chatInfo))
            startActivity(intent)
            finish()
            return
        } else if (peopleSelectType == Constants.PeopleSelectType.CALL) {
            val isVideoCall = intent.extras?.getBoolean("isVideoCall") ?: false
            val selectedPeople = peopleList[position]

            finish()
            return
        }

        var selectedPeopleCount = 0
        for (data in peopleList) {
            if (data.isSelected)
                selectedPeopleCount++
        }

        if (selectedPeopleCount == 0) {
            txt_selected_people_count.visibility = View.GONE
            view87.visibility = View.GONE
        } else {
            txt_selected_people_count.visibility = View.VISIBLE
            view87.visibility = View.VISIBLE
            val peopleData = "${getString(R.string.selected_people)} : $selectedPeopleCount"
            txt_selected_people_count.text = peopleData
        }
    }

    private fun showPeopleFilter() {
        val view =
            LayoutInflater.from(this).inflate(R.layout.search_people_filters_bottom_sheet, null)
        val dialog = BottomSheetDialog(this, R.style.BottomSheetFilter)
        dialog.setContentView(view)

        val slider = view.findViewById<Slider>(R.id.slider)
        val ll_values = view.findViewById<LinearLayout>(R.id.ll_values)
        val txt_people_filter = view.findViewById<CustomTextView>(R.id.txt_people_filter)
        val txt_within_ = view.findViewById<CustomTextView>(R.id.txt_within_)
        val act_location = view.findViewById<AutoCompleteTextView>(R.id.act_location)
        val act_interest = view.findViewById<AutoCompleteTextView>(R.id.act_interest)
        val recycler_view_location = view.findViewById<RecyclerView>(R.id.recycler_view_location)
        val recycler_view_interest = view.findViewById<RecyclerView>(R.id.recycler_view_interest)
        val btn_clear_all = view.findViewById<Button>(R.id.btn_clear_all)

        // setting language text
        txt_people_filter.text = getString(R.string.people_filter)
        txt_within_.text = getString(R.string.within_km)
        act_location.hint = getString(R.string.choose_location)
        act_interest.hint = getString(R.string.choose_interests)

        slider.value = valueSliderPeople

        //auto complete text adaptor
        val adapterACTLocation: ArrayAdapter<String> =
            ArrayAdapter(this, android.R.layout.select_dialog_item, listACTLocation)
        act_location.threshold = 1
        act_location.setAdapter(adapterACTLocation)

        //layout manager for location
        val flowLayoutManagerLocation = FlowLayoutManager()
        flowLayoutManagerLocation.isAutoMeasureEnabled = true
        flowLayoutManagerLocation.setAlignment(Alignment.LEFT)
        flowLayoutManagerLocation.maxItemsPerLine(4)
        recycler_view_location.layoutManager = flowLayoutManagerLocation

        //adaptor for location
        val adaptorLocation = PeopleFilterAdapter(listSelectedLocationPeople)
        recycler_view_location.adapter = adaptorLocation

        //item click of auto complete text view
        act_location.onItemClickListener =
            AdapterView.OnItemClickListener { _, view1, _, _ ->
                val txt = (view1 as MaterialTextView)
                listSelectedLocationPeople.add(txt.text.toString())
                adaptorLocation.notifyDataSetChanged()
                act_location.setText("")
            }

        val adapterACTInterest: ArrayAdapter<String> =
            ArrayAdapter(this, android.R.layout.select_dialog_item, listACTInterest)
        act_interest.threshold = 1
        act_interest.setAdapter(adapterACTInterest)

        //layout manager for location
        val flowLayoutManagerInterest = FlowLayoutManager()
        flowLayoutManagerInterest.isAutoMeasureEnabled = true
        flowLayoutManagerInterest.setAlignment(Alignment.LEFT)
        flowLayoutManagerInterest.maxItemsPerLine(4)
        recycler_view_interest.layoutManager = flowLayoutManagerInterest

        //adaptor for location
        val adaptorInterest = PeopleFilterAdapter(listSelectedInterestPeople)
        recycler_view_interest.adapter = adaptorInterest

        //item click of auto complete text view
        act_interest.onItemClickListener =
            AdapterView.OnItemClickListener { _, view1, _, _ ->
                val txt = (view1 as MaterialTextView)
                listSelectedInterestPeople.add(txt.text.toString())
                adaptorInterest.notifyDataSetChanged()
                act_interest.setText("")
            }

        slider.addOnSliderTouchListener(object : Slider.OnSliderTouchListener {
            override fun onStartTrackingTouch(slider: Slider) {}

            override fun onStopTrackingTouch(slider: Slider) {
                if (slider.value == 1.0f) {
                    if (indexSliderPeople > 0) {
                        slider.value = 4f
                        indexSliderPeople--
                        setLabelSlider(slider, indexSliderPeople, ll_values)
                    }
                } else if (slider.value == 4.0f) {
                    if (indexSliderPeople * 4 < listOfRange.size) {
                        slider.value = 1f
                        indexSliderPeople++
                        setLabelSlider(slider, indexSliderPeople, ll_values)
                    }
                }
                valueSliderPeople = slider.value
            }
        })

        btn_clear_all.setOnClickListener {
            valueSliderPeople = 5f
            slider.value = valueSliderPeople
            listSelectedLocationPeople.clear()
            listSelectedInterestPeople.clear()
            listSelectedMusicPeople.clear()
            listSelectedMoviesPeople.clear()
            listSelectedBooksPeople.clear()
            adaptorLocation.notifyDataSetChanged()
            adaptorInterest.notifyDataSetChanged()
        }

        setLabelSlider(slider, indexSliderPeople, ll_values)

        dialog.show()
    }
}