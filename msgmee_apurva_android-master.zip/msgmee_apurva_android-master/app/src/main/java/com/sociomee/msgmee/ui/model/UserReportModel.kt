package com.sociomee.msgmee.ui.model

import com.google.gson.annotations.SerializedName

data class UserReportModel(
        @SerializedName("data")
    val userReportData: UserReportData,
        @SerializedName("error")
    val error: Boolean,
        @SerializedName("success")
    val success: Boolean
) {
    data class UserReportData(
        @SerializedName("successResult")
        val reportList: ArrayList<ReportList>
    )
}
data class ReportList(
    @SerializedName("createdAt")
    val createdAt: String,
    @SerializedName("deletedAt")
    val deletedAt: Any,
    @SerializedName("id")
    val id: String,
    @SerializedName("isActive")
    val isActive: Int,
    @SerializedName("isDeleted")
    val isDeleted: Int,
    @SerializedName("reportText")
    val reportText: String,
    @SerializedName("type")
    val type: String,
    @SerializedName("updatedAt")
    val updatedAt: Any
)