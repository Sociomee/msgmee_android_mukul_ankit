package com.sociomee.msgmee.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sociomee.msgmee.R
import com.sociomee.msgmee.ui.`interface`.LanguageSelectCallback
import com.sociomee.msgmee.ui.model.LanguageList

class ChooseLanguageAdapter(val list: List<LanguageList>, private val languageSelectCallback: LanguageSelectCallback) :
        RecyclerView.Adapter<ChooseLanguageAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
            LayoutInflater.from(parent.context)
                    .inflate(R.layout.choose_language_child, parent, false))

    override fun getItemCount() = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvLanguage.text = list[position].name

        holder.itemView.setOnClickListener {
            languageSelectCallback.languageSelectCallback(position)
        }
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvLanguage: TextView = itemView.findViewById(R.id.txt_language)
    }
}