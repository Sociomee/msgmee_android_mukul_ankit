package com.sociomee.msgmee.ui.`interface`

interface SingleItemCallback {

    fun itemInteracted(position : Int)

}