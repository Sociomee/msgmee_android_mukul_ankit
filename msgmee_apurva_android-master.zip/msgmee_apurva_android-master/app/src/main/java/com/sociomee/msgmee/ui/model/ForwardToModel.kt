package com.sociomee.msgmee.ui.model

import com.google.gson.annotations.SerializedName

data class ForwardToModel(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("successResult")
        val successResult: SuccessResult
    ) {
        data class SuccessResult(
            @SerializedName("count")
            val count: Int,
            @SerializedName("rows")
            val rows: ArrayList<Row>
        ) {
            data class Row(
                @SerializedName("broadcastId")
                val broadcastId: String?,
                @SerializedName("broadcastListName")
                val broadcastListName: String?,
                @SerializedName("chatHeadId")
                val chatHeadId: String?,
                @SerializedName("chatHeadType")
                val chatHeadType: String,
                @SerializedName("friendFullName")
                val friendFullName: String?,
                @SerializedName("friendId")
                val friendId: String?,
                @SerializedName("friendImageThumb")
                val friendImageThumb: String?,
                @SerializedName("friendIsOnline")
                val friendIsOnline: String?,
                @SerializedName("friendUserName")
                val friendUserName: String?,
                @SerializedName("groupId")
                val groupId: String?,
                @SerializedName("groupImageThumb")
                val groupImageThumb: String?,
                @SerializedName("groupName")
                val groupName: String?,
                @SerializedName("userFullName")
                val userFullName: String,
                @SerializedName("userId")
                var userId: String?,
                @SerializedName("userImageThumb")
                var userImageThumb: String?,
                @SerializedName("userUserName")
                var userUserName: String?,
            )
        }
    }
}

data class ForwardToData(
    var userId: String = "",
    var userImageThumb: String? = "",
    var userUserName: String = "",
    var type: String = "",
    var isSelected: Boolean = false
)