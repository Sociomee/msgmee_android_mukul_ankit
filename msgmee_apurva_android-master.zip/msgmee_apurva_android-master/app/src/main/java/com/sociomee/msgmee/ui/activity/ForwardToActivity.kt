package com.sociomee.msgmee.ui.activity

import android.content.Intent
import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.`interface`.ItemSelectCallback
import com.sociomee.msgmee.ui.adapter.ForwardToAdapter
import com.sociomee.msgmee.ui.model.ForwardToData
import com.sociomee.msgmee.ui.model.SelectedChatModel
import com.sociomee.msgmee.ui.viewmodel.ForwardToVM
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.ScrollListener
import kotlinx.android.synthetic.main.forward_to_activity.*

class ForwardToActivity : CustomAppCompatActivity(), ItemSelectCallback {

    private lateinit var forwardToVM: ForwardToVM
    private lateinit var forwardToAdapter: ForwardToAdapter
    private var forwardToList = ArrayList<ForwardToData>()
    private var isLastPage = false
    private var isLoading = false
    private var searchText = ""
    private var isSearch = false
    private var pageIndex = 0
    private var selectedFriendList = ArrayList<SelectedChatModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.forward_to_activity)

        bindData()
        initData()
        observeData()
        setViewsClick()

        Log.v("harshThread", "onCreate is main thread == ${Looper.myLooper() == Looper.getMainLooper()}")
    }

    private fun initData() {
        forwardToVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            ForwardToVM::class.java
        )
    }

    private fun observeData() {
        forwardToVM.observeForwardToList().observe(this, Observer {
            pb_forward_to.visibility = View.GONE
            isLoading = false
            if(it.isEmpty()) {
                isLastPage = true
            } else {
                if(isSearch) {
                    forwardToList.clear()
                }
                Log.v("harshThread", "observeForwardToList is main thread == ${Looper.myLooper() == Looper.getMainLooper()}")
                it.forEach { model ->
                    val data = ForwardToData()
                    when {
                        model.friendId != null -> {
                            data.userUserName = model.friendUserName ?: ""
                            data.userId = model.friendId
                            data.type = "user"
                            data.userImageThumb = model.friendImageThumb
                        }
                        model.groupId != null -> {
                            data.userUserName = model.groupName ?: ""
                            data.userId = model.groupId
                            data.type = "group"
                            data.userImageThumb = model.groupImageThumb
                        }
                        model.broadcastId != null -> {
                            data.userUserName = model.broadcastListName ?: ""
                            data.userId = model.broadcastId
                            data.type = "broadcast"
                            data.userImageThumb = null
                        }
                        model.userId != null -> {
                            data.userUserName = model.userUserName ?: ""
                            data.userId = model.userId!!
                            data.type = "user"
                            data.userImageThumb = null
                        }
                    }
                    val index = selectedFriendList.indexOfFirst { selectedChatModel ->
                        selectedChatModel.id == data.userId
                    }
                    if(index != -1) {
                        data.isSelected = true
                    }
                    forwardToList.add(data)
                    Log.v("harshThread", "forEach is main thread == ${Looper.myLooper() == Looper.getMainLooper()}")
                }
                forwardToAdapter.notifyDataSetChanged()
                Log.v("harshThread", "notifyDataSetChanged is main thread == ${Looper.myLooper() == Looper.getMainLooper()}")
            }
            isSearch = false
        })

        // fetching data
        fetchForwardToList()

        // observing error
        observeError()
    }

    private fun fetchForwardToList() {
        pb_forward_to.visibility = View.VISIBLE

        val bodyMap: HashMap<String, Any> = hashMapOf(
            "pageSize" to Constants.globalPageSize,
            "pageIndex" to pageIndex,
            "searchKey" to searchText
        )
        forwardToVM.fetchForwardToList(bodyMap)
    }

    private fun observeError() {
        forwardToVM.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    showToast("Server Error")
                }
                else -> {
                }
            }
        })
    }

    private fun setViewsClick() {
        img_toolbar_back.setOnClickListener {
            onBackPressed()
        }
        edt_search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                if(edt_search.text.toString() != searchText) {
                    searchText = edt_search.text.toString()
                    pageIndex = 0
                    isLastPage = false
                    isSearch = true
                    fetchForwardToList()
                }
                return@setOnEditorActionListener true
            }
            return@setOnEditorActionListener false
        }
        txt_done.setOnClickListener {
            if(selectedFriendList.size > 0) {
                val intent = Intent()
                intent.putParcelableArrayListExtra("selectedChatList", selectedFriendList)
                setResult(RESULT_OK, intent)
            }
            finish()
        }
    }

    override fun setInitialLanguage() {
        txt_chat_head_name.text = getString(R.string.forward_to)
        txt_done.text = getString(R.string.send)
        edt_search.hint = getString(R.string.search_)
    }

    override fun bindData() {
        forwardToAdapter = ForwardToAdapter(forwardToList, this)
        val layoutManager = LinearLayoutManager(this)
        rl_forward_list.layoutManager = layoutManager
        rl_forward_list.adapter = forwardToAdapter
        txt_done.alpha = 0.5f
        txt_selected_count.visibility = View.GONE

        // listening for pagination
        // adding scroll listener for pagination
        rl_forward_list.addOnScrollListener(object : ScrollListener(layoutManager) {
            override fun isNewLastPage() = true
            override fun isOldLastPage() = isLastPage
            override fun isLoading() = isLoading
            override fun loadNewItems() {}

            override fun loadOldItems() {
                isSearch = false
                isLoading = true
                pageIndex++
                fetchForwardToList()
            }
        })
    }

    override fun itemSelectionChanged(position: Int, id: String, type: String, isSelected: Boolean) {
        val model = SelectedChatModel(type, id)
        selectedFriendList.remove(model)
        if(isSelected) {
            selectedFriendList.add(model)
        }
        if (selectedFriendList.size == 0) {
            txt_selected_count.visibility = View.GONE
            txt_done.alpha = 0.5f
        } else {
            txt_selected_count.visibility = View.VISIBLE
            val peopleData = "${selectedFriendList.size} ${getString(R.string.selected)}"
            txt_selected_count.text = peopleData
            txt_done.alpha = 1.0f
        }
    }

}