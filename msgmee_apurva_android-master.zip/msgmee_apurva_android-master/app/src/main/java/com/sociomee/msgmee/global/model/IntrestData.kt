package com.sociomee.msgmee.global.model

data class IntrestData (val intrestName:String,var isSelected:Boolean=false)