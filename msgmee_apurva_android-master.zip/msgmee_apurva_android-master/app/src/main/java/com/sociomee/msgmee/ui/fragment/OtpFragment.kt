package com.sociomee.msgmee.ui.fragment

import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.util.TypedValue
import android.view.View
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.activity.ForgotPasswordActivity
import com.sociomee.msgmee.ui.activity.SignUpActivity
import com.sociomee.msgmee.ui.data.AuthModel
import com.sociomee.msgmee.ui.viewmodel.AuthSharedViewModel
import com.sociomee.msgmee.ui.viewmodel.OtpViewModel
import com.sociomee.msgmee.utils.AuthenticationUtil
import com.sociomee.msgmee.utils.OtpEditText
import com.sociomee.msgmee.utils.SmsReceiver
import kotlinx.android.synthetic.main.otp_fragment.*


class OtpFragment : Fragment(R.layout.otp_fragment) {

    lateinit var authSharedViewModel: AuthSharedViewModel
    lateinit var otpViewModel: OtpViewModel
    lateinit var countDownTimer: CountDownTimer
    lateinit var savedAuth: AuthModel
    private lateinit var otpType: AuthenticationUtil.OtpType
    lateinit var smsReceiver: SmsReceiver

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        smsReceiver =  SmsReceiver()
        smsReceiver.setOtp(edt_pin1, edt_pin2, edt_pin3, edt_pin4, edt_pin5, edt_pin6)

        when(activity) {
            is SignUpActivity -> otpType = AuthenticationUtil.OtpType.SIGNUP
            is ForgotPasswordActivity -> otpType = AuthenticationUtil.OtpType.FORGOT_PASSWORD
        }

        setInitialLanguage()

        val otpEditText = OtpEditText(context!!, edt_pin1, edt_pin2, edt_pin3, edt_pin4, edt_pin5,
                edt_pin6)

        if (activity is ForgotPasswordActivity)
            progressBar.visibility = View.GONE

        img_toolbar_back.setOnClickListener {
            if (activity is SignUpActivity)
                (activity as SignUpActivity).onBackPress()
            else if (activity is ForgotPasswordActivity)
                (activity as ForgotPasswordActivity).onBackPressed()
        }

        btn_continue.setOnClickListener {
            if (activity is SignUpActivity) {
                val enteredOtp = otpEditText.text
                otpViewModel.verifyOtp(
                        hashMapOf("otp" to enteredOtp, "sentTo" to savedAuth.enteredCredential,
                                "type" to "signup"))
            } else if (activity is ForgotPasswordActivity)
            {
                val enteredOtp = otpEditText.text
                otpViewModel.verifyOtp(
                        hashMapOf("otp" to enteredOtp, "sentTo" to savedAuth.enteredCredential,
                                "type" to  AuthenticationUtil.OtpType.FORGOT_PASSWORD.type))
            }
//                (activity as ForgotPasswordActivity).changeFragment(ResetPasswordFragment(),
//                        "UserCredentialsFragment")
        }




        initData()
        observeData()
        setViewsClick()
    }

    private fun setViewsClick() {
        txt_resend.setOnClickListener {
            txt_time_limit.visibility = View.VISIBLE
            txt_did_not_.visibility = View.GONE
            txt_resend.visibility = View.GONE

            setUpTimer()
            // resending otp
            val bodyMap = HashMap<String, Any>().apply {
                put("isEmail", savedAuth.isEmail)
                put("type", otpType.type)
                if (savedAuth.isEmail) {
                    put("email", savedAuth.enteredCredential)
                } else {
                    put("mobile", savedAuth.enteredCredential)
                }
            }
            otpViewModel.sendOtp(bodyMap)
        }
    }

    private fun initData() {

        authSharedViewModel = ViewModelProvider(requireActivity(),
                ViewModelProvider.NewInstanceFactory()).get(
                AuthSharedViewModel::class.java
        )

        otpViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
                OtpViewModel::class.java)
    }

    private fun observeData() {
        authSharedViewModel.observeSavedAuth().observe(viewLifecycleOwner, Observer {
            savedAuth = it
            txt_contact.text = savedAuth.enteredCredential
            setUpTimer()
        })
        otpViewModel.observeLoading().observe(this, Observer {
            (activity as CustomAppCompatActivity).changeLoadingStatus(it!!)
        })
        otpViewModel.observeOtpVerification().observe(this, Observer {
            if (!it) {
                txt_error.visibility = View.VISIBLE
                txt_error.text = getString(R.string.wrong_otp)
            } else {
                txt_error.visibility = View.GONE
                (activity as CustomAppCompatActivity).showToast(
                        getString(R.string.otp_verified_successfully))
                if(activity is ForgotPasswordActivity){
                    (activity as ForgotPasswordActivity).changeFragment(ResetPasswordFragment(),
                            "ResetPasswordFragment")
                }
                else if(activity is SignUpActivity) {
                    (activity as SignUpActivity).changeFragment(
                            AuthenticationUtil.SignupFragmentType.CREDENTIAL, "UserCredentialsFragment")
                }


            }
        })
        otpViewModel.observeOtpSent().observe(this, Observer {
            if (!it) {
                txt_error.visibility = View.VISIBLE
                txt_error.text = getString(R.string.something_went_wrong_)
            } else {
                setUpTimer()
            }
        })

        // observing errors
        observeError()
    }

    private fun observeError() {
        otpViewModel.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    (activity as CustomAppCompatActivity).showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    (activity as CustomAppCompatActivity).showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    (activity as CustomAppCompatActivity).showToast("Server Error")
                }
                else -> {
                }
            }
        })
    }

    private fun setUpTimer() {
        val typedValue = TypedValue()
        context!!.theme.resolveAttribute(R.attr.titleTextColor, typedValue, true)
        txt_time_limit.setTextColor(typedValue.data)

        countDownTimer = object : CountDownTimer(30000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                Log.v("harsh", "counter $millisUntilFinished")
                try {
                    val remainingTime = "${millisUntilFinished / 1000} ${getString(R.string.sec)}"
                    txt_time_limit.text = remainingTime
                    if (millisUntilFinished < 10000) {
                        txt_time_limit.setTextColor(ContextCompat.getColor(context!!, R.color.red))
                    }
                } catch (e: Exception) {
                    Log.v("harsh", "exception occurred")
                }
            }

            override fun onFinish() {
                Log.v("harsh", "counter finished")
                try {
                    txt_time_limit.visibility = View.GONE
                    txt_did_not_.visibility = View.VISIBLE
                    txt_resend.visibility = View.VISIBLE
                } catch (e: Exception) {
                    Log.v("harsh", "exception occurred")
                }
            }
        }
        countDownTimer.start()
    }

    private fun setInitialLanguage() {
        txt_enter_otp.setText(R.string.enter_otp)
        txt_resend.setText(R.string.resend)
        txt_did_not_.setText(R.string.didn_t_receive_)
        btn_continue.setText(R.string.continue_btn)
        txt_did_not_.visibility = View.GONE
        txt_resend.visibility = View.GONE
    }

    override fun onDestroyView() {
        Log.v("harsh", "fragment detached")
        countDownTimer.cancel()
        super.onDestroyView()
    }

}