package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.model.CallHistoryModel
import com.sociomee.msgmee.ui.repo.CallHistoryRepo

class CallHistoryVM: MyViewModel() {

    private var callHistoryList = MutableLiveData<CallHistoryModel.Data>()
    private lateinit var callHistoryRepo: CallHistoryRepo

    // returning LiveData
    fun observeCallHistoryList() = callHistoryList

    fun fetchCallHistoryList(bodyMap: HashMap<String, Any>, isRefresh: Boolean = false) {
        if(!this::callHistoryRepo.isInitialized) {
            callHistoryRepo = CallHistoryRepo()
        }
        callHistoryRepo.fetchCallHistoryList(bodyMap).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                it.data!!.isRefresh = isRefresh
                callHistoryList.value = it.data
            } else {
                errorListener.value = it.status
            }
        }
    }

    fun fetchUserCallHistoryList(bodyMap: HashMap<String, Any>, isRefresh: Boolean = false) {
        if(!this::callHistoryRepo.isInitialized) {
            callHistoryRepo = CallHistoryRepo()
        }
        callHistoryRepo.fetchUserCallHistoryList(bodyMap).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                it.data!!.isRefresh = isRefresh
                callHistoryList.value = it.data
            } else {
                errorListener.value = it.status
            }
        }
    }

}