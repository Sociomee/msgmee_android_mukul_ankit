package com.sociomee.msgmee.ui.adapter

import android.content.Intent
import android.graphics.Color
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.widget.CustomIconView
import com.sociomee.msgmee.custom.widget.CustomImageView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.activity.CallInfoActivity
import com.sociomee.msgmee.ui.model.CallHistoryData
import com.sociomee.msgmee.ui.model.StartCallModel
import com.sociomee.msgmee.ui.model.UserDataPassModel
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.TimeAgo
import com.sociomee.msgmee.utils.VerticalTextView

class CallsListAdapter(val list: ArrayList<CallHistoryData>) :
    RecyclerView.Adapter<CallsListAdapter.MessageListHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = MessageListHolder(
        LayoutInflater.from(
            parent.context
        ).inflate(R.layout.call_list_child, parent, false)
    )

    override fun getItemCount() = list.size

    override fun onBindViewHolder(holder: MessageListHolder, position: Int) {
        val model = list[position]

        Glide.with(holder.itemView.context).load(model.members[0].profileThumb)
            .placeholder(R.drawable.profile_placeholder).into(holder.img_calls_profile)

        holder.txt_calls_name.text = model.members[0].name
        holder.txt_call_time.text = TimeAgo.getTimeAgo(model.startTime)
        holder.txt_last_call.text = model.callText

        val typedValue = TypedValue()
        holder.itemView.context.theme.resolveAttribute(R.attr.titleTextColor, typedValue, true)

        when (model.callType) {
            Constants.CallType.MISSED_VIDEO -> {
                holder.txt_last_call.setTextColor(
                    ContextCompat.getColor(
                        holder.itemView.context,
                        R.color.red
                    )
                )
                Glide.with(holder.itemView.context).load(R.drawable.ic_call_missed_video)
                    .into(holder.img_last_call)
            }
            Constants.CallType.MISSED_AUDIO -> {
                holder.txt_last_call.setTextColor(
                    ContextCompat.getColor(
                        holder.itemView.context,
                        R.color.red
                    )
                )
                Glide.with(holder.itemView.context).load(R.drawable.ic_call_missed_audio)
                    .into(holder.img_last_call)
            }
            Constants.CallType.OUTGOING_VIDEO -> {
                holder.txt_last_call.setTextColor(typedValue.data)
                Glide.with(holder.itemView.context).load(R.drawable.ic_call_outgoing_video)
                    .into(holder.img_last_call)
            }
            Constants.CallType.OUTGOING_AUDIO -> {
                holder.txt_last_call.setTextColor(typedValue.data)
                Glide.with(holder.itemView.context).load(R.drawable.ic_call_outgoing_audio)
                    .into(holder.img_last_call)
            }
            Constants.CallType.INCOMING_VIDEO -> {
                holder.txt_last_call.setTextColor(typedValue.data)
                Glide.with(holder.itemView.context).load(R.drawable.ic_call_incoming_video)
                    .into(holder.img_last_call)
            }
            Constants.CallType.INCOMING_AUDIO -> {
                holder.txt_last_call.setTextColor(typedValue.data)
                Glide.with(holder.itemView.context).load(R.drawable.ic_call_incoming_audio)
                    .into(holder.img_last_call)
            }
        }

        holder.img_video_call.setOnClickListener {
            val otherCallerIndex = model.members.indexOfFirst {
                it.name != Constants.userInfo!!.username
            }
            if (otherCallerIndex == -1) {
                (holder.itemView.context as CustomAppCompatActivity).showToast()
            } else {
                Constants.startCall(
                    holder.itemView.context, true, StartCallModel(
                        model.members[otherCallerIndex].name,
                        model.members[otherCallerIndex].name,
                        model.members[otherCallerIndex].id,
                        model.members[otherCallerIndex].profileThumb
                    )
                )
            }
        }
        holder.img_audio_call.setOnClickListener {
            val otherCallerIndex = model.members.indexOfFirst {
                it.name != Constants.userInfo!!.username
            }
            if (otherCallerIndex == -1) {
                (holder.itemView.context as CustomAppCompatActivity).showToast()
            } else {
                Constants.startCall(
                    holder.itemView.context, false, StartCallModel(
                        model.members[otherCallerIndex].name,
                        model.members[otherCallerIndex].name,
                        model.members[otherCallerIndex].id,
                        model.members[otherCallerIndex].profileThumb
                    )
                )
            }
        }

        holder.itemView.setOnClickListener {
            val intent = Intent(
                holder.itemView.context,
                CallInfoActivity::class.java
            )
            intent.putExtra(
                "userData", Constants.myGson.toJson(
                    UserDataPassModel(
                        model.members[0].name,
                        model.members[0].profileThumb,
                        model.members[0].id
                    )
                )
            )
            holder.itemView.context.startActivity(
                intent
            )
        }

        if (model.members.size > 1) {
            holder.cl_call_type.visibility = View.VISIBLE
            holder.cl_call_type.setBackgroundColor(Color.parseColor("#688473"))
            holder.txt_call_type.text = holder.itemView.context.getString(R.string.group)
        } else {
            holder.cl_call_type.visibility = View.GONE
        }
    }

    class MessageListHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cl_call_type = itemView.findViewById<ConstraintLayout>(R.id.cl_call_type)
        val txt_call_type = itemView.findViewById<VerticalTextView>(R.id.txt_call_type)
        val img_calls_profile = itemView.findViewById<CustomImageView>(R.id.img_calls_profile)
        val txt_calls_name = itemView.findViewById<CustomTextView>(R.id.txt_calls_name)
        val txt_last_call = itemView.findViewById<CustomTextView>(R.id.txt_last_call)
        val txt_call_time = itemView.findViewById<CustomTextView>(R.id.txt_call_time)
        val img_last_call = itemView.findViewById<CustomIconView>(R.id.img_last_call)
        val img_video_call = itemView.findViewById<CustomIconView>(R.id.img_video_call)
        val img_audio_call = itemView.findViewById<CustomIconView>(R.id.img_audio_call)
    }
}