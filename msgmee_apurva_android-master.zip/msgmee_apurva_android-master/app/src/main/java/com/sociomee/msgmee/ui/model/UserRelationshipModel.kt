package com.sociomee.msgmee.ui.model

import com.google.gson.annotations.SerializedName

data class UserRelationshipModel(
        @SerializedName("data")
    val userRelationshipData: UserRelationshipData,
        @SerializedName("error")
    val error: Boolean,
        @SerializedName("success")
    val success: Boolean
) {
    data class UserRelationshipData(
        @SerializedName("successResult")
        val successResult: List<UserRelationshipList>
    )
    data class UserRelationshipList(
            @SerializedName("byAdmin")
            val byAdmin: Int,
            @SerializedName("id")
            val id: String,
            @SerializedName("name")
            val name: String
    )
}