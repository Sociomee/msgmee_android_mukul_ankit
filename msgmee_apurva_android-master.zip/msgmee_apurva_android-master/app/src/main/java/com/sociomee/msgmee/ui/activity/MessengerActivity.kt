package com.sociomee.msgmee.ui.activity

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.tabs.TabLayout
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.fragment.CallsListFragment
import com.sociomee.msgmee.ui.fragment.ChatHeadListFragment
import com.sociomee.msgmee.ui.model.ChatHeadSearched
import com.sociomee.msgmee.ui.repo.UpdateUserRepo
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.MyPreferences
import kotlinx.android.synthetic.main.messenger_activity.*
import org.greenrobot.eventbus.EventBus


class MessengerActivity : CustomAppCompatActivity() {

    private var isMessageOpen = true
    private var isMultiSelectOpen = false
    private var messengerFragment: Fragment? = null
    private var callFragment: Fragment? = null
//    private var pageFragment: Fragment? = null
//    private var marketFragment: Fragment? = null
    private lateinit var toolbar: Toolbar
    private var searchText = ""
    private var searchDelay: Long = 600 // 600 milliseconds
    private var searchHandler: Handler? = null
    private var isOpenCall = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.messenger_activity)

        isOpenCall = intent?.extras?.getBoolean("isOpenCall") ?: false

        toolbar = findViewById(R.id.custom_toolbar)
        setSupportActionBar(toolbar)
        supportActionBar!!.title = getString(R.string.message_mee)

        bindData()
        setViewClicks()
    }

    override fun setInitialLanguage() {
//        txt_toolbar_text.text = getString(R.string.social_messages)
    }

    override fun bindData() {
        messenger_tablayout.addTab(messenger_tablayout.newTab().setText(getString(R.string.social)))
//        messenger_tablayout.addTab(messenger_tablayout.newTab().setText(getString(R.string.page)))
//        messenger_tablayout.addTab(messenger_tablayout.newTab().setText(getString(R.string.market)))
        messenger_tablayout.addTab(messenger_tablayout.newTab().setText(getString(R.string.calls)))
    }

    private fun setViewClicks() {
//        toolbar.setNavigationOnClickListener {
//            onBackPressed()
//        }

        val tl = (messenger_tablayout.getChildAt(0) as ViewGroup).getChildAt(if (isOpenCall) 0 else 1) as LinearLayout
        val tv = tl.getChildAt(1) as TextView
        val defaultTypeface = tv.typeface

        messenger_tablayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabReselected(tab: TabLayout.Tab?) {

            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                val tlu =
                    (messenger_tablayout.getChildAt(0) as ViewGroup).getChildAt(
                        tab!!.position
                    ) as LinearLayout
                val tvu = tlu.getChildAt(1) as TextView
                tvu.typeface = defaultTypeface
            }

            override fun onTabSelected(tab: TabLayout.Tab?) {
                val tls =
                    (messenger_tablayout.getChildAt(0) as ViewGroup).getChildAt(
                        tab!!.position
                    ) as LinearLayout
                val tvs = tls.getChildAt(1) as TextView
                tvs.setTypeface(tvs.typeface, Typeface.BOLD)

                when (tab.position) {
                    0 -> {
                        isMessageOpen = true
                        if (messengerFragment == null) {
                            messengerFragment = ChatHeadListFragment()
                        }
                        transactFragment(messengerFragment!!, "socialMessenger")
                    }
//                    1 -> {
//                        isMessageOpen = false
//                        if(pageFragment == null) {
//                            pageFragment = PageMessengerFragment()
//                        }
//                        transactFragment(pageFragment!!, "pageMessenger")
//                    }
//                    2 -> {
//                        isMessageOpen = false
//                        if(marketFragment == null) {
//                            marketFragment = MarketMessengerFragment()
//                        }
//                        transactFragment(marketFragment!!, "marketMessenger")
//                    }
                    1 -> {
                        isMessageOpen = false
                        if (callFragment == null) {
                            callFragment = CallsListFragment()
                        }
                        transactFragment(callFragment!!, "callList")
                    }
                }
            }
        })

        // opening default tab
        if(isOpenCall) {
            isMessageOpen = false
            callFragment = CallsListFragment()
            transactFragment(callFragment!!, "callList")
            val tls =
                (messenger_tablayout.getChildAt(0) as ViewGroup).getChildAt(1) as LinearLayout
            val tvs = tls.getChildAt(1) as TextView
            tvs.setTypeface(tvs.typeface, Typeface.BOLD)
            messenger_tablayout.getTabAt(1)!!.select()
        } else {
            isMessageOpen = true
            messengerFragment = ChatHeadListFragment()
            transactFragment(messengerFragment!!, "socialMessenger")
            val tls =
                (messenger_tablayout.getChildAt(0) as ViewGroup).getChildAt(0) as LinearLayout
            val tvs = tls.getChildAt(1) as TextView
            tvs.setTypeface(tvs.typeface, Typeface.BOLD)
            messenger_tablayout.getTabAt(0)!!.select()
        }
    }

    private fun transactFragment(fragment: Fragment, tag: String) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fl_messenger, fragment, tag)
            .commit()
    }

    @SuppressLint("InflateParams")
    private fun showOptionsMenu() {
        val view = LayoutInflater.from(this).inflate(R.layout.profile_options_bs, null)
        val dialog = BottomSheetDialog(this, R.style.SheetDialog)
        dialog.setContentView(view)

        val txt_menu_1 = view.findViewById<CustomTextView>(R.id.txt_menu_1)
        val txt_menu_2 = view.findViewById<CustomTextView>(R.id.txt_menu_2)
        val txt_menu_3 = view.findViewById<CustomTextView>(R.id.txt_menu_3)
        val txt_menu_4 = view.findViewById<CustomTextView>(R.id.txt_menu_4)
        val txt_menu_5 = view.findViewById<CustomTextView>(R.id.txt_menu_5)

        txt_menu_1.text = getString(R.string.new_message)
        if (isMessageOpen) {
            txt_menu_2.text = getString(R.string.new_group)
            txt_menu_3.text = getString(R.string.broadcast)

            txt_menu_2.setOnClickListener {
                val intent = Intent(this, FriendListActivity::class.java)
                intent.putExtra("type", Constants.PeopleSelectType.GROUP)
                startActivity(intent)
                dialog.dismiss()
            }
            txt_menu_3.setOnClickListener {
                val intent = Intent(this, FriendListActivity::class.java)
                intent.putExtra("type", Constants.PeopleSelectType.BROADCAST)
                startActivity(intent)
                dialog.dismiss()
            }
        } else {
            txt_menu_2.text = getString(R.string.new_audio_call)
            txt_menu_3.text = getString(R.string.new_video_call)

            txt_menu_2.setOnClickListener {
                val intent = Intent(this, FriendListActivity::class.java)
                intent.putExtra("type", Constants.PeopleSelectType.CALL)
                intent.putExtra("isVideoCall", false)
                startActivity(intent)
                dialog.dismiss()
            }
            txt_menu_3.setOnClickListener {
                val intent = Intent(this, FriendListActivity::class.java)
                intent.putExtra("type", Constants.PeopleSelectType.CALL)
                intent.putExtra("isVideoCall", true)
                startActivity(intent)
                dialog.dismiss()
            }
        }
        txt_menu_1.setOnClickListener {
            val intent = Intent(this, FriendListActivity::class.java)
            intent.putExtra("type", Constants.PeopleSelectType.SINGLE)
            startActivity(intent)
            dialog.dismiss()
        }

        txt_menu_4.text = getString(R.string.settings)
        txt_menu_5.text = getString(R.string.log_out)

        txt_menu_5.setOnClickListener {
            dialog.dismiss()
            UpdateUserRepo.logOutUser()
            MyPreferences.deleteStringInPreference(this, Constants.userDataKey)
            Constants.userInfo=null
            startActivity(LoginActivity::class.java)
            finish()
        }

        dialog.show()
    }

    fun multiSelectChange(isMultiSelectOpen: Boolean) {
        group_toolbar.visibility = if (isMultiSelectOpen) View.GONE else View.VISIBLE
        this.isMultiSelectOpen = isMultiSelectOpen
    }

    override fun onBackPressed() {
        if (isMessageOpen && isMultiSelectOpen) {
            val fragment =
                supportFragmentManager.findFragmentByTag("messageList") as ChatHeadListFragment
            fragment.resetMultiSelect()
        } else {
            super.onBackPressed()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.messenger_toolbar_menu, menu!!)
        val searchViewItem = menu.findItem(R.id.mt_search)
        val searchView = searchViewItem.actionView as SearchView
        searchView.queryHint = getString(R.string.search_friends)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                searchView.clearFocus()
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                Log.v("harsh", "messenger search == $newText")
                searchText = newText ?: ""

                if (searchHandler != null) {
                    searchHandler!!.removeCallbacks(searchRunnable)
                } else {
                    searchHandler = Handler(Looper.myLooper()!!)
                }
                searchHandler!!.postDelayed(searchRunnable, searchDelay)
                return true
            }

        })
        return super.onCreateOptionsMenu(menu)
    }

    val searchRunnable = Runnable {
        EventBus.getDefault().post(ChatHeadSearched(searchText))
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.mt_options) {
            showOptionsMenu()
        } else if (item.itemId == R.id.mt_copy) {
            copyFCM()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun copyFCM() {
        val clipboard: ClipboardManager =
            getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("", MyPreferences.getFcmToken(this))
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, "FCM copied to clipboard", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        if(searchHandler != null){
            searchHandler!!.removeCallbacks(searchRunnable)
        }
    }
}