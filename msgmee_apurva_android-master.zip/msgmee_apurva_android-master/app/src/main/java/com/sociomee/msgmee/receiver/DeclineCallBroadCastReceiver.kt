package com.sociomee.msgmee.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import com.sociomee.msgmee.notification.MyNotificationBuilder
import com.sociomee.msgmee.ui.repo.CallingRepo

class DeclineCallBroadCastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        val callingRepo = CallingRepo()

        val bodyMap: HashMap<String, Any> = hashMapOf(
            "callRoomId" to MyNotificationBuilder.callRoomId,
            "callState" to "ended"
        )
        callingRepo.updateCallState(bodyMap, type = "decline")

        // closing notification
        with(NotificationManagerCompat.from(context!!)) {
            cancel(MyNotificationBuilder.callNotificationId)
        }
    }

}