package com.sociomee.msgmee.ui.activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.gson.Gson
import com.luck.picture.lib.PictureSelector
import com.luck.picture.lib.config.PictureConfig
import com.luck.picture.lib.entity.LocalMedia
import com.luck.picture.lib.instagram.InsGallery
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.imagePicker.GlideCacheEngine
import com.sociomee.msgmee.imagePicker.GlideEngine
import com.sociomee.msgmee.ui.`interface`.GroupInfoInterface
import com.sociomee.msgmee.ui.adapter.GroupAdapter
import com.sociomee.msgmee.ui.model.ChatHeadInfo
import com.sociomee.msgmee.ui.model.GroupInfoData
import com.sociomee.msgmee.ui.model.ChatMemberData
import com.sociomee.msgmee.ui.model.MediaModel
import com.sociomee.msgmee.ui.viewmodel.GroupInfoVM
import com.sociomee.msgmee.ui.viewmodel.MediaUploadVM
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.MyPreferences
import com.sociomee.msgmee.utils.mediaFullUrl
import com.yalantis.ucrop_.UCrop
import kotlinx.android.synthetic.main.group_info_activity.*
import kotlinx.android.synthetic.main.group_info_activity.img_group_profile
import kotlinx.android.synthetic.main.group_info_activity.txt_name
import kotlinx.android.synthetic.main.select_media_dialog.view.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap
import androidx.lifecycle.Observer

class GroupInfoActivity : CustomAppCompatActivity(), GroupInfoInterface {

    private var isRefresh: Boolean = true
    private lateinit var groupInfoVM: GroupInfoVM
    private lateinit var groupInfoData: GroupInfoData
    private lateinit var groupId: String
    private var groupMemberList = ArrayList<ChatMemberData>()
    private var pageNo = 0
    private var searchText = ""
    private lateinit var groupAdapter: GroupAdapter
    private val REQUIRED_PERMISSIONS = arrayOf(
        "android.permission.CAMERA",
    )
    private val REQUEST_CODE_PERMISSIONS = 101
    private val ADD_PARTICIPANT_CODE = 103
    private val CAMERA_REQUEST = 102
    private lateinit var capturedPhotoPath: String
    private var groupImagePath: String? = null
    private var gallerySelectedImage: LocalMedia? = null
    private lateinit var mediaUploadVM: MediaUploadVM
    private var groupUpdateData: ChatHeadInfo? = null
    private var isMute: Boolean = false
    private var is1stTime = true
    private var optionSelectPosition: Int = 0
    private var isMember = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.group_info_activity)

        groupId = intent!!.extras!!.getString("groupId", "")

        initData()
        observeData()
        bindData()
        setViewsClick()
    }

    private fun setViewsClick() {
        img_back.setOnClickListener {
            onBackPressed()
        }
        txt_change.setOnClickListener {
            openMediaBottomSheet()
        }
        txt_save.setOnClickListener {
            if (edt_name.text.toString().isEmpty()) {
                showToast("Group Name can't be empty")
                return@setOnClickListener
            }
            if (groupImagePath != null) {
                mediaUploadVM.uploadPathMedia(
                    listOf(
                        MediaModel(
                            groupImagePath!!,
                            Constants.SelectedMediaType.IMAGE
                        )
                    ), "groupDp"
                )
            } else {
                updateGroup()
            }
        }
        cb_mute.setOnCheckedChangeListener { _, isChecked ->
            isMute = isChecked
        }
        txt_add_participant.setOnClickListener {
            if (isMember) {
                val bodyMap: HashMap<String, Any> = hashMapOf(
                    "groupId" to groupId
                )
                groupInfoVM.leaveGroup(bodyMap)
            } else {
                val intent = Intent(this, FriendListActivity::class.java)
                intent.putExtra("type", Constants.PeopleSelectType.GROUP_ADD_PEOPLE)
                intent.putExtra("groupId", groupId)
                startActivityForResult(intent, ADD_PARTICIPANT_CODE)
            }
        }
    }

    override fun memberLongPressed(position: Int) {
        if (isMember || Constants.isCurrentUser(groupMemberList[position].id))
            return
        showPeopleActionDialog(position)
    }

    private fun showPeopleActionDialog(position: Int) {
        optionSelectPosition = position

        val view = LayoutInflater.from(this).inflate(R.layout.profile_options_bs, null)
        val dialog = BottomSheetDialog(this, R.style.SheetDialog)
        val isMember = groupMemberList[optionSelectPosition].role == "member"
        dialog.setContentView(view)

        val txt_menu_1 = view.findViewById<CustomTextView>(R.id.txt_menu_1)
        val txt_menu_2 = view.findViewById<CustomTextView>(R.id.txt_menu_2)
        val txt_menu_3 = view.findViewById<CustomTextView>(R.id.txt_menu_3)
        val txt_menu_4 = view.findViewById<CustomTextView>(R.id.txt_menu_4)
        val txt_menu_5 = view.findViewById<CustomTextView>(R.id.txt_menu_5)
        val view_menu_2 = view.findViewById<View>(R.id.view_menu_2)
        val view_menu_3 = view.findViewById<View>(R.id.view_menu_3)
        val view_menu_4 = view.findViewById<View>(R.id.view_menu_4)

        txt_menu_3.visibility = View.GONE
        view_menu_2.visibility = View.GONE
        txt_menu_4.visibility = View.GONE
        view_menu_3.visibility = View.GONE
        txt_menu_5.visibility = View.GONE
        view_menu_4.visibility = View.GONE

        if (isMember) {
            txt_menu_2.text = getString(R.string.make_admin)
        } else {
            txt_menu_2.text = getString(R.string.remove_from_admin)
        }

        txt_menu_1.text = getString(R.string.remove_from_group)

        txt_menu_1.setOnClickListener {
            val bodyMap = hashMapOf(
                "groupId" to groupId,
                "members" to listOf(
                    hashMapOf(
                        "memberId" to groupMemberList[position].id,
                        "memberName" to groupMemberList[position].userName
                    )
                )
            )
            groupInfoVM.removeUserFromGroup(bodyMap)
            dialog.dismissWithAnimation = true
            dialog.dismiss()
        }

        txt_menu_2.setOnClickListener {
            val bodyMap = hashMapOf(
                "groupId" to groupId,
                "memberIds" to listOf(groupMemberList[position].id)
            )
            if (isMember) {
                bodyMap["role"] = "admin"
            }
            groupInfoVM.changeGroupMemberRole(bodyMap)
            dialog.dismissWithAnimation = true
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun initData() {
        groupInfoVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            GroupInfoVM::class.java
        )
        mediaUploadVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            MediaUploadVM::class.java
        )
    }

    private fun observeData() {
        groupInfoVM.observeLoading().observe(this, Observer {
            changeLoadingStatus(it)
        })
        mediaUploadVM.observeLoading().observe(this, Observer {
            changeLoadingStatus(it)
        })
        groupInfoVM.observerGroupInfo().observe(this, Observer {
            groupInfoData = it
            isMember = groupInfoData.role == "member"
            fetchGroupPeople()
            bindGroupData()
        })
        groupInfoVM.observerGroupPeopleList().observe(this, Observer {
            if (isRefresh) {
                groupMemberList.clear()
                isRefresh = false
            }
            groupMemberList.addAll(it)
            groupAdapter.notifyDataSetChanged()
        })
        groupInfoVM.observerGroupUpdate().observe(this, Observer {
            val intent = Intent()
            intent.putExtra("updatedData", Gson().toJson(groupUpdateData))
            setResult(RESULT_OK, intent)
            finish()
        })
        groupInfoVM.observerMemberRoleChange().observe(this, Observer {
            groupMemberList[optionSelectPosition].role =
                if (groupMemberList[optionSelectPosition].role == "member") {
                    "admin"
                } else {
                    "member"
                }
            groupAdapter.notifyDataSetChanged()
        })
        groupInfoVM.observerGroupLeft().observe(this, Observer {
            if (it) {
                finish()
            }
        })
        groupInfoVM.observerUserRemoved().observe(this, Observer {
            if (it) {
                groupMemberList.removeAt(optionSelectPosition)
                groupAdapter.notifyDataSetChanged()
            }
        })
        mediaUploadVM.observeMediaUpload().observe(this, Observer {
            updateGroup(it[0].mediaPath)
        })

        // fetching group info
        fetchGroupData()

        observeError()
    }

    private fun updateGroup(groupImageUrl: String? = null) {
        groupUpdateData = ChatHeadInfo(
            "",
            edt_name.text.toString(),
            null,
            "group",
            groupId
        )
        val bodyMap: HashMap<String, Any> = hashMapOf(
            "groupId" to groupId,
            "groupName" to edt_name.text.toString(),
            "summary" to edt_description.text.toString(),
            "isMute" to isMute
        )

        if (groupImageUrl != null) {
            bodyMap["imageURL"] = groupImageUrl

            groupUpdateData!!.chatProfile = groupImageUrl.mediaFullUrl()
        }

        groupInfoVM.updateGroupInfo(bodyMap)
    }

    private fun fetchGroupData(showLoading: Boolean = true) {
        val bodyMap: HashMap<String, Any> = hashMapOf(
            "groupId" to groupId
        )
        groupInfoVM.fetchGroupInfo(bodyMap, showLoading)
    }

    private fun fetchGroupPeople(showLoading: Boolean = false) {
        val bodyMap: HashMap<String, Any> = hashMapOf(
            "groupId" to groupId,
            "searchKey" to searchText,
            "pageSize" to Constants.globalPageSize,
            "pageIndex" to pageNo
        )
        groupInfoVM.fetchGroupPeopleList(bodyMap, showLoading)
    }

    private fun bindGroupData() {
        if (isMember) {
            edit_group.visibility = View.GONE
            read_group.visibility = View.VISIBLE

            txt_group_name.text = groupInfoData.groupName
            txt_group_summary.text = groupInfoData.groupSummary ?: ""
            txt_add_participant.text = getString(R.string.leave_group)
            txt_add_participant.setTextColor(ContextCompat.getColor(this, R.color.red))
        } else {
            edit_group.visibility = View.VISIBLE
            read_group.visibility = View.GONE

            edt_name.setText(groupInfoData.groupName)
            edt_description.setText(groupInfoData.groupSummary ?: "")
            txt_add_participant.text = getString(R.string.add_more_participant)
        }
        isMute = groupInfoData.isMute == 1
        cb_mute.isChecked = isMute

        Glide.with(this).load(groupInfoData.groupImageURL)
            .placeholder(R.drawable.profile_placeholder).into(img_group_profile)
        val participantDetail =
            groupInfoData.membersCount.toString() + " " + getString(R.string.participants)
        txt_participant.text = participantDetail
    }

    private fun observeError() {
        groupInfoVM.observeError().observe(this, Observer {
            processError(it)
        })
        mediaUploadVM.observeError().observe(this, Observer {
            processError(it)
        })
    }

    private fun processError(it: ResponseStatus?) {
        when (it) {
            ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                showToast("Internet not available")
            }
            ResponseStatus.AUTH_ERROR -> {
                showToast("Auth Error")
            }
            ResponseStatus.SERVER_ERROR -> {
                showToast("Server Error")
            }
            else -> {
            }
        }
    }

    override fun setInitialLanguage() {
        txt_group_info.text = getString(R.string.group_info)
        txt_max_char_.text = getString(R.string.max_180_char)
        txt_save.text = getString(R.string.save)
        txt_name.text = getString(R.string.group_name)
        txt_description.text = getString(R.string.summary)
        edt_name.hint = getString(R.string.enter_your_group_)
        edt_description.hint = getString(R.string.describe_your_group_)
        edt_search.hint = getString(R.string.search_participants)
        txt_mute_notification.text = getString(R.string.mute_notification)
        txt_group_image.text = getString(R.string.group_image)
        txt_change.text = getString(R.string.change)
    }

    override fun bindData() {
        groupAdapter = GroupAdapter(groupMemberList, this)
        rl_participant.layoutManager = LinearLayoutManager(this)
        rl_participant.adapter = groupAdapter
        groupAdapter.notifyDataSetChanged()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            UCrop.of(
                File(capturedPhotoPath).toUri(),
                Uri.parse(Constants.createNewFilePath(this, "jpg"))
            )
                .withAspectRatio(1f, 1f).start(this)
        } else if (requestCode == UCrop.REQUEST_CROP) {
            if (resultCode == RESULT_OK) {
                val resultUri = UCrop.getOutput(data!!)
                if (resultUri != null) {
                    groupImagePath = resultUri.path
                    Glide.with(this).load(resultUri).into(img_group_profile)
                }
            }
        } else if (requestCode == PictureConfig.REQUEST_GALLERY_IMAGE_FOR_POST && resultCode == RESULT_OK) {
            gallerySelectedImage = PictureSelector.obtainMultipleResult(data)[0]
            if (gallerySelectedImage != null) {
                val file = File(gallerySelectedImage!!.cutPath)
                UCrop.of(file.toUri(), Uri.parse(Constants.createNewFilePath(this, "jpg")))
                    .withAspectRatio(1f, 1f).start(this)
            }
        } else if (requestCode == ADD_PARTICIPANT_CODE) {
            // updating member list
            pageNo = 0
            isRefresh = true
            fetchGroupPeople(showLoading = false)
        }
    }

    private fun openMediaBottomSheet() {
        val view = LayoutInflater.from(this).inflate(R.layout.select_media_dialog, null)
        val dialog = BottomSheetDialog(this, R.style.SheetDialog)
        view.txt_select_media_.text = getString(R.string.select_media_)
        view.txt_camera.text = getString(R.string.camera)
        view.txt_gallery.text = getString(R.string.gallery)
        view.txt_take_a_.text = getString(R.string.take_a_)
        dialog.setContentView(view)

        view.card_camera.setOnClickListener {
            dialog.dismiss()
            if (Constants.isPermissionGranted(this, REQUIRED_PERMISSIONS)) {
                dispatchTakePictureIntent()
            } else {
                ActivityCompat.requestPermissions(
                    this,
                    REQUIRED_PERMISSIONS,
                    REQUEST_CODE_PERMISSIONS
                )
            }
        }
        view.card_gallery.setOnClickListener {
            dialog.dismiss()

            // opening InsGallery
            MyPreferences.saveIntInPreference(this, "maxSelect", 1)

            InsGallery.openGalleryForImages(
                this, GlideEngine.createGlideEngine(),
                GlideCacheEngine.createCacheEngine(), ArrayList<LocalMedia>(),
                PictureConfig.REQUEST_GALLERY_IMAGE_FOR_POST
            )
        }

        dialog.show()
    }

    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            // Ensure that there's a camera activity to handle the intent
            takePictureIntent.resolveActivity(packageManager)?.also {
                // Create the File where the photo should go
                val photoFile = createImageFile()
                // Continue only if the File was successfully created
                if (photoFile == null) {
                    showToast()
                } else {
                    photoFile.also {
                        val photoURI: Uri = FileProvider.getUriForFile(
                            this,
                            "com.example.android.fileprovider",
                            it
                        )
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                        startActivityForResult(takePictureIntent, CAMERA_REQUEST)
                    }
                }
            }
        }
    }

    private fun createImageFile(): File? {
        // Create an image file name
        return try {
            val timeStamp: String =
                SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
            File.createTempFile(
                "JPEG_${timeStamp}_", /* prefix */
                ".jpg", /* suffix */
                storageDir /* directory */
            ).apply {
                // Save a file: path for use with ACTION_VIEW intents
                capturedPhotoPath = absolutePath
            }
        } catch (e: Exception) {
            null
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (Constants.isPermissionGranted(this, REQUIRED_PERMISSIONS)) {
                dispatchTakePictureIntent()
            } else {
                Toast.makeText(this, "Permissions not granted by the user.", Toast.LENGTH_SHORT)
                    .show()
                finish()
            }
        }
    }
}