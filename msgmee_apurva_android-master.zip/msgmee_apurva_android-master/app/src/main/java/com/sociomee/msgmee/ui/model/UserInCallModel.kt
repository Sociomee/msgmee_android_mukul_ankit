package com.sociomee.msgmee.ui.model

import com.google.gson.annotations.SerializedName

data class UserInCallModel(
    @SerializedName("callDuration")
    val callDuration: Int,
    @SerializedName("callState")
    var callState: String,
    @SerializedName("fullname")
    val fullName: String,
    @SerializedName("memberId")
    val memberId: String,
    @SerializedName("profileImageThumb")
    val profileImageThumb: String?,
    @SerializedName("startTime")
    val startTime: String,
    @SerializedName("userName")
    val userName: String,
    @SerializedName("sequenceNo")
    val uid: Int = 0
)