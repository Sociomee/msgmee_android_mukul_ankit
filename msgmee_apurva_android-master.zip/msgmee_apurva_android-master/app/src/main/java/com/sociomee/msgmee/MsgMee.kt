package com.sociomee.msgmee

import android.Manifest
import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.LocationManager
import android.os.Bundle
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.exoplayer2.database.ExoDatabaseProvider
import com.google.android.exoplayer2.upstream.cache.CacheEvictor
import com.google.android.exoplayer2.upstream.cache.LeastRecentlyUsedCacheEvictor
import com.google.android.exoplayer2.upstream.cache.SimpleCache
import com.sociomee.msgmee.global.model.SavedLocationModel
import com.sociomee.msgmee.global.repo.PublicIpRepo
import com.sociomee.msgmee.notification.MyNotificationBuilder
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.MyPreferences
import com.sociomee.msgmee.utils.MySocketEvents
import io.socket.client.IO
import io.socket.client.Socket
import java.util.*

class MsgMee : Application(), Application.ActivityLifecycleCallbacks {

    private var activityReferences = 0
    private var isActivityChangingConfigurations = false

    companion object {
        var simpleCache: SimpleCache? = null
        var isInternetAvailable = true
        private var socket: Socket? = null

        fun initializeSocketAndListenEvents() {
            val options = IO.Options()
            options.auth = hashMapOf(
                "token" to Constants.userInfo!!.token
            )
            socket = IO.socket(MyRetrofit.socketUrl, options)

            // listening socket events
            socket!!.on(MySocketEvents.EVENT_CONNECT, MySocketEvents.onConnect)
            socket!!.on(MySocketEvents.EVENT_DISCONNECT, MySocketEvents.onDisconnect)
            socket!!.on(MySocketEvents.EVENT_CONNECT_ERROR, MySocketEvents.onConnectError)
            socket!!.on(MySocketEvents.EVENT_CONNECT_TIMEOUT, MySocketEvents.onConnectTimeout)
            socket!!.on(MySocketEvents.EVENT_RECONNECT, MySocketEvents.onReconnect)
            socket!!.on(MySocketEvents.EVENT_RECONNECT_ATTEMPT, MySocketEvents.onReconnectAttempt)
            socket!!.on(MySocketEvents.EVENT_RECONNECTING, MySocketEvents.onReconnecting)
            socket!!.on(MySocketEvents.EVENT_RECONNECT_ERROR, MySocketEvents.onReconnectError)
            socket!!.on(MySocketEvents.EVENT_RECONNECT_FAILED, MySocketEvents.onReconnectFailed)
            socket!!.on(MySocketEvents.EVENT_RECONNECT_FAILED, MySocketEvents.onReconnectFailed)
            socket!!.on(MySocketEvents.EVENT_SERVER_TIME, MySocketEvents.serverTime)
            socket!!.on(MySocketEvents.EVENT_USER_ONLINE, MySocketEvents.userOnline)
            socket!!.on(MySocketEvents.EVENT_USER_OFFLINE, MySocketEvents.userOffline)
            socket!!.on(MySocketEvents.EVENT_NEW_MESSAGE, MySocketEvents.newMessage)

            socket!!.io().timeout(MySocketEvents.socketTimeout)

            // finally connecting socket
            socket!!.connect()
        }

        fun getSocket() = socket!!
    }

    override fun onCreate() {
        super.onCreate()

        // creating notification channel
        MyNotificationBuilder.createNotificationChannel(this)

        // initializing socket if user is logged in
        if (MyPreferences.isUserLoggedIn(this))
            initializeSocketAndListenEvents()

        // registering activities callback for checking app foreground or background
        registerActivityLifecycleCallbacks(this)

        val leastRecentlyUsedCacheEvictor = LeastRecentlyUsedCacheEvictor(94371840L)

        if (simpleCache == null) {
            simpleCache = SimpleCache(
                this.cacheDir,
                leastRecentlyUsedCacheEvictor as CacheEvictor,
                ExoDatabaseProvider(this as Context)
            )
        }

        checkAndUpdateLocation()
    }

    private fun checkAndUpdateLocation() {
        val result = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (result == PackageManager.PERMISSION_GRANTED) {
            getLocation()
        } else {
            PublicIpRepo.fetchLocationFromPublicIp(this)
        }
    }

    private fun getLocation() {
        val locationManager = this.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
        } else {
            val lastKnownLocationGPS = locationManager.getLastKnownLocation(
                LocationManager.GPS_PROVIDER
            )
            lastKnownLocationGPS?.let {
                it.latitude
                it.longitude
            }
                ?: if (locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER) != null) {
                    val location = locationManager.getLastKnownLocation(
                        LocationManager.PASSIVE_PROVIDER
                    )
                    savedInputLocation(location!!.latitude, location.longitude)
                } else {
                    PublicIpRepo.fetchLocationFromPublicIp(this)
                }
        }
    }

    private fun savedInputLocation(lat: Double, lng: Double) {
        val geocoder = Geocoder(this, Locale.getDefault())
        val addresses = geocoder.getFromLocation(lat, lng, 1)

        val city: String = addresses[0].locality
        val state: String = addresses[0].adminArea
        val country: String = addresses[0].countryName

        val savedLocationModel = SavedLocationModel(lat, lng, country, state, city)
        Constants.saveLocation(this, savedLocationModel)
    }

    override fun onActivityStarted(p0: Activity) {
        if (++activityReferences == 1 && !isActivityChangingConfigurations) {
            // App enters foreground
            Log.v("harsh", "Application == foreground")

            // emitting user goes online
            if (socket != null && socket!!.connected()) {
                socket!!.emit(MySocketEvents.EVENT_ONLINE)
            }
        }
    }

    override fun onActivityStopped(p0: Activity) {
        isActivityChangingConfigurations = p0.isChangingConfigurations
        if (--activityReferences == 0 && !isActivityChangingConfigurations) {
            // App enters background
            Log.v("harsh", "Application == background $activityReferences")

            // emitting user goes offline
            if (socket != null && socket!!.connected()) {
                socket!!.emit(MySocketEvents.EVENT_OFFLINE)
            }
        }
    }

    override fun onActivityCreated(p0: Activity, p1: Bundle?) {}
    override fun onActivityResumed(p0: Activity) {}
    override fun onActivityPaused(p0: Activity) {}
    override fun onActivitySaveInstanceState(p0: Activity, p1: Bundle) {}
    override fun onActivityDestroyed(p0: Activity) {}
}