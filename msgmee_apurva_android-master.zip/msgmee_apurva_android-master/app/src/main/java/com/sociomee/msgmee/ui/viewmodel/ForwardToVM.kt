package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.model.ForwardToModel
import com.sociomee.msgmee.ui.repo.ForwardToRepo

class ForwardToVM : MyViewModel() {

    var forwardToList = MutableLiveData<ArrayList<ForwardToModel.Data.SuccessResult.Row>>()
    lateinit var forwardToRepo: ForwardToRepo

    // returning LiveData
    fun observeForwardToList() = forwardToList

    fun fetchForwardToList(body: HashMap<String, Any>) {
        if (!this::forwardToRepo.isInitialized) {
            forwardToRepo = ForwardToRepo()
        }
        isLoading.value = true
        forwardToRepo.fetchForwardToList(body).observeForever{
            if(it.status == ResponseStatus.SUCCESS) {
                forwardToList.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }
}