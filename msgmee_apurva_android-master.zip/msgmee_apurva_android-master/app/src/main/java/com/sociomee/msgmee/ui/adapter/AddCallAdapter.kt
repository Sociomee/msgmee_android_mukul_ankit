package com.sociomee.msgmee.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomIconView
import com.sociomee.msgmee.custom.widget.CustomImageView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.model.FriendModel

class AddCallAdapter(private val friendList : ArrayList<FriendModel>, private val clickEvent: (index: Int) -> Unit) : RecyclerView.Adapter<AddCallAdapter.AddCallHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = AddCallHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.add_call_child, parent, false)
    )

    override fun getItemCount() = friendList.size

    override fun onBindViewHolder(holder: AddCallHolder, position: Int) {
        val model = friendList[position]

        holder.txt_full_name.text = model.fullName
        holder.txt_username.text = model.userName

        Glide.with(holder.itemView.context).load(model.profileImageThumb).placeholder(R.drawable.profile_placeholder).into(holder.img_profile)

        if(model.isInCall) {
            holder.img_call.alpha = 0.4f
            holder.img_call.setOnClickListener {}
        } else {
            holder.img_call.alpha = 1f
            holder.img_call.setOnClickListener {
                clickEvent(position)
            }
        }
    }

    class AddCallHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val img_profile = itemView.findViewById<CustomImageView>(R.id.img_profile)
        val img_call = itemView.findViewById<CustomIconView>(R.id.img_call)
        val txt_full_name = itemView.findViewById<CustomTextView>(R.id.txt_full_name)
        val txt_username = itemView.findViewById<CustomTextView>(R.id.txt_username)
    }

}