package com.sociomee.msgmee.ui.`interface`

interface LanguageSelectCallback {

    fun languageSelectCallback(index : Int)

}