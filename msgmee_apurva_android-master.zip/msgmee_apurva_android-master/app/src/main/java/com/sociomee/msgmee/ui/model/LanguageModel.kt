package com.sociomee.msgmee.ui.model

import com.google.gson.annotations.SerializedName

data class LanguageModel(
        @SerializedName("data")
        val languageData: LanguageData,
        @SerializedName("error")
        val error: Boolean,
        @SerializedName("success")
        val success: Boolean
)

data class LanguageData(
        @SerializedName("successResult")
        val successResult: SuccessResult
)

data class SuccessResult(
        @SerializedName("count")
        val count: Int,
        @SerializedName("rows")
        val languageList: List<LanguageList>
)

data class LanguageList(
        @SerializedName("code")
        val code: String,
        @SerializedName("iconURL")
        val iconURL: String,
        @SerializedName("id")
        val id: String,
        @SerializedName("name")
        val name: String,
        var isSelected:Boolean=false
)
