package com.sociomee.msgmee.ui.`interface`


import com.sociomee.msgmee.ui.data.CreateAccountModel

import retrofit2.http.Body
import com.sociomee.msgmee.retrofit.MyCall
import com.sociomee.msgmee.ui.data.CountryListModel
import com.sociomee.msgmee.ui.data.InterestModel
import com.sociomee.msgmee.ui.model.LanguageModel
import com.sociomee.msgmee.ui.model.MessageResponse
import com.sociomee.msgmee.ui.model.UserDataModel
import retrofit2.http.POST

interface LoginApiCall {

    @POST("/public/getAllAppLanguages")
    fun getLanguageList(): MyCall<LanguageModel>

    @POST("/public/userEmailAvailable")
    fun checkEmailAvailability(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/public/userMobileAvailable")
    fun checkMobileAvailability(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/public/sendOtp")
    fun sendOtpEmail(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/public/login")
    fun loginUser(@Body body: HashMap<String, Any>): MyCall<UserDataModel>

    @POST("/public/verifyOtp")
    fun verifyOtp(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/public/registerUser")
    fun createAccount(@Body body: HashMap<String, Any>): MyCall<CreateAccountModel>

    @POST("/public/resetPassword")
    fun resetPassword(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/user/update")
    fun userUpdate(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("admin/getAllInterests")
    fun getInterestList(): MyCall<InterestModel>

    @POST("/user/addInterests")
    fun addInterestToUser(@Body body: HashMap<String, Any>): MyCall<MessageResponse>

    @POST("/public/getAllCountry")
    fun getCountryList(): MyCall<CountryListModel>
}