package com.sociomee.msgmee.ui.data


import com.google.gson.annotations.SerializedName

data class InterestModel(
        @SerializedName("data")
        val interestData: InterestData,
        @SerializedName("error")
        val error: Boolean,
        @SerializedName("success")
        val success: Boolean
) {
    data class InterestData(
            @SerializedName("successResult")
            val successResult: SuccessResult
    )

    data class SuccessResult(
            @SerializedName("count")
            val count: Int,
            @SerializedName("rows")
            val interestList: List<InterestList>
    )

    data class InterestList(
            @SerializedName("id")
            val id: String,
            @SerializedName("name")
            val name: String,
            var isSelected: Boolean = false
    )
}