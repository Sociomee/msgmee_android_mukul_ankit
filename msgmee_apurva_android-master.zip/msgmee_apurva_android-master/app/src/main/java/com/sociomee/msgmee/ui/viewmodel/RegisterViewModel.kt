package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.repo.RegisterRepo

open class RegisterViewModel : MyViewModel() {

    private var loginIdAvailable = MutableLiveData<Boolean>()
    private var otpSent = MutableLiveData<Boolean>()
    lateinit var registerRepo: RegisterRepo

    // returning LiveData
    fun observeLoginIdAvailability() = loginIdAvailable
    fun observeOtpSent() = otpSent

    fun checkEmailAvailability(body: HashMap<String, Any>, isForgot: Boolean = false) {
        if(!this::registerRepo.isInitialized) {
            registerRepo = RegisterRepo()
        }
        isLoading.value = true
        registerRepo.checkEmailAvailability(body).observeForever{
            if(it.status == ResponseStatus.SUCCESS) {
                loginIdAvailable.value = it.data!!

                if(isForgot) {
                    if(it.data) {
                        isLoading.value = false
                    }
                } else {
                    if(!it.data) {
                        isLoading.value = false
                    }
                }
            } else {
                isLoading.value = false
                errorListener.value = it.status
            }
        }
    }

    fun checkMobileAvailability(body: HashMap<String, Any>, isForgot: Boolean = false) {
        if(!this::registerRepo.isInitialized) {
            registerRepo = RegisterRepo()
        }
        isLoading.value = true
        registerRepo.checkMobileAvailability(body).observeForever{
            if(it.status == ResponseStatus.SUCCESS) {
                loginIdAvailable.value = it.data!!

                if(isForgot) {
                    if(it.data) {
                        isLoading.value = false
                    }
                } else {
                    if(!it.data) {
                        isLoading.value = false
                    }
                }
            } else {
                isLoading.value = false
                errorListener.value = it.status
            }
        }
    }

    fun sendOtp(body: HashMap<String, Any>) {
        if(!this::registerRepo.isInitialized) {
            registerRepo = RegisterRepo()
        }
        isLoading.value = true
        registerRepo.sendOtpEmail(body).observeForever{
            if(it.status == ResponseStatus.SUCCESS) {
                otpSent.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }
}