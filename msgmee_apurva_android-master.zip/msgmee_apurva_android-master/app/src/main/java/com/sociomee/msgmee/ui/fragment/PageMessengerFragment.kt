package com.sociomee.msgmee.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.`interface`.SingleItemCallback
import com.sociomee.msgmee.ui.adapter.PageMessageListAdapter
import com.sociomee.msgmee.ui.adapter.PageMessengerListAdapter
import kotlinx.android.synthetic.main.page_messenger_fragment.*

class PageMessengerFragment : Fragment(R.layout.page_messenger_fragment), SingleItemCallback {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setInitialLanguage()
        bindData()
        setViewClicks()
    }

    private fun bindData() {
        val adapter = PageMessengerListAdapter()
        rl_market_list.layoutManager = LinearLayoutManager(context, RecyclerView.HORIZONTAL, false)
        rl_market_list.adapter = adapter

        val messageAdapter = PageMessageListAdapter(this)
        rl_market_message.layoutManager = LinearLayoutManager(context)
        rl_market_message.adapter = messageAdapter
    }

    private fun setViewClicks() {
    }

    private fun setInitialLanguage() {

    }

    override fun itemInteracted(position: Int) {
        val bottomSheetDialog = BottomSheetDialog(context!!, R.style.SheetDialog)
        val view = LayoutInflater.from(context).inflate(R.layout.profile_options_bs, null)
        bottomSheetDialog.setContentView(view)

        val txt_menu_1 = view.findViewById<CustomTextView>(R.id.txt_menu_1)
        val txt_menu_2 = view.findViewById<CustomTextView>(R.id.txt_menu_2)
        val txt_menu_3 = view.findViewById<CustomTextView>(R.id.txt_menu_3)
        val txt_menu_4 = view.findViewById<CustomTextView>(R.id.txt_menu_4)
        val txt_menu_5 = view.findViewById<CustomTextView>(R.id.txt_menu_5)

        txt_menu_1.text = context!!.getString(R.string.mark_as_unread)
        txt_menu_2.text = context!!.getString(R.string.add_to_archive)
        txt_menu_3.text = context!!.getString(R.string.pin_chat)
        txt_menu_4.text = context!!.getString(R.string.mute)
        txt_menu_5.text = context!!.getString(R.string.delete_chat)

        bottomSheetDialog.show()
    }
}