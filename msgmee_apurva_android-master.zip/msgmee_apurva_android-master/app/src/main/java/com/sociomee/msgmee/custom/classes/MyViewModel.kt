package com.sociomee.msgmee.custom.classes

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

open class MyViewModel : ViewModel() {

    var isLoading = MutableLiveData<Boolean>()
    var errorListener = MutableLiveData<ResponseStatus>()

    fun observeLoading() = isLoading
    fun observeError() = errorListener

}