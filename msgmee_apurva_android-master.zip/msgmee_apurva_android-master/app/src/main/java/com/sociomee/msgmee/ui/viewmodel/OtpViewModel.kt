package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.repo.OtpRepo

class OtpViewModel : RegisterViewModel() {

    private val otpVerified = MutableLiveData<Boolean>()
    private lateinit var otpRepo: OtpRepo

    // returning LiveData
    fun observeOtpVerification() = otpVerified

    fun verifyOtp(body: HashMap<String, Any>) {
        if(!this::otpRepo.isInitialized) {
            otpRepo = OtpRepo()
        }
        isLoading.value = true
        otpRepo.verifyOtp(body).observeForever{
            if(it.status == ResponseStatus.SUCCESS) {
                otpVerified.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }
}