package com.sociomee.msgmee.ui.model

data class GroupCreateMemberModel (val memberId: String, val memberName: String)