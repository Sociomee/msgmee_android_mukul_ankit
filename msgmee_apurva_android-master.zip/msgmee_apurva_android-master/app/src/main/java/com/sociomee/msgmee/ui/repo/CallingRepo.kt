package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.ApiCall
import com.sociomee.msgmee.ui.model.MessageResponse
import retrofit2.Response

class CallingRepo {

    fun initiateCall(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.initiateCall(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                data.postValue(MyResponse.success(response.body()!!.success))
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

        })
        return data
    }

    fun addUserInCall(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.addUserInCall(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                data.postValue(MyResponse.success(response.body()!!.success))
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

        })
        return data
    }

    fun updateCallState(body: HashMap<String, Any>, type: String = "update"): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = when (type) {
            "accept" -> {
                retrofitService.acceptCall(body)
            }
            "decline" -> {
                retrofitService.declineCall(body)
            }
            else -> {
                retrofitService.updateCallState(body)
            }
        }

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                data.postValue(MyResponse.success(response.body()!!.success))
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

        })
        return data
    }

    fun removeUserFromCall(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.removeUserFromCall(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                data.postValue(MyResponse.success(response.body()!!.success))
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

        })
        return data
    }

    fun addMissedCall(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.addMissedCall(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                data.postValue(MyResponse.success(response.body()!!.success))
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

        })
        return data
    }

}