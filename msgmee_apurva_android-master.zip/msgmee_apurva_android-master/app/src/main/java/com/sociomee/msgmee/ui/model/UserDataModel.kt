package com.sociomee.msgmee.ui.model


import com.google.gson.annotations.SerializedName

data class UserDataModel(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("successResult")
        val userInfoModel: UserInfoModel,
        @SerializedName("errorResult")
        val errorResult: String
    )
}
data class UserInfoModel(
        @SerializedName("addressBy")
        val addressBy: Any,
        @SerializedName("bio")
        val bio: Any,
        @SerializedName("blockedByAdmin")
        val blockedByAdmin: Int,
        @SerializedName("countryId")
        val countryId: Any,
        @SerializedName("coverImage")
        val coverImage: String,
        @SerializedName("createdAt")
        val createdAt: String,
        @SerializedName("deletedAt")
        val deletedAt: Any,
        @SerializedName("dob")
        val dob: Any,
        @SerializedName("email")
        val email: String,
        @SerializedName("fullName")
        val fullName: String,
        @SerializedName("gender")
        val gender: String,
        @SerializedName("id")
        val id: String,
        @SerializedName("isActive")
        val isActive: Int,
        @SerializedName("isDeleted")
        val isDeleted: Int,
        @SerializedName("languagId")
        val languagId: Any,
        @SerializedName("loginMode")
        val loginMode: String,
        @SerializedName("mobile")
        val mobile: String,
        @SerializedName("professionId")
        val professionId: Any,
        @SerializedName("profileImage")
        val profileImage: String?,
        @SerializedName("profileImageThumb")
        val profileImageThumb: String?,
        @SerializedName("thumbnailURL")
        val thumbnailURL: Any,
        @SerializedName("token")
        val token: String,
        @SerializedName("updatedAt")
        val updatedAt: String,
        @SerializedName("userName")
        val username: String,
        @SerializedName("sequenceNo")
        val userSequenceNo: Int
)