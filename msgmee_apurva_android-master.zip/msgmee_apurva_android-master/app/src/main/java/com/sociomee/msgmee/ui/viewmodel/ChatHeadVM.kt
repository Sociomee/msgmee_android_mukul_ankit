package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.model.ChatHeadModel
import com.sociomee.msgmee.ui.model.DataChangeModel
import com.sociomee.msgmee.ui.repo.ChatHeadRepo

class ChatHeadVM : MyViewModel() {

    private var chatHeadList = MutableLiveData<ChatHeadModel.Data.SuccessResult>()
    private var chatHeadPinChange = MutableLiveData<DataChangeModel>()
    private var chatHeadMuteChange = MutableLiveData<DataChangeModel>()
    private var chatHeadDelete = MutableLiveData<Boolean>()
    private var chatArchiveChange = MutableLiveData<Boolean>()
    private lateinit var chatHeadRepo: ChatHeadRepo

    // returning LiveData
    fun observeChatHeadList() = chatHeadList
    fun observeChatHeadPin() = chatHeadPinChange
    fun observeChatHeadMute() = chatHeadMuteChange
    fun observeChatHeadDelete() = chatHeadDelete
    fun observeChatArchive() = chatArchiveChange

    fun fetchChatHeadList(
        body: HashMap<String, Any>,
        showArchive: Boolean = false,
        isRefresh: Boolean = false
    ) {
        if (!this::chatHeadRepo.isInitialized) {
            chatHeadRepo = ChatHeadRepo()
        }
        chatHeadRepo.fetchChatHeadList(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                it.data!!.isRefresh = isRefresh
                it.data.showArchive = showArchive
                chatHeadList.value = it.data
            } else {
                errorListener.value = it.status
            }
        }
    }

    fun changeChatArchive(body: HashMap<String, Any>) {
        if (!this::chatHeadRepo.isInitialized) {
            chatHeadRepo = ChatHeadRepo()
        }
        chatHeadRepo.changeChatArchive(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                chatArchiveChange.value = it.data!!
            } else {
                errorListener.value = it.status
            }
        }
    }

    fun changeChatHeadPin(body: HashMap<String, Any>, position: Int) {
        if (!this::chatHeadRepo.isInitialized) {
            chatHeadRepo = ChatHeadRepo()
        }
        chatHeadRepo.changeChatHeadPin(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                chatHeadPinChange.value = DataChangeModel(position, it.data!!)
            } else {
                errorListener.value = it.status
            }
        }
    }

    fun changeChatHeadMute(body: HashMap<String, Any>, position: Int) {
        if (!this::chatHeadRepo.isInitialized) {
            chatHeadRepo = ChatHeadRepo()
        }
        chatHeadRepo.changeChatHeadMute(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                chatHeadMuteChange.value = DataChangeModel(position, it.data!!)
            } else {
                errorListener.value = it.status
            }
        }
    }

    fun deleteChatHeads(body: HashMap<String, Any>) {
        if (!this::chatHeadRepo.isInitialized) {
            chatHeadRepo = ChatHeadRepo()
        }
        chatHeadRepo.deleteChatHeads(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                chatHeadDelete.value = it.data
            } else {
                errorListener.value = it.status
            }
        }
    }
}