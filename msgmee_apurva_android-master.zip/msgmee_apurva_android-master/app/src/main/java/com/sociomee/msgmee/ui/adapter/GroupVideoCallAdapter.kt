package com.sociomee.msgmee.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomImageView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.model.UserInCallModel
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.callStatus
import com.sociomee.msgmee.utils.physicalScreenRectPx
import io.agora.rtc.RtcEngine
import io.agora.rtc.video.VideoCanvas

class GroupVideoCallAdapter() :
    RecyclerView.Adapter<GroupVideoCallAdapter.GroupVideoCallHolder>() {

    private lateinit var userList: ArrayList<UserInCallModel>
    private var screenFullWidth: Int = 0
    private var screenFullHeight: Int = 0
    private lateinit var rtcEngine: RtcEngine

    constructor(context: Context, userList: ArrayList<UserInCallModel>, rtcEngine: RtcEngine): this() {
        this.userList = userList
        this.rtcEngine = rtcEngine
        screenFullWidth = context.physicalScreenRectPx.width()
        screenFullHeight = context.physicalScreenRectPx.height()
    }

    override fun onCreateViewHolder (parent: ViewGroup, viewType: Int): GroupVideoCallHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.group_video_call_child, parent, false)
        val params = view.layoutParams
        params.width = if (viewType == 0) {
            (screenFullWidth / 2)
        } else {
            screenFullWidth
        }
        params.height =
            (screenFullHeight / ((userList.size / 2) + (userList.size % 2)))
        view.layoutParams = params
        return GroupVideoCallHolder(view)
    }

    override fun getItemViewType(position: Int): Int {
        return if (position == (userList.size - 1) && (position + 1) % 2 == 1) 1 else 0
    }

    override fun onBindViewHolder(holder: GroupVideoCallHolder, position: Int) {
        val data = userList[position]
        if(data.memberId == Constants.userInfo!!.id) { // means local video
            // Enable the video module.
            rtcEngine.enableVideo()

            // Create a SurfaceView object.
            val surfaceView = RtcEngine.CreateRendererView(holder.itemView.context)
            surfaceView.setZOrderMediaOverlay(true)
            holder.fl_group_call.addView(surfaceView)
            rtcEngine.setupLocalVideo(VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_FIT, 0))

            holder.txt_group_call_state.visibility = View.GONE
            holder.img_group_call.visibility = View.GONE
        } else {
            if(data.callState == "inCall") {
                holder.txt_group_call_state.visibility = View.GONE
                holder.img_group_call.visibility = View.GONE

                // Create a SurfaceView object.
                val surfaceView = RtcEngine.CreateRendererView(holder.itemView.context)
                holder.fl_group_call.addView(surfaceView)

                // Set the remote video view.
                rtcEngine.setupRemoteVideo(VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_FIT, userList[position].uid))
            } else {
                holder.txt_group_call_state.visibility = View.VISIBLE
                holder.img_group_call.visibility = View.VISIBLE

                Glide.with(holder.itemView.context).load(data.profileImageThumb).placeholder(R.drawable.profile_placeholder).into(holder.img_group_call)
                val state = "${data.callState.callStatus()} ${data.userName}"
                holder.txt_group_call_state.text = state
            }
        }
    }

    override fun getItemCount() = userList.size

    class GroupVideoCallHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val fl_group_call = itemView.findViewById<FrameLayout>(R.id.fl_group_call)
        val txt_group_call_state = itemView.findViewById<CustomTextView>(R.id.txt_group_call_state)
        val img_group_call = itemView.findViewById<CustomImageView>(R.id.img_group_call)
    }
}