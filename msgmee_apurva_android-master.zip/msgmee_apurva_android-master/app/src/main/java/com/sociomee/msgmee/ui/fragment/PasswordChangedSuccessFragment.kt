package com.sociomee.msgmee.ui.fragment

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.sociomee.msgmee.R
import com.sociomee.msgmee.ui.activity.ForgotPasswordActivity
import com.sociomee.msgmee.ui.activity.LoginActivity
import kotlinx.android.synthetic.main.password_changed_success_fragment.*

class PasswordChangedSuccessFragment : Fragment(R.layout.password_changed_success_fragment) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setInitialLanguage()

        img_toolbar_back.setOnClickListener {
            (activity as ForgotPasswordActivity).onBackPressed()
        }

        btn_back_to_login.setOnClickListener {
            startActivity(Intent(context, LoginActivity::class.java))
            activity!!.finish()
        }
    }

    private fun setInitialLanguage() {
        btn_back_to_login.text = getString(R.string.back_to_login)
        txt_password_changed_.text = getString(R.string.password_changed_)
        txt_you_can_.text = getString(R.string.you_can_now_login_)
    }

}