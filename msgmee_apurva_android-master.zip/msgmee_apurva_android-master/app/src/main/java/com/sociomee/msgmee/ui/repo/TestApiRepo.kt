package com.sociomee.msgmee.ui.repo

import android.util.Log
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.ApiCall
import com.sociomee.msgmee.ui.model.MessageResponse
import retrofit2.Response

class TestApiRepo {

    companion object {
        fun hitTestApi(body: HashMap<String, Any>) {
            val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
            val call = retrofitService.testApi(body)
            call.enqueue(object : MyCallback<MessageResponse> {
                override fun success(response: Response<MessageResponse>) {
                    Log.v("harshNotification", "success")
                }

                override fun networkError() {
                    Log.v("harshNotification", "networkError")
                }

                override fun authError() {
                    Log.v("harshNotification", "authError")
                }

                override fun serverError() {
                    Log.v("harshNotification", "serverError")
                }
            })
        }
    }

}