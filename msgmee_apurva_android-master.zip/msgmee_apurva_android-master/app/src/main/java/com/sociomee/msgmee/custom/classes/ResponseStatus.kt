package com.sociomee.msgmee.custom.classes

enum class ResponseStatus {
    SUCCESS,
    INTERNET_NOT_AVAILABLE,
    AUTH_ERROR,
    SERVER_ERROR
}