package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData

import com.sociomee.msgmee.ui.data.InterestModel
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.LoginApiCall
import com.sociomee.msgmee.ui.model.MessageResponse
import retrofit2.Response

class InterestRepo {

    fun fetchInterestList() : MutableLiveData<MyResponse<List<InterestModel.InterestList>>>{
        val data = MutableLiveData<MyResponse<List<InterestModel.InterestList>>>()
        val retrofitService = MyRetrofit.getRetrofitService(LoginApiCall::class.java)
        val call = retrofitService.getInterestList()

        call.enqueue(object : MyCallback<InterestModel> {
            override fun success(response: Response<InterestModel>) {
              data.postValue(MyResponse.success(response.body()!!.interestData.successResult.interestList))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {

                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }

    fun addInterestToUser(body: HashMap<String, Any>) : MutableLiveData<MyResponse<Boolean>>{
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(LoginApiCall::class.java)
        val call = retrofitService.addInterestToUser(body)

        call.enqueue(object : MyCallback<MessageResponse>{
            override fun success(response: Response<MessageResponse>) {
                if(response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {

                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }
}