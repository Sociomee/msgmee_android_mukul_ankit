package com.sociomee.msgmee.ui.model
import com.google.gson.annotations.SerializedName

data class UserSpeakLanguageModel(
        @SerializedName("data")
    val userSpeakLanguageData: UserSpeakLanguageData,
        @SerializedName("error")
    val error: Boolean,
        @SerializedName("success")
    val success: Boolean
)
    data class UserSpeakLanguageData(
        @SerializedName("successResult")
        val userSpeakLanguageList: List<UserSpeakLanguageList>
    )
        data class UserSpeakLanguageList(
            @SerializedName("langId")
            val langId: String,
            @SerializedName("name")
            val name: String,
            var isSelected:Boolean=false
        )

