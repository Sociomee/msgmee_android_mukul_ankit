package com.sociomee.msgmee.ui.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class CallNotificationModel(
    @SerializedName("callRoomId")
    val callRoomId: String,
    @SerializedName("caller")
    val caller: Caller,
    @SerializedName("isVideo")
    val isVideo: Int,
    @SerializedName("membersCount")
    val membersCount: Int
): Parcelable {
    @Parcelize
    data class Caller(
        @SerializedName("userId")
        val userId: String,
        @SerializedName("userName")
        val userName: String,
        @SerializedName("profilePicture")
        val callerProfilePic: String?
    ) : Parcelable
}