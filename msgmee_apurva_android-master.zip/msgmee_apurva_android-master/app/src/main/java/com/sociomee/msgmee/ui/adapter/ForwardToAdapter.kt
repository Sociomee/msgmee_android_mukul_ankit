package com.sociomee.msgmee.ui.adapter

import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomImageView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.`interface`.ItemSelectCallback
import com.sociomee.msgmee.ui.model.ForwardToData

class ForwardToAdapter(
    private val forwardToList: ArrayList<ForwardToData>,
    private val itemSelectCallback: ItemSelectCallback
) :
    RecyclerView.Adapter<ForwardToAdapter.ForwardToHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ForwardToHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.group_people_child, parent, false)
    )

    override fun getItemCount() = forwardToList.size

    override fun onBindViewHolder(holder: ForwardToHolder, position: Int) {
        val model = forwardToList[position]

        if(model.type == "broadcast") {
            Glide.with(holder.itemView.context).load(R.drawable.ic_broadcast_background)
                .into(holder.img_messenger_profile)
        } else {
            Glide.with(holder.itemView.context).load(model.userImageThumb)
                .placeholder(R.drawable.profile_placeholder).into(holder.img_messenger_profile)
        }

        holder.cv_online_circle.visibility = View.GONE
        holder.cb_people_child.isChecked = model.isSelected
        Log.v("harshThread", "onBindViewHolder is main thread == ${Looper.myLooper() == Looper.getMainLooper()}")
        holder.txt_calls_name.text = model.userUserName

        // clicks
        holder.cb_people_child.setOnClickListener {
            forwardToList[position].isSelected = holder.cb_people_child.isChecked
            itemSelectCallback.itemSelectionChanged(position, model.userId, model.type, holder.cb_people_child.isChecked)
        }
    }

    class ForwardToHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txt_calls_name = itemView.findViewById<CustomTextView>(R.id.txt_calls_name)
        val cb_people_child = itemView.findViewById<CheckBox>(R.id.cb_people_child)
        val cv_online_circle = itemView.findViewById<CardView>(R.id.cv_online_circle)
        val img_messenger_profile =
            itemView.findViewById<CustomImageView>(R.id.img_messenger_profile)
    }
}