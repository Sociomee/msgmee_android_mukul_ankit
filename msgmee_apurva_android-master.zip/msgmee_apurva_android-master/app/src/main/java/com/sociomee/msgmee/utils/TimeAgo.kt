package com.sociomee.msgmee.utils

import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

class TimeAgo {

    companion object {
        fun getDateFormat(): SimpleDateFormat {
            val simpleDateFormat = SimpleDateFormat(
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                Locale.ENGLISH
            )
            val defaultTimeZone = TimeZone.getDefault()
            val strDefaultTimeZone = defaultTimeZone.getDisplayName(false, TimeZone.SHORT)
            simpleDateFormat.timeZone = TimeZone.getTimeZone(strDefaultTimeZone)
            return simpleDateFormat
        }
        private const val SECOND_MILLIS = 1000
        private const val MINUTE_MILLIS = 60 * SECOND_MILLIS
        private const val HOUR_MILLIS = 60 * MINUTE_MILLIS
        private const val DAY_MILLIS = 24 * HOUR_MILLIS

        fun getTimeAgo(timeInString: String) : String? {
            val lastMessageDate = getDateFormat().parse(timeInString) ?: return null
            val givenTime = lastMessageDate.time

            var time = givenTime
            if (time < 1000000000000L) {
                time *= 1000
            }

            val now: Long = System . currentTimeMillis ()
            if (time > now || time <= 0) {
                return null
            }


            val diff = now - time
            when {
                diff < MINUTE_MILLIS -> {
                    return "just now"
                }
                diff < 2 * MINUTE_MILLIS -> {
                    return "a minute ago"
                }
                diff < 50 * MINUTE_MILLIS -> {
                    return "${diff / MINUTE_MILLIS} minutes ago"
                }
                diff < 90 * MINUTE_MILLIS -> {
                    return "an hour ago"
                }
                diff < 24 * HOUR_MILLIS -> {
                    return "${diff / HOUR_MILLIS} hours ago"
                }
                diff < 48 * HOUR_MILLIS -> {
                    return "Yesterday"
                }
                else -> {
                    return "${diff / DAY_MILLIS} days ago"
                }
            }
        }

        fun getTimeDifference(givenTimeInString: String) : Long {
            val givenTimeParsed = getDateFormat().parse(givenTimeInString) ?: return 0L
            val givenTime = givenTimeParsed.time

            val currentTime = System.currentTimeMillis()
            val difference = abs(currentTime - givenTime)

            return if(difference > 0) {
                difference / 1000
            } else {
                0L
            }
        }
    }
}