package com.sociomee.msgmee.ui.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.`interface`.MultiSelectCallBack
import com.sociomee.msgmee.ui.activity.FriendListActivity
import com.sociomee.msgmee.ui.activity.MessengerActivity
import com.sociomee.msgmee.ui.adapter.ChatHeadAdapter
import com.sociomee.msgmee.ui.model.ChatHeadData
import com.sociomee.msgmee.ui.model.ChatHeadSearched
import com.sociomee.msgmee.ui.model.OnlineChangeModel
import com.sociomee.msgmee.ui.viewmodel.ChatHeadVM
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.ScrollListener
import com.sociomee.msgmee.utils.TimeAgo
import kotlinx.android.synthetic.main.chat_head_list_fragment.*
import kotlinx.android.synthetic.main.chat_head_list_fragment.txt_multi_select_count
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe

class ChatHeadListFragment
    : Fragment(R.layout.chat_head_list_fragment), MultiSelectCallBack {

    private val chatHeadList = ArrayList<ChatHeadData>()
    private lateinit var chatHeadAdapter: ChatHeadAdapter
    private lateinit var chatHeadVM: ChatHeadVM
    private var selectedMessageList = ArrayList<Int>()
    private var deletedMessageList = ArrayList<Int>()
    private var isMultiSelectOpen = false
    private var isLastPage = false
    private var isLoading = false
    private var multiSelectCount = 0
    private var pageIndex = 0

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setInitialLanguage()
        initData()
        observeData()
        setViewClicks()
    }

    private fun initData() {
        chatHeadVM = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            ChatHeadVM::class.java
        )
        chatHeadAdapter = ChatHeadAdapter(chatHeadList, this)
        val layoutManager = LinearLayoutManager(context)
        rl_message_list.layoutManager = layoutManager
        rl_message_list.adapter = chatHeadAdapter

        // changing view visibility for initial data
        group_multi_select_toolbar.visibility = View.GONE
        cl_empty.visibility = View.GONE
        rl_message_list.visibility = View.VISIBLE

        // adding scroll listener for pagination
        rl_message_list.addOnScrollListener(object : ScrollListener(layoutManager) {
            override fun isNewLastPage() = true
            override fun isOldLastPage() = isLastPage
            override fun isLoading() = isLoading
            override fun loadNewItems() {}

            override fun loadOldItems() {
                isLoading = true
                pageIndex++
                fetchChatHeadList(
                    showArchive = true,
                    isRefresh = false,
                    searchText = ""
                )
            }
        })
    }

    private fun observeData() {
        chatHeadVM.observeChatHeadList().observe(this, Observer {
            isLoading = false
            if (it.isRefresh) {
                chatHeadList.clear()
            }
            if(it.chatHeadList.isEmpty()) {
                isLastPage = true
            } else {
                isLastPage = false

                chatHeadList.addAll(it.chatHeadList)

                val newList = chatHeadList.sortedWith(
                    compareBy<ChatHeadData> { model -> model.isPinned == 0 }
                        .thenBy { model3 ->
                            model3.isArchived == 1
                        }
                        .thenByDescending { model2 ->
                            TimeAgo.getDateFormat().parse(model2.lastMessageDate)
                        }
                )
                chatHeadList.clear()
                chatHeadList.addAll(newList)

                if(it.showArchive) {
                    val archiveIndex = chatHeadList.indexOfFirst { model ->
                        model.isArchived == 1
                    }

                    if(archiveIndex != -1) {
                        chatHeadList.add(
                            archiveIndex, ChatHeadData.createArchiveHead()
                        )
                    }
                }

                updateChatHeadUI()
            }
        })
        chatHeadVM.observeLoading().observe(this, Observer {
            (activity as CustomAppCompatActivity).changeLoadingStatus(it)
        })
        chatHeadVM.observeChatHeadDelete().observe(this, Observer {
            for (pos in deletedMessageList) {
                chatHeadList.removeAt(pos)
            }
            chatHeadAdapter.notifyDataSetChanged()
            deletedMessageList.clear()
        })
        chatHeadVM.observeChatHeadMute().observe(this, Observer {
            chatHeadList[it.position].isMute = if (chatHeadList[it.position].isMute == 1) 0 else 1

            chatHeadAdapter.notifyDataSetChanged()
        })
        chatHeadVM.observeChatHeadPin().observe(this, Observer { pinChangeData ->
            chatHeadList[pinChangeData.position].isPinned =
                if (chatHeadList[pinChangeData.position].isPinned == 1) 0 else 1

            // sorting according to pinned chats and last message date
            val newList = chatHeadList.sortedWith(
                compareBy<ChatHeadData> { it.isPinned == 0 }
                    .thenBy {
                        it.isArchived == 1
                    }
                    .thenByDescending {
                        TimeAgo.getDateFormat().parse(it.lastMessageDate)
                    }
            )

            chatHeadList.clear()
            chatHeadList.addAll(newList)

            chatHeadAdapter.notifyDataSetChanged()
        })
        chatHeadVM.observeChatArchive().observe(this, Observer {
            refreshChatHead()
        })

        observeError()
    }

    private fun refreshChatHead() {
        pageIndex = 0
        fetchChatHeadList(showArchive = true)
    }

    private fun changePin(position: Int) {
        val bodyMap: HashMap<String, Any> = hashMapOf(
            "chatHeadId" to chatHeadList[position].chatHeadId,
            "isPinned" to (chatHeadList[position].isPinned != 1)
        )
        chatHeadVM.changeChatHeadPin(bodyMap, position)
    }

    private fun changeMute(position: Int) {
        val bodyMap: HashMap<String, Any> = hashMapOf(
            "chatHeadId" to chatHeadList[position].chatHeadId,
            "isMute" to (chatHeadList[position].isMute != 1)
        )
        chatHeadVM.changeChatHeadMute(bodyMap, position)
    }

    private fun fetchChatHeadList(showArchive: Boolean, isRefresh: Boolean = true, searchText: String = "") {
        if (isRefresh)
            pageIndex = 0
        val body: HashMap<String, Any> = hashMapOf(
            "searchKey" to searchText,
            "pageIndex" to pageIndex,
            "pageSize" to Constants.globalPageSize
        )
        chatHeadVM.fetchChatHeadList(
            body,
            showArchive = showArchive,
            isRefresh = isRefresh
        )
    }

    private fun observeError() {
        chatHeadVM.observeError().observe(this, Observer {
            when (it) {
                ResponseStatus.INTERNET_NOT_AVAILABLE -> {
                    (activity as CustomAppCompatActivity).showToast("Internet not available")
                }
                ResponseStatus.AUTH_ERROR -> {
                    (activity as CustomAppCompatActivity).showToast("Auth Error")
                }
                ResponseStatus.SERVER_ERROR -> {
                    (activity as CustomAppCompatActivity).showToast("Server Error")
                }
                else -> {
                }
            }
        })
    }

    private fun setViewClicks() {
        txt_add.setOnClickListener {
            val intent = Intent(context, FriendListActivity::class.java)
            intent.putExtra("type", Constants.PeopleSelectType.SINGLE)
            startActivity(intent)
        }
        img_multi_select_back.setOnClickListener {
            resetMultiSelect()
        }
        img_multi_select_pin.setOnClickListener {
            if (multiSelectCount > 3) {
                Toast.makeText(
                    requireContext(), getString(R.string.pin_limit_error),
                    Toast.LENGTH_LONG
                ).show()
            } else {
                changePin(selectedMessageList[0])
                chatHeadAdapter.clearMultiSelect()
            }
        }
        img_multi_select_mute.setOnClickListener {
            changeMute(selectedMessageList[0])
            chatHeadAdapter.clearMultiSelect()
        }
        img_multi_select_delete.setOnClickListener {
            val chatHeadIdList = ArrayList<String>()
            for (pos in selectedMessageList) {
                chatHeadIdList.add(chatHeadList[pos].chatHeadId)
                deletedMessageList.add(pos)
            }

            val bodyMap: HashMap<String, Any> = hashMapOf(
                "chatHeadIds" to chatHeadIdList
            )
            chatHeadVM.deleteChatHeads(bodyMap)
            resetMultiSelect()
        }
        img_multi_select_menu.setOnClickListener {
            showOptionBottomSheet()
        }
    }

    private fun showOptionBottomSheet() {
        var showArchive = true
        val chatHeadIdList = ArrayList<String>()
        if(chatHeadList[selectedMessageList[0]].isArchived == 1) {
            showArchive = false
        }
        for (pos in selectedMessageList) {
            chatHeadIdList.add(chatHeadList[pos].chatHeadId)
        }

        val view = LayoutInflater.from(context).inflate(R.layout.two_options_bs, null)
        val dialog = BottomSheetDialog(context!!, R.style.SheetDialog)
        dialog.setContentView(view)

        val txt_menu_1 = view.findViewById<CustomTextView>(R.id.txt_menu_1)
        val txt_menu_2 = view.findViewById<CustomTextView>(R.id.txt_menu_2)
        val view_menu_2 = view.findViewById<View>(R.id.view_menu_2)

        txt_menu_2.visibility = View.GONE
        view_menu_2.visibility = View.GONE

        txt_menu_1.text = if(showArchive) {
            getString(R.string.archive_chat)
        } else {
            getString(R.string.unarchive_chat)
        }

        txt_menu_1.setOnClickListener {
            val bodyMap: HashMap<String, Any> = hashMapOf(
                "chatHeadIds" to chatHeadIdList,
                "isArchived" to showArchive
            )
            chatHeadVM.changeChatArchive(bodyMap)
            resetMultiSelect()
            dialog.dismiss()
        }

        dialog.show()
    }

    fun resetMultiSelect() {
        chatHeadAdapter.clearMultiSelect()
    }

    /*private fun populateFakeData() {
        messageList.add(MessageListModel("Harsh", "Test Message",
                Constant.LastMessageType.TYPING, "5m ago", 10, isOnline = true))
        messageList.add(MessageListModel("Lucknow", "Kaha ho?",
                Constant.LastMessageType.BROADCAST, "5m ago", 0, isOnline = true))
        messageList.add(
                MessageListModel("Anuraag", "Test Message", Constant.LastMessageType.IMAGE,
                        "5m ago", 0, isOnline = true))
        messageList.add(MessageListModel("Akhtar", "Test Message",
                Constant.LastMessageType.MISSED_VIDEO_CALL, "5m ago", 0))
        messageList.add(MessageListModel("DBM Lucknow", "I am Project Manager",
                Constant.LastMessageType.GROUP_MESSAGE, "1yr ago", 15))
        messageList.add(
                MessageListModel("Laiba", "Test Message", Constant.LastMessageType.LEFT_GROUP,
                        "2d ago", 1, isOnline = true, isPinned = true))
        messageList.add(MessageListModel("Alhaj", "Test Message",
                Constant.LastMessageType.MISSED_AUDIO_CALL, "1M ago", 2))
        messageList.add(MessageListModel("Saurabh", "Test Message",
                Constant.LastMessageType.GROUP_TYPING, "5m ago", 0))
        messageList.add(
                MessageListModel("Peeyush", "Yes", Constant.LastMessageType.MESSAGE, "5m ago",
                        0))
        messageList.add(
                MessageListModel("Shaban", "Test Message", Constant.LastMessageType.VIDEO,
                        "5m ago", 0))
        messageList.add(
                MessageListModel("Sagar", "Test Message", Constant.LastMessageType.AUDIO,
                        "5m ago", 10, isOnline = true))
        messageList.add(
                MessageListModel("John Doe", "Test Message", Constant.LastMessageType.CONTACT,
                        "5m ago", 10))

        // sorting list based on pin
        messageList.sortBy {
            !it.isPinned
        }
    }*/

    private fun updateChatHeadUI() {
        if (chatHeadList.size == 0) {
            rl_message_list.visibility = View.GONE
            cl_empty.visibility = View.VISIBLE
            txt_empty_title.text = getString(R.string.no_conversation)
            txt_empty_description.text = getString(R.string.you_dont_have_conversation_)
            txt_add.text = getString(R.string.message_people)
        } else {
            cl_empty.visibility = View.GONE
            rl_message_list.visibility = View.VISIBLE
            chatHeadAdapter.notifyDataSetChanged()
        }
    }

    private fun setInitialLanguage() {

    }

    override fun multiSelectChange(isMultiSelectOpen: Boolean, selectCount: Int) {
    }

    override fun notifyMultiSelectItemChange(
        isMultiSelectOpen: Boolean, selectCount: Int,
        selectedMessageList: ArrayList<Int>
    ) {
        if (activity is MessengerActivity) {
            (activity as MessengerActivity).multiSelectChange(isMultiSelectOpen)
        }
        group_multi_select_toolbar.visibility = if (isMultiSelectOpen) View.VISIBLE else View.GONE
        this.isMultiSelectOpen = isMultiSelectOpen
        this.multiSelectCount = selectCount
        txt_multi_select_count.text = selectCount.toString()
        this.selectedMessageList = selectedMessageList

        if(selectedMessageList.isNotEmpty()) {
            val archiveState = chatHeadList[selectedMessageList[0]].isArchived
            var showArchiveOption = true
            for(pos in selectedMessageList) {
                if(chatHeadList[pos].isArchived != archiveState) {
                    showArchiveOption = false
                    break
                }
            }
            img_multi_select_menu.visibility = if(showArchiveOption) View.VISIBLE else View.GONE
        }


        if (multiSelectCount == 1) {
            img_multi_select_mute.visibility = View.VISIBLE
            img_multi_select_pin.visibility = View.VISIBLE

            img_multi_select_mute.setImageDrawable(
                ContextCompat.getDrawable(
                    context!!, if (chatHeadList[selectedMessageList[0]].isMute == 1) {
                        R.drawable.ic_unmute
                    } else {
                        R.drawable.ic_mute
                    }
                )
            )
        } else {
            img_multi_select_mute.visibility = View.GONE
            img_multi_select_pin.visibility = View.GONE
        }
    }

    @Suppress("unused")
    @Subscribe
    fun chatHeadSearched(searchData: ChatHeadSearched) {
        Log.v("harsh", "searchData == ${searchData.searchText}")
        // fetching chatHead list data
        fetchChatHeadList(showArchive = false, searchText = searchData.searchText.trim())
    }

    @Suppress("unused")
    @Subscribe
    fun userOnlineStatusChanged(onlineChangeData: OnlineChangeModel) {
        activity!!.runOnUiThread {
            for (index in chatHeadList.indices) {
                if (chatHeadList[index].chatHeadType == "user" && chatHeadList[index].otherUserId == onlineChangeData.userId) {
                    chatHeadList[index].isOnline = if (onlineChangeData.isOnline) 1 else 0
                    chatHeadAdapter.notifyItemChanged(index)
                    break
                }
            }
        }
    }

    @Suppress("unused")
    @Subscribe
    fun chatHeadUpdated(chatHeadData: ChatHeadData) {
        activity!!.runOnUiThread {
            var oldIndex = -1
            for (index in chatHeadList.indices) {
                if (chatHeadList[index].chatHeadId == chatHeadData.chatHeadId) {
                    oldIndex = index
                    break
                }
            }
            val newIndex = chatHeadList.indexOfFirst {
                it.isPinned == 0
            }
            if (oldIndex != -1) {
                chatHeadList.removeAt(oldIndex)

                chatHeadList.add(newIndex, chatHeadData)
                chatHeadAdapter.notifyItemMoved(oldIndex, newIndex)
                chatHeadAdapter.notifyItemChanged(newIndex)
            } else {
                chatHeadList.add(newIndex, chatHeadData)
                chatHeadAdapter.notifyItemInserted(newIndex)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // fetching chatHead list data
        refreshChatHead()
        EventBus.getDefault().register(this)
    }

    override fun onStop() {
        super.onStop()
        EventBus.getDefault().unregister(this)
    }
}