package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.model.*
import com.sociomee.msgmee.ui.repo.ChatRepo
import com.sociomee.msgmee.utils.Constants

class ChatVM : MyViewModel() {

    private var chatHeadData = MutableLiveData<ChatHeadInfoModel>()
    private var messageSent = MutableLiveData<String?>()
    private var messagesDeletedForMe = MutableLiveData<MessageDeleteModel>()
    private var messagesDeletedForAll = MutableLiveData<Boolean>()
    private var chatHeadCleared = MutableLiveData<Boolean>()
    private var forwardMessages = MutableLiveData<Boolean>()
    private var chatMessages = MutableLiveData<ChatMessageData>()
    private var searchMessage = MutableLiveData<SearchMessageModel.Data>()
    private lateinit var chatRepo: ChatRepo

    // returning live data
    fun observeMessageSending() = messageSent
    fun observeMessageList() = chatMessages
    fun observeDeleteForMe() = messagesDeletedForMe
    fun observeDeleteForAll() = messagesDeletedForAll
    fun observeChatHeadClear() = chatHeadCleared
    fun observeChatHeadData() = chatHeadData
    fun observeSearchMessages() = searchMessage
    fun observeForwardMessages() = forwardMessages

    fun getChatHeadById(body: HashMap<String, Any>) {
        if (!this::chatRepo.isInitialized) {
            chatRepo = ChatRepo()
        }
        chatRepo.getChatHeadById(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                chatHeadData.value = it.data
            } else {
                errorListener.value = it.status
            }
        }
    }

    fun fetchChatHeadMessages(body: HashMap<String, Any>, chatFetchType: Constants.ChatFetchType) {
        if (!this::chatRepo.isInitialized) {
            chatRepo = ChatRepo()
        }
        chatRepo.fetchChatHeadMessages(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                chatMessages.value = ChatMessageData(it.data!!, chatFetchType)
            } else {
                errorListener.value = it.status
            }
        }
    }

    fun searchMessages(body: HashMap<String, Any>) {
        if (!this::chatRepo.isInitialized) {
            chatRepo = ChatRepo()
        }
        chatRepo.searchMessages(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                searchMessage.value = it.data!!
            } else {
                errorListener.value = it.status
            }
        }
    }

    fun sendMessage(body: HashMap<String, Any>, isSendToUser: Boolean = false) {
        if (!this::chatRepo.isInitialized) {
            chatRepo = ChatRepo()
        }
        chatRepo.sendMessage(body, isSendToUser).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                messageSent.value = it.data
            } else {
                errorListener.value = it.status
            }
        }
    }

    fun forwardMessages(body: HashMap<String, Any>) {
        if (!this::chatRepo.isInitialized) {
            chatRepo = ChatRepo()
        }
        chatRepo.forwardMessages(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                forwardMessages.value = it.data
            } else {
                errorListener.value = it.status
            }
        }
    }

    fun deleteMessagesForMe(body: HashMap<String, Any>, selectedMessages: ArrayList<Int>) {
        if (!this::chatRepo.isInitialized) {
            chatRepo = ChatRepo()
        }
        chatRepo.deleteMessages(body, true).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                messagesDeletedForMe.value = MessageDeleteModel(it.data!!, selectedMessages)
            } else {
                errorListener.value = it.status
            }
        }
    }

    fun deleteMessagesForAll(body: HashMap<String, Any>) {
        if (!this::chatRepo.isInitialized) {
            chatRepo = ChatRepo()
        }
        chatRepo.deleteMessages(body, false).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                messagesDeletedForAll.value = it.data!!
            } else {
                errorListener.value = it.status
            }
        }
    }

    fun clearChatHead(body: HashMap<String, Any>) {
        if (!this::chatRepo.isInitialized) {
            chatRepo = ChatRepo()
        }
        chatRepo.clearChatHead(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                chatHeadCleared.value = it.data
            } else {
                errorListener.value = it.status
            }
        }
    }
}