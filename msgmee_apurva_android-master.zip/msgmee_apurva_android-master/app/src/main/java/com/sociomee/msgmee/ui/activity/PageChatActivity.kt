package com.sociomee.msgmee.ui.activity

import android.content.res.ColorStateList
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.widget.ImageViewCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.classes.CustomAppCompatActivity
import com.sociomee.msgmee.ui.`interface`.MultiSelectCallBack
import com.sociomee.msgmee.ui.adapter.ChatAdapter
import com.sociomee.msgmee.ui.model.MessageDemoModel
import com.sociomee.msgmee.utils.Constants
import kotlinx.android.synthetic.main.page_chat_activity.*

class PageChatActivity : CustomAppCompatActivity(), MultiSelectCallBack {

    private val messageList = ArrayList<MessageDemoModel>()
    private var isKeyboardOpen = false
    private var showFab = false
    private var multiSelectOpen = false
    private var isReplyShowing = false
    private var multiSelectCount = 0
    private lateinit var chatAdapter: ChatAdapter
    private var selectedMessageList = ArrayList<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.page_chat_activity)

        addKeyboardListener()
        populateFakeMessage()
        bindData()
        setViewsClick()
    }

    private fun addKeyboardListener() {
        edt_chat.addTextChangedListener(textChangedListener)
        changeViewBasedOnKeyboard()
    }

    private val textChangedListener = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {

        }

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

        }

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            isKeyboardOpen = edt_chat.text!!.isNotEmpty()
            changeViewBasedOnKeyboard()
        }
    }

    override fun onResume() {
        addKeyboardListener()
        super.onResume()
    }

    override fun onPause() {
        edt_chat.removeTextChangedListener(textChangedListener)
        super.onPause()
    }

    override fun multiSelectChange(isMultiSelectOpen: Boolean, selectCount: Int) {
    }

    override fun notifyMultiSelectItemChange(isMultiSelectOpen: Boolean, selectCount: Int,
                                             selectedMessageList: ArrayList<Int>) {
        this.multiSelectOpen = isMultiSelectOpen
        this.multiSelectCount = selectCount
        txt_multi_select_count.text = selectCount.toString()
        this.selectedMessageList = selectedMessageList

        img_reply.visibility = if (multiSelectOpen && selectCount == 1) View.VISIBLE else View.GONE

        chat_toolbar_group.visibility = if (multiSelectOpen) View.GONE else View.VISIBLE
        reply_toolbar_group.visibility = if (multiSelectOpen) View.VISIBLE else View.GONE
    }

    private fun changeViewBasedOnKeyboard() {
        cv_attachment.visibility = if (isKeyboardOpen) View.GONE else View.VISIBLE
        cv_camera.visibility = if (isKeyboardOpen) View.GONE else View.VISIBLE
        cv_mic.visibility = if (isKeyboardOpen) View.GONE else View.VISIBLE
        cv_send.visibility = if (isKeyboardOpen) View.VISIBLE else View.GONE

        if (isKeyboardOpen) {
            ImageViewCompat.setImageTintList(img_emoji,
                    ColorStateList.valueOf(ContextCompat.getColor(this, R.color.lite_green_100)))
        } else {
            ImageViewCompat.setImageTintList(img_emoji,
                    ColorStateList.valueOf(ContextCompat.getColor(this, R.color.black)))
        }
    }

    private fun setViewsClick() {
        img_toolbar_back.setOnClickListener {
            onBackPressed()
        }
        cv_attachment.setOnClickListener {
            showFab = !showFab
            animateFabMenu()
        }

        img_reply_close.setOnClickListener {
            isReplyShowing = false
            animateReply()
        }
        img_delete.setOnClickListener {
            selectedMessageList.sort()
            selectedMessageList.reverse()
            for (pos in selectedMessageList) {
                messageList.removeAt(pos)
                chatAdapter.notifyItemRemoved(pos)
            }
            chatAdapter.clearMultiSelect()
        }
        img_reply.setOnClickListener {
                processReply()
        }

        // default y value
        cv_camera_fab.y = resources.getDimension(R.dimen.animate_200)
        cv_doc_fab.y = resources.getDimension(R.dimen.animate_300)
        cv_gallery_fab.y = resources.getDimension(R.dimen.animate_400)
        cv_contact_fab.y = resources.getDimension(R.dimen.animate_500)
        cv_audio_fab.y = resources.getDimension(R.dimen.animate_600)
        cl_reply_root.y = resources.getDimension(R.dimen.animate_200)
    }

    private fun animateReply() {
        if (isReplyShowing) {
            cl_reply_root.animate().translationY(0f)
            edt_chat.hint = getString(R.string.type_to_reply)
        } else {
            cl_reply_root.animate().translationY(resources.getDimension(R.dimen.animate_200))
            edt_chat.hint = getString(R.string.type_your_message)
        }
    }

    private fun animateFabMenu() {
        if (showFab) {
            cv_camera_fab.animate().translationY(0f)
            cv_doc_fab.animate().translationY(0f)
            cv_gallery_fab.animate().translationY(0f)
            cv_contact_fab.animate().translationY(0f)
            cv_audio_fab.animate().translationY(0f)
        } else {
            cv_camera_fab.animate().translationY(resources.getDimension(R.dimen.animate_200))
            cv_doc_fab.animate().translationY(resources.getDimension(R.dimen.animate_300))
            cv_gallery_fab.animate().translationY(resources.getDimension(R.dimen.animate_400))
            cv_contact_fab.animate().translationY(resources.getDimension(R.dimen.animate_500))
            cv_audio_fab.animate().translationY(resources.getDimension(R.dimen.animate_600))
        }
    }

    override fun setInitialLanguage() {
        edt_chat.hint = getString(R.string.type_your_message)
        txt_page_name.hint = "Eminem Production"
    }

    override fun bindData() {
        // shuffling the items of the list
        messageList.shuffle()

//        chatAdapter = ChatAdapter(messageList, this)
        rl_chat.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, true)
        rl_chat.adapter = chatAdapter
        chatAdapter.notifyDataSetChanged()
    }

    override fun onBackPressed() {
        if (multiSelectOpen) {
            chatAdapter.clearMultiSelect()
        } else {
            super.onBackPressed()
        }
    }

    private fun processReply() {
        val replyModel = messageList[selectedMessageList[0]]

        chatAdapter.clearMultiSelect()
        isReplyShowing = true

        txt_reply_username.text = replyModel.senderName
        txt_reply_text.text = replyModel.message

        img_reply_media.visibility = View.VISIBLE

        when (replyModel.messageType) {
            Constants.MessageType.MY_MESSAGE, Constants.MessageType.OTHER_MESSAGE,
            Constants.MessageType.MY_MESSAGE_REPLY, Constants.MessageType.OTHER_MESSAGE_REPLY,
            Constants.MessageType.MY_IMAGE_REPLY, Constants.MessageType.OTHER_IMAGE_REPLY,
            Constants.MessageType.MY_CONTACT_REPLY, Constants.MessageType.OTHER_CONTACT_REPLY,
            Constants.MessageType.MY_AUDIO_REPLY, Constants.MessageType.OTHER_AUDIO_REPLY,
            Constants.MessageType.MY_DOC_REPLY, Constants.MessageType.OTHER_DOC_REPLY,
            Constants.MessageType.MY_VIDEO_REPLY, Constants.MessageType.OTHER_VIDEO_REPLY,
            Constants.MessageType.MY_GIF_REPLY, Constants.MessageType.OTHER_GIF_REPLY -> {
                img_reply_media.visibility = View.GONE
            }
            Constants.MessageType.MY_IMAGE, Constants.MessageType.OTHER_IMAGE,
            Constants.MessageType.MY_IMAGE_MESSAGE, Constants.MessageType.OTHER_IMAGE_MESSAGE -> {
                Glide.with(this).load(R.drawable.test_image).into(img_reply_media)
            }
            Constants.MessageType.MY_CONTACT, Constants.MessageType.OTHER_CONTACT -> {
                Glide.with(this).load(R.drawable.test_image).into(img_reply_media)
            }
            Constants.MessageType.MY_AUDIO, Constants.MessageType.OTHER_AUDIO -> {
                Glide.with(this).load(R.drawable.ic_circle_play).into(img_reply_media)
            }
            Constants.MessageType.MY_DOC, Constants.MessageType.OTHER_DOC -> {
                Glide.with(this).load(R.drawable.ic_doc).into(img_reply_media)
            }
            Constants.MessageType.MY_VIDEO, Constants.MessageType.OTHER_VIDEO,
            Constants.MessageType.MY_VIDEO_MESSAGE, Constants.MessageType.OTHER_VIDEO_MESSAGE -> {
                Glide.with(this).load(R.drawable.test_image).into(img_reply_media)
            }
            Constants.MessageType.MY_GIF, Constants.MessageType.OTHER_GIF,
            Constants.MessageType.CHAT_BUBBLE -> {
                Glide.with(this).load(R.drawable.test_image).into(img_reply_media)
            }
        }


        animateReply()
    }

    private fun populateFakeMessage() {
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_MESSAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_MESSAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_MESSAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_MESSAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_MESSAGE_REPLY, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_IMAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_IMAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_IMAGE_REPLY, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_IMAGE_MESSAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_VIDEO, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_VIDEO_MESSAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_VIDEO, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_VIDEO_REPLY, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this), Constants.MessageType.MY_GIF,
                        "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_GIF, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_GIF_REPLY, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_CONTACT, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_CONTACT, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_CONTACT_REPLY, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this), Constants.MessageType.MY_DOC,
                        "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_DOC, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_DOC_REPLY, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_AUDIO, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_AUDIO, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.MY_AUDIO_REPLY, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_MESSAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_MESSAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_MESSAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_MESSAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_MESSAGE_REPLY, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_IMAGE_MESSAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_IMAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_IMAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_IMAGE_REPLY, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_VIDEO_MESSAGE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_VIDEO, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_VIDEO, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_VIDEO_REPLY, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_AUDIO, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_AUDIO, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_AUDIO_REPLY, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_CONTACT, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_CONTACT, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_CONTACT_REPLY, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_GIF, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_GIF, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_GIF_REPLY, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_DOC, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_DOC, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel(Constants.getRandomString(this),
                        Constants.MessageType.OTHER_DOC_REPLY, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel("Today's Message",
                        Constants.MessageType.CHAT_BUBBLE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel("Yesterday's Message",
                        Constants.MessageType.CHAT_BUBBLE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel("Created Chat",
                        Constants.MessageType.CHAT_BUBBLE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
        messageList.add(
                MessageDemoModel("Cleared Chat",
                        Constants.MessageType.CHAT_BUBBLE, "2m ago",
                        "Harsh", Constants.getRandomString(this)))
    }
}