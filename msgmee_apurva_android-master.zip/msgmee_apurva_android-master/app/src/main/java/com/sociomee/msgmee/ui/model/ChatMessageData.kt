package com.sociomee.msgmee.ui.model

import com.sociomee.msgmee.utils.Constants

data class ChatMessageData(val messageList: ArrayList<ChatModel>, val chatFetchType: Constants.ChatFetchType)