package com.sociomee.msgmee.ui.data

data class AuthModel(val isEmail: Boolean, val enteredCredential: String, val type: String, val socialLoginData: SocialLoginData? = null)

data class SocialLoginData(val name: String, val profilePicture: String)