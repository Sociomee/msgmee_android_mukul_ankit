package com.sociomee.msgmee.ui.model

import android.os.Parcel
import android.os.Parcelable
import com.sociomee.msgmee.utils.Constants

@Suppress("CAST_NEVER_SUCCEEDS")
data class MediaPreviewModel(
    val mediaPath: String,
    val mediaType: Constants.SelectedMediaType,
    var mediaMessage: String = ""
) :  Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString()!!,
        parcel.readInt().let { if (it >= 0) enumValues<Constants.SelectedMediaType>()[it] else 0 } as Constants.SelectedMediaType,
        parcel.readString()!!
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(mediaPath)
        parcel.writeInt(mediaType?.ordinal ?: -1)
        parcel.writeString(mediaMessage)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<MediaPreviewModel> {
        override fun createFromParcel(parcel: Parcel): MediaPreviewModel {
            return MediaPreviewModel(parcel)
        }

        override fun newArray(size: Int): Array<MediaPreviewModel?> {
            return arrayOfNulls(size)
        }
    }


}