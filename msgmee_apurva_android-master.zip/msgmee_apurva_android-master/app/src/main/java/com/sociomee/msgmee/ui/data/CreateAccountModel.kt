package com.sociomee.msgmee.ui.data


import com.google.gson.annotations.SerializedName
import com.sociomee.msgmee.ui.model.UserInfoModel

data class CreateAccountModel(
        @SerializedName("data")
    val `data`: Data,
        @SerializedName("error")
    val error: Boolean,
        @SerializedName("success")
    val success: Boolean
) {
    data class Data(
            @SerializedName("errorResult")
        val errorResult: ErrorResult,
            @SerializedName("successResult")
        val successResult: UserInfoModel
    ) {
        data class ErrorResult(
            @SerializedName("message")
            val message: String,
            @SerializedName("userNameList")
            val userNameList: List<String>
        )
    }
}