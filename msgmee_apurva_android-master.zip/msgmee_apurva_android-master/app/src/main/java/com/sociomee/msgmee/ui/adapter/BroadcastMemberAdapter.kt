package com.sociomee.msgmee.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sociomee.msgmee.R
import com.sociomee.msgmee.custom.widget.CustomImageView
import com.sociomee.msgmee.custom.widget.CustomTextView
import com.sociomee.msgmee.ui.model.ChatMemberData

class BroadcastMemberAdapter(private val memberList: ArrayList<ChatMemberData>) :
    RecyclerView.Adapter<BroadcastMemberAdapter.BroadcastMemberHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = BroadcastMemberHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.participants_child, parent, false)
    )

    override fun onBindViewHolder(holder: BroadcastMemberHolder, position: Int) {
        val data = memberList[position]
        holder.txt_group_admin.text = holder.itemView.context.getString(R.string.remove)

        holder.txt_group_admin.visibility = View.GONE
        holder.txt_group_admin.setTextColor(ContextCompat.getColor(holder.itemView.context,
        R.color.red))

        holder.txt_name.text = data.fullName

        Glide.with(holder.itemView.context).load(data.profileImageThumb).placeholder(
            R.drawable.profile_placeholder
        ).into(holder.img_profile)
    }

    override fun getItemCount() = memberList.size

    class BroadcastMemberHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txt_group_admin = itemView.findViewById<CustomTextView>(R.id.txt_group_admin)
        val txt_name = itemView.findViewById<CustomTextView>(R.id.txt_name)
        val img_profile = itemView.findViewById<CustomImageView>(R.id.img_profile)
    }

}