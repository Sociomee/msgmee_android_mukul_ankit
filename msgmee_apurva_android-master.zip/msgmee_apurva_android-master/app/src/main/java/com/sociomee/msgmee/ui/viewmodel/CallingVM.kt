package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.repo.CallingRepo

class CallingVM: MyViewModel() {

    private var initiateCall = MutableLiveData<Boolean>()
    private var addUserInCall = MutableLiveData<Boolean>()
    private var updateCallStatus = MutableLiveData<Boolean>()
    private lateinit var callingRepo: CallingRepo

    // returning LiveData
    fun observeInitiateCall() = initiateCall
    fun observeUpdateCallStatus() = updateCallStatus
    fun observeAddUserInCall() = addUserInCall

    fun initiateCall(body: HashMap<String, Any>) {
        if(!this::callingRepo.isInitialized) {
            callingRepo = CallingRepo()
        }
        callingRepo.initiateCall(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                initiateCall.value = it.data
            } else {
                errorListener.value = it.status
            }
        }
    }

    fun addUserInCall(body: HashMap<String, Any>) {
        if(!this::callingRepo.isInitialized) {
            callingRepo = CallingRepo()
        }
        callingRepo.addUserInCall(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                addUserInCall.value = it.data
            } else {
                errorListener.value = it.status
            }
        }
    }

    fun updateCallStatus(body: HashMap<String, Any>) {
        if(!this::callingRepo.isInitialized) {
            callingRepo = CallingRepo()
        }
        callingRepo.initiateCall(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                updateCallStatus.value = it.data
            } else {
                errorListener.value = it.status
            }
        }
    }

}