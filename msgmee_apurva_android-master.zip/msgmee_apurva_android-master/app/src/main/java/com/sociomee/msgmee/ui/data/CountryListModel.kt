package com.sociomee.msgmee.ui.data

import com.google.gson.annotations.SerializedName

data class CountryListModel(
        @SerializedName("data")
        val `data`: Data,
        @SerializedName("error")
        val error: Boolean,
        @SerializedName("success")
        val success: Boolean
) {
    data class Data(
            @SerializedName("successResult")
            val row: CountryRowData
    ) {
        data class CountryRowData(
                @SerializedName("rows")
                val countryList: ArrayList<CountryDataModel>
        )
    }
}

data class CountryDataModel(
        @SerializedName("code")
        val code: String?,
        @SerializedName("flagURL")
        val flagURL: String,
        @SerializedName("iconURL")
        val iconURL: String,
        @SerializedName("id")
        val id: String,
        @SerializedName("name")
        val name: String,
        @SerializedName("nativeLanguagesId")
        val nativeLanguagesId: Any,
        @SerializedName("teleCode")
        val teleCode: Any
)