package com.sociomee.msgmee.notification

import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.sociomee.msgmee.R
import com.sociomee.msgmee.ui.activity.MessengerActivity
import com.sociomee.msgmee.ui.model.CallMissedNotificationModel
import com.sociomee.msgmee.ui.model.CallNotificationModel
import com.sociomee.msgmee.ui.model.MessageNotificationModel
import com.sociomee.msgmee.utils.Constants
import java.lang.Exception

class FirebaseNotificationService : FirebaseMessagingService() {

    override fun onNewToken(newToken: String) {
        super.onNewToken(newToken)
        Log.v("harshNotification", "onNewToken == $newToken")
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d("harshNotification", "From: ${remoteMessage.from}")

        Log.d("harshNotification", "Message data payload: ${remoteMessage.data}")

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            remoteMessage.data.forEach { (s, s2) ->
                Log.v("harshNotification", "key $s == value $s2")
            }
        }
        var notificationType = ""

        try {
            remoteMessage.data.apply {
                if (this.isNotEmpty()) {

                    notificationType = this["type"] ?: ""
                    val payload = this["payload"] ?: ""

                    if (payload.isNotEmpty()) {
                        val parser = JsonParser()
                        val jsonObject = parser.parse(payload) as JsonObject

                        if (notificationType == "msgRecieved") {
                            val messageData: MessageNotificationModel? = Constants.myGson.fromJson(
                                jsonObject["data"],
                                MessageNotificationModel::class.java
                            )

                            if (messageData != null && messageData.chatHeadId != MyNotificationBuilder.openedChatHeadId) {
                                MyNotificationBuilder.showMessageNotification(
                                    this@FirebaseNotificationService,
                                    messageData
                                )
                            }
                        } else if (notificationType == "incommingCall") {
                            val callData: CallNotificationModel? = Constants.myGson.fromJson(
                                jsonObject["data"],
                                CallNotificationModel::class.java
                            )

                            if (callData != null && !MyNotificationBuilder.isInCall) {
                                MyNotificationBuilder.showCallNotification(
                                    this@FirebaseNotificationService,
                                    callData
                                )
                            }
                        } else if (notificationType == "missedCall") {
                            val callMissedData: CallMissedNotificationModel? =
                                Constants.myGson.fromJson(
                                    jsonObject["data"],
                                    CallMissedNotificationModel::class.java
                                )
                            val intent = Intent(
                                this@FirebaseNotificationService,
                                MessengerActivity::class.java
                            )
                            intent.putExtra("isOpenCall", true)

                            if (callMissedData?.callRoomInfo != null) {
                                val callText =
                                    this@FirebaseNotificationService.getString(if (callMissedData.callRoomInfo.isVideo == 1) R.string.you_missed_video_ else R.string.you_missed_audio_)
                                MyNotificationBuilder.showTextNotification(
                                    this@FirebaseNotificationService,
                                    this@FirebaseNotificationService.getString(R.string.new_missed_call),
                                    "$callText ${callMissedData.callRoomInfo.callerUserName}",
                                    intent,
                                    notificationId = MyNotificationBuilder.callNotificationId - 1
                                )
                            }

                            // dismissing call notification if there is any
                            with(NotificationManagerCompat.from(this@FirebaseNotificationService)) {
                                cancel(MyNotificationBuilder.callNotificationId)
                            }
                        } else {
                            val intent = Intent(
                                this@FirebaseNotificationService,
                                MessengerActivity::class.java
                            )
                            MyNotificationBuilder.showTextNotification(
                                this@FirebaseNotificationService,
                                "Generic notification",
                                "This is a notification with $notificationType",
                                intent,
                                notificationId = MyNotificationBuilder.callNotificationId - 2
                            )
                        }
                    }
                } else {
                    val intent = Intent(
                        this@FirebaseNotificationService,
                        MessengerActivity::class.java
                    )
                    MyNotificationBuilder.showTextNotification(
                        this@FirebaseNotificationService,
                        "Generic notification",
                        "This is a notification without any type",
                        intent,
                        notificationId = MyNotificationBuilder.callNotificationId - 2
                    )
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Notification error of type == $notificationType", Toast.LENGTH_LONG).show()
            Log.v("harshNotification", "notification creation error == ${e.message}")
        }
    }

}