package com.sociomee.msgmee.retrofit

import android.util.Log
import com.sociomee.msgmee.BuildConfig
import com.sociomee.msgmee.utils.Constants
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class MyRetrofit {

    companion object {
        var baseUrl: String = "https://apiserver.msgmee.com" // aws
        var socketUrl: String = "https://socket.msgmee.com" // aws
        const val mediaBaseUrl: String =
            "https://sociomee-dev.s3.ap-south-1.amazonaws.com/" // image base url

        lateinit var client: OkHttpClient

        private val headerInterceptor = Interceptor { chain ->
            Log.i("harsh", "headerInterceptor called")
            var request = chain.request()
            request = if (Constants.userInfo != null && Constants.userInfo!!.token.isNotEmpty()) {
                request.newBuilder()
                    .addHeader("Authorization", "Bearer ${Constants.userInfo!!.token}")
                    .build()
            } else {
                request.newBuilder()
                    .build()
            }
            chain.proceed(request)
        }

        private fun getHttpClient(): OkHttpClient {

            val interceptor = HttpLoggingInterceptor()
            interceptor.setLevel(HttpLoggingInterceptor.Level.BODY)

            client = if (BuildConfig.DEBUG) {
                OkHttpClient.Builder().addInterceptor(headerInterceptor)
                    .addInterceptor(interceptor)
                    .connectTimeout(5, TimeUnit.MINUTES)
                    .readTimeout(5, TimeUnit.MINUTES)
                    .writeTimeout(5, TimeUnit.MINUTES).build()
            } else {
                OkHttpClient.Builder().addInterceptor(headerInterceptor)
                    .addInterceptor(interceptor)
                    .connectTimeout(60, TimeUnit.SECONDS)
                    .readTimeout(60, TimeUnit.SECONDS)
                    .writeTimeout(60, TimeUnit.SECONDS).build()
            }
            return client
        }

        private fun getRetrofit() = Retrofit.Builder()
            .baseUrl(baseUrl)
            .addCallAdapterFactory(CustomCallAdapter())
            .addConverterFactory(GsonConverterFactory.create())
            .client(getHttpClient())
            .build()

        fun <T> getRetrofitService(serviceType: Class<T>): T {
            return getRetrofit().create(serviceType)
        }
    }
}