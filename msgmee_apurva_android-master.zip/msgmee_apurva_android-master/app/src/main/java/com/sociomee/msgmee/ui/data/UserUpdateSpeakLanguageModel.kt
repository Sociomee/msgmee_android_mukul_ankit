package com.sociomee.msgmee.ui.data


import com.google.gson.annotations.SerializedName

data class UserUpdateSpeakLanguageModel(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("successResult")
        val successResult: String
    )
}