package com.sociomee.msgmee.notification

import android.annotation.TargetApi
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.util.Log
import android.widget.RemoteViews
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.sociomee.msgmee.R
import com.sociomee.msgmee.receiver.AcceptCallBroadCastReceiver
import com.sociomee.msgmee.receiver.DeclineCallBroadCastReceiver
import com.sociomee.msgmee.ui.activity.CallActivity
import com.sociomee.msgmee.ui.activity.ChatActivity
import com.sociomee.msgmee.ui.model.CallNotificationModel
import com.sociomee.msgmee.ui.model.ChatHeadInfo
import com.sociomee.msgmee.ui.model.MessageNotificationModel
import com.sociomee.msgmee.ui.repo.CallingRepo
import com.sociomee.msgmee.utils.Constants
import com.sociomee.msgmee.utils.getMessageText
import com.sociomee.msgmee.utils.imageUrlToIcon
import java.io.IOException
import java.net.URL

class MyNotificationBuilder {

    companion object {
        private var globalNotificationId = 0
        const val callNotificationId = Int.MAX_VALUE
        private const val CALL_TIMEOUT_MILLIS = 30000L
        private const val MESSAGE_GROUP = "messageGroup"
        var openedChatHeadId: String? = null
        var isInCall: Boolean = false
        var callRoomId = ""
        var isVideoCall = false

        //====================================Text Notification====================================//
        //====================================Text Notification====================================//
        fun showTextNotification(
            context: Context, title: String,
            body: String,
            intent: Intent,
            notificationId: Int = globalNotificationId++
        ) {
            val pendingIntent: PendingIntent = PendingIntent.getActivity(context, 0, intent, 0)
            val builder = NotificationCompat.Builder(
                context,
                context.getString(R.string.other_notification_channel)
            )
                .setSmallIcon(R.drawable.app_logo)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(
                    NotificationCompat.BigTextStyle()
                        .bigText(body)
                )
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)

            showNotification(context, builder, notificationId = notificationId)
        }


        //====================================Call Notification====================================//
        //====================================Call Notification====================================//
        fun showCallNotification(
            context: Context,
            callNotificationModel: CallNotificationModel
        ) {
            // waking screen if turned off
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            val isScreenOn =
                pm.isInteractive
            Log.v("harshNotification", "isScreenOn == $isScreenOn")

            if (!isScreenOn) {
                val wl = pm.newWakeLock(
                    PowerManager.SCREEN_DIM_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "myApp:notificationLock"
                )
                wl.acquire(CALL_TIMEOUT_MILLIS) //set your time in milliseconds
            }

            val callingRepo = CallingRepo()
            fun updateCallState(state: String) {

                val bodyMap: HashMap<String, Any> = hashMapOf(
                    "callRoomId" to callNotificationModel.callRoomId,
                    "callState" to state
                )
                callingRepo.updateCallState(bodyMap)
            }

            // updating ringing status
            updateCallState("ringing")

            // intent for opening calling activity
            val intent = Intent(context, CallActivity::class.java)
            intent.putExtra("callRoomId", callNotificationModel.callRoomId)
            intent.putExtra("isVideoCall", callNotificationModel.isVideo)
            intent.putExtra("isOwner", false)

            // pending intent for accepting or declining call
            callRoomId = callNotificationModel.callRoomId
            isVideoCall = callNotificationModel.isVideo == 1
            val acceptIntent = Intent(context, AcceptCallBroadCastReceiver::class.java)
            val acceptPendingIntent = PendingIntent.getBroadcast(
                context,
                0,
                acceptIntent,
                PendingIntent.FLAG_UPDATE_CURRENT
            )
            // decline intent
            val declineIntent = Intent(context, DeclineCallBroadCastReceiver::class.java)
            val declinePendingIntent = PendingIntent.getBroadcast(
                context,
                0,
                declineIntent,
                PendingIntent.FLAG_UPDATE_CURRENT
            )

            // creating collapsed and expanded notification layout
            val callerName = callNotificationModel.caller.userName
            val callingText =
                "$callerName " + if (callNotificationModel.isVideo == 1) context.getString(R.string.is_video_calling_) else context.getString(
                    R.string.is_audio_calling_
                )
            val callerImage: Bitmap? =
                if (callNotificationModel.caller.callerProfilePic != null && callNotificationModel.caller.callerProfilePic.isNotEmpty()) {
                    try {
                        val url = URL(callNotificationModel.caller.callerProfilePic)
                        BitmapFactory.decodeStream(url.openConnection().getInputStream())
                    } catch (e: IOException) {
                        println(e)
                        BitmapFactory.decodeResource(
                            context.resources,
                            R.drawable.profile_placeholder
                        )
                    }
                } else {
                    BitmapFactory.decodeResource(context.resources, R.drawable.profile_placeholder)
                }

            // collapsed layout
            val notificationLayoutCollapsed = RemoteViews(
                context.packageName,
                R.layout.call_notification_collapsed
            )
            notificationLayoutCollapsed.setTextViewText(R.id.txt_caller_name, callerName)
            notificationLayoutCollapsed.setTextViewText(R.id.txt_caller_type, callingText)
            if (callerImage != null) {
                notificationLayoutCollapsed.setImageViewBitmap(R.id.img_profile, callerImage)
            }
            notificationLayoutCollapsed.setOnClickPendingIntent(
                R.id.img_accept_call,
                acceptPendingIntent
            )
            notificationLayoutCollapsed.setOnClickPendingIntent(
                R.id.img_decline_call,
                declinePendingIntent
            )

            // expanded layout
            val notificationLayoutExpanded = RemoteViews(
                context.packageName,
                R.layout.call_notification_expanded
            )
            notificationLayoutExpanded.setTextViewText(R.id.txt_caller_name, callerName)
            notificationLayoutExpanded.setTextViewText(R.id.txt_caller_type, callingText)
            notificationLayoutExpanded.setTextViewText(
                R.id.txt_call_decline,
                context.getString(R.string.decline)
            )
            notificationLayoutExpanded.setTextViewText(
                R.id.txt_call_accept,
                context.getString(R.string.accept)
            )
            notificationLayoutExpanded.setTextViewText(R.id.txt_caller_type, callingText)
            if (callerImage != null) {
                notificationLayoutExpanded.setImageViewBitmap(R.id.img_profile, callerImage)
            }
            notificationLayoutExpanded.setOnClickPendingIntent(
                R.id.rl_accept_call,
                acceptPendingIntent
            )
            notificationLayoutExpanded.setOnClickPendingIntent(
                R.id.rl_decline_call,
                declinePendingIntent
            )

            val resultPendingIntent: PendingIntent? = TaskStackBuilder.create(context).run {
                // Add the intent, which inflates the back stack
                addNextIntentWithParentStack(intent)
                // Get the PendingIntent containing the entire back stack
                getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT)
            }
            val soundUri = Uri.parse(
                "android.resource://" +
                        context.packageName +
                        "/" +
                        R.raw.incoming_call_ringtone
            )
            val builder = NotificationCompat.Builder(
                context,
                context.getString(R.string.call_notification_channel)
            )
                .setCustomContentView(notificationLayoutCollapsed)
                .setCustomBigContentView(notificationLayoutExpanded)
                .setSmallIcon(R.drawable.app_logo)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setSound(soundUri)
                .setVibrate(longArrayOf(1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000))
                .setContentIntent(resultPendingIntent)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setTimeoutAfter(CALL_TIMEOUT_MILLIS)
                .setAutoCancel(true)

            val notification = builder.build()
            notification.flags =
                Notification.FLAG_NO_CLEAR // this stops notification from being removed by user
            with(NotificationManagerCompat.from(context)) {
                // notificationId is a unique int for each notification that you must define
                notify(callNotificationId, notification)
            }
        }


        //====================================Message Notification====================================//
        //====================================Message Notification====================================//
        fun showMessageNotification(context: Context, messageData: MessageNotificationModel) {
            // intent for when user clicks on whole notification
            val activityIntent = Intent(context, ChatActivity::class.java)
            val chatInfo = ChatHeadInfo(
                messageData.chatHeadId,
                messageData.chatName,
                messageData.chatProfile,
                messageData.chatHeadType,
                messageData.chatTypeId,
                messageData.chatHeadSequenceNo
            )
            activityIntent.putExtra("chatHeadData", Constants.myGson.toJson(chatInfo))
            val activityPendingIntent: PendingIntent? = TaskStackBuilder.create(context).run {
                // Add the intent, which inflates the back stack
                addNextIntentWithParentStack(activityIntent)
                // Get the PendingIntent containing the entire back stack
                getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                showMessageNotificationForP(
                    context,
                    activityPendingIntent!!,
                    messageData
                )
            } else {
                showMessageNotificationBelowP(
                    context,
                    activityPendingIntent!!,
                    messageData
                )
            }
        }

        @RequiresApi(Build.VERSION_CODES.P)
        private fun showMessageNotificationForP(
            context: Context,
            activityPendingIntent: PendingIntent,
            messageData: MessageNotificationModel
        ) {
            val builder = Notification.Builder(
                context,
                context.getString(R.string.other_notification_channel)
            ).setSmallIcon(R.drawable.app_logo)
                .setContentIntent(activityPendingIntent)
                .setColor(Color.GREEN)
                .setGroup(MESSAGE_GROUP)
                .setGroupSummary(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setAutoCancel(true)

            // creating logged in user's person
            val currentPerson = Person.Builder().apply {
                setName(Constants.userInfo!!.username)
                if (Constants.userInfo!!.profileImage != null || Constants.userInfo!!.profileImageThumb != null) {
                    val icon = (Constants.userInfo!!.profileImageThumb
                        ?: Constants.userInfo!!.profileImage)!!.imageUrlToIcon()
                    if (icon != null) {
                        setIcon(icon)
                    }
                }
            }.build()

            with(Notification.MessagingStyle(currentPerson)) {
                if (messageData.chatHeadType == "group") {
                    conversationTitle = messageData.chatName
                }

                // adding all messages
                var size = messageData.messageList.size
                messageData.messageList.forEach {
                    val person = Person.Builder().apply {
                        setName(it.senderUsername)
                        if (it.senderProfilePicture != null) {
                            val icon = it.senderProfilePicture.imageUrlToIcon()
                            if (icon != null) {
                                setIcon(icon)
                            }
                        }
                    }.build()
                    addMessage(
                        if (it.imageUrl != null && !it.imageUrl.contains("undefined", true)) {
                            Notification.MessagingStyle.Message(
                                it.getMessageText(context),
                                (System.currentTimeMillis() - (size-- * 1000)),
                                person
                            ).setData("image/", Uri.parse(it.imageUrl))
                        } else {
                            Notification.MessagingStyle.Message(
                                it.getMessageText(context),
                                (System.currentTimeMillis() - 10000),
                                person
                            )
                        }
                    )
                }

                setBuilder(builder)
            }

            showNotification(context, builder, notificationId = messageData.chatHeadSequenceNo)
        }

        @TargetApi(Build.VERSION_CODES.O)
        @Suppress("DEPRECATION")
        private fun showMessageNotificationBelowP(
            context: Context,
            activityPendingIntent: PendingIntent,
            messageData: MessageNotificationModel
        ) {
            val messageStyle = NotificationCompat.MessagingStyle(Constants.userInfo!!.username)

            if (messageData.chatHeadType == "group") {
                messageStyle.conversationTitle = messageData.chatName
            }

            var size = messageData.messageList.size
            messageData.messageList.forEach {
                messageStyle.addMessage(
                    if (it.imageUrl != null && !it.imageUrl.contains("undefined", true)) {
                        NotificationCompat.MessagingStyle.Message(
                            it.getMessageText(context),
                            (System.currentTimeMillis() - (size-- * 1000)),
                            it.senderUsername
                        )
                            .setData("image/", Uri.parse(it.imageUrl))
                    } else {
                        NotificationCompat.MessagingStyle.Message(
                            it.getMessageText(context),
                            (System.currentTimeMillis() - 10000),
                            it.senderUsername
                        )
                    }
                )
            }

            val builder = NotificationCompat.Builder(
                context,
                context.getString(R.string.other_notification_channel)
            ).setStyle(
                messageStyle
            ).setSmallIcon(R.drawable.app_logo)
                .setContentTitle("MessageMee")
                .setContentIntent(activityPendingIntent)
                .setColor(Color.GREEN)
                .setGroup(MESSAGE_GROUP)
                .setGroupSummary(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setAutoCancel(true)

            showNotification(context, builder, notificationId = messageData.chatHeadSequenceNo)
        }


        //====================================Process Notification====================================//
        //====================================Process Notification====================================//
        fun createNotificationChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val callNotification = context.getString(R.string.call_notification_channel)
                val otherNotification = context.getString(R.string.other_notification_channel)
                val callDescriptionText = context.getString(R.string.call_notification_channel_desc)
                val otherDescriptionText = context.getString(R.string.other_notification_channel_desc)
                val importance = NotificationManager.IMPORTANCE_HIGH
                val audioAttributes = AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .build()
                val soundUri = Uri.parse(
                    "android.resource://" +
                            context.packageName +
                            "/" +
                            R.raw.incoming_call_ringtone
                )
                val callNotificationChannel = NotificationChannel(callNotification, callNotification, importance).apply {
                    description = callDescriptionText
                    enableVibration(true)
                    vibrationPattern = longArrayOf(1000, 1000, 1000, 1000, 1000)
                    setSound(soundUri, audioAttributes)
                }
                val otherNotificationChannel = NotificationChannel(otherNotification, otherNotification, importance).apply {
                    description = otherDescriptionText
                }
                // Register the channel with the system
                val notificationManager: NotificationManager =
                    context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.createNotificationChannels(listOf(callNotificationChannel, otherNotificationChannel))
            }
        }

        private fun showNotification(
            context: Context,
            builder: NotificationCompat.Builder,
            notificationId: Int = globalNotificationId++
        ) {
            with(NotificationManagerCompat.from(context)) {
                // notificationId is a unique int for each notification that you must define
                notify(notificationId, builder.build())
            }
        }

        private fun showNotification(
            context: Context,
            builder: Notification.Builder,
            notificationId: Int = globalNotificationId++
        ) {
            with(NotificationManagerCompat.from(context)) {
                // notificationId is a unique int for each notification that you must define
                notify(notificationId, builder.build())
            }
        }
    }
}