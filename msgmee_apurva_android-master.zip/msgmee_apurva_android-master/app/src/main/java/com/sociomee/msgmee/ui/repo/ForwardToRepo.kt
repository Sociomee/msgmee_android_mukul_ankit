package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.ApiCall
import com.sociomee.msgmee.ui.model.ForwardToModel
import retrofit2.Response

class ForwardToRepo {

    fun fetchForwardToList(body: HashMap<String, Any>) : MutableLiveData<MyResponse<ArrayList<ForwardToModel.Data.SuccessResult.Row>>> {
        val data = MutableLiveData<MyResponse<ArrayList<ForwardToModel.Data.SuccessResult.Row>>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.fetchForwardToList(body)

        call.enqueue(object : MyCallback<ForwardToModel> {
            override fun success(response: Response<ForwardToModel>) {
                data.postValue(MyResponse.success(response.body()!!.data.successResult.rows))
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }
        })
        return data
    }

}