package com.sociomee.msgmee.ui.model


import com.google.gson.annotations.SerializedName

data class ChatMemberModel(
    @SerializedName("data")
    val `data`: Data,
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("success")
    val success: Boolean
) {
    data class Data(
        @SerializedName("successResult")
        val successResult: SuccessResult
    ) {
        data class SuccessResult(
            @SerializedName("count")
            val count: Int,
            @SerializedName("rows")
            val rows: List<ChatMemberData>
        )
    }
}
data class ChatMemberData(
    @SerializedName("fullName")
    val fullName: String,
    @SerializedName("id")
    val id: String,
    @SerializedName("profileImageThumb")
    val profileImageThumb: String,
    @SerializedName("role")
    var role: String,
    @SerializedName("userName")
    val userName: String
)