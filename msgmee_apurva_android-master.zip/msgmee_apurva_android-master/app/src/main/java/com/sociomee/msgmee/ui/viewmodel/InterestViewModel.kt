package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.ui.data.InterestModel
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.repo.InterestRepo

class InterestViewModel : MyViewModel() {

    private var interestList = MutableLiveData<List<InterestModel.InterestList>>()
    private var addInterestToUser = MutableLiveData<Boolean>()
    private lateinit var interestRepo: InterestRepo

    // returning LiveData
    fun observeInterestList() = interestList

    fun getInterestList() {
        if (!this::interestRepo.isInitialized) {
            interestRepo = InterestRepo()
        }
        isLoading.value = true
        interestRepo.fetchInterestList().observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                interestList.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }

    // add interest to user
    fun observeAddInterest() = addInterestToUser
    fun addInterestToUser(body: HashMap<String, Any>) {
        if (!this::interestRepo.isInitialized) {
            interestRepo = InterestRepo()
        }
        isLoading.value = true
        interestRepo.addInterestToUser(body).observeForever {
            if (it.status == ResponseStatus.SUCCESS) {
                addInterestToUser.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }
}