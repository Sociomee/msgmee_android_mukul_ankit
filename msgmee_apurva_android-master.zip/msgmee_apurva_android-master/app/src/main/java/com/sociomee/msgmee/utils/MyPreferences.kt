package com.sociomee.msgmee.utils

import android.content.Context
import com.google.gson.Gson
import com.sociomee.msgmee.ui.model.UserInfoModel

class MyPreferences {

    companion object {
        fun saveStringInPreference(context: Context, key: String, value: String) {
            val preferences = context.getSharedPreferences("MessageMee", Context.MODE_PRIVATE)
            preferences.edit().putString(key, value).apply()
        }

        fun deleteStringInPreference(context: Context, key: String) {
            val preferences = context.getSharedPreferences("MessageMee", Context.MODE_PRIVATE)
            preferences.edit().remove(key).apply()
        }

        fun saveIntInPreference(context: Context, key: String, value: Int) {
            val preferences = context.getSharedPreferences("MessageMee", Context.MODE_PRIVATE)
            preferences.edit().putInt(key, value).apply()
        }

        fun getFromPreferences(context: Context, key: String): String? {
            return context.getSharedPreferences("MessageMee", Context.MODE_PRIVATE).getString(key, "")
        }

        fun getFromPreferencesOrNull(context: Context, key: String): String? {
            return context.getSharedPreferences("MessageMee", Context.MODE_PRIVATE).getString(key, null)
        }

        fun isUserLoggedIn(context: Context): Boolean {
            if(Constants.userInfo != null) {
                return true
            }

            val data = getFromPreferences(context, Constants.userDataKey) ?: ""
            if (data.isNotEmpty()) {
                Constants.userInfo = Gson().fromJson(
                    getFromPreferences(context, Constants.userDataKey),
                    UserInfoModel::class.java
                )
            }
            return Constants.userInfo != null
        }

        fun getFcmToken(context: Context): String {
            return getFromPreferences(context, "fcm") ?: ""
        }

        fun saveFcmToken(context: Context, token: String) {
            saveStringInPreference(context, "fcm", token)
        }
    }

}