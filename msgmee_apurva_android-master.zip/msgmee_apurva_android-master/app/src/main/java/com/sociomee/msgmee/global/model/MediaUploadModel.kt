package com.sociomee.msgmee.global.model

import com.google.gson.annotations.SerializedName

data class MediaUploadModel(
        @SerializedName("data")
        val mediaUploadData: MediaUploadData,
        @SerializedName("error")
        val error: Boolean,
        @SerializedName("success")
        val success: Boolean
)

data class MediaUploadData(
        @SerializedName("errorResult")
        val errorResult: String,
        @SerializedName("successResult")
        val successResult: List<String>
)