package com.sociomee.msgmee.utils

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.sociomee.msgmee.custom.widget.CustomEditText


class SmsReceiver : BroadcastReceiver() {

    private lateinit var edt_pin1: CustomEditText
    private lateinit var edt_pin2: CustomEditText
    private lateinit var edt_pin3: CustomEditText
    private lateinit var edt_pin4: CustomEditText
    private lateinit var edt_pin5: CustomEditText
    private lateinit var edt_pin6: CustomEditText

    fun setOtp(edt_pin1: CustomEditText, edt_pin2: CustomEditText, edt_pin3: CustomEditText, edt_pin4: CustomEditText, edt_pin5: CustomEditText, edt_pin6: CustomEditText) {
        this.edt_pin1 = edt_pin1
        this.edt_pin2 = edt_pin2
        this.edt_pin3 = edt_pin3
        this.edt_pin4 = edt_pin4
        this.edt_pin5 = edt_pin5
        this.edt_pin6 = edt_pin6
    }

    override fun onReceive(context: Context?, intent: Intent?) {

        edt_pin1 = CustomEditText(context)
        edt_pin2 = CustomEditText(context)
        edt_pin3 = CustomEditText(context)
        edt_pin4 = CustomEditText(context)
        edt_pin5 = CustomEditText(context)
        edt_pin6 = CustomEditText(context)

        val smsMessages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        for (smsMessage in smsMessages) {
            val messageBody = smsMessage.messageBody
            val getOTP = messageBody.takeLast(6)

            edt_pin1.setText(getOTP[0].toString())
            edt_pin2.setText(getOTP[1].toString())
            edt_pin3.setText(getOTP[2].toString())
            edt_pin4.setText(getOTP[3].toString())
            edt_pin5.setText(getOTP[4].toString())
            edt_pin6.setText(getOTP[5].toString())
        }
    }
}
