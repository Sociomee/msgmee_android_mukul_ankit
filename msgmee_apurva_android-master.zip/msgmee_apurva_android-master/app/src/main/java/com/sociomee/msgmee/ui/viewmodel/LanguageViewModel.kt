package com.sociomee.msgmee.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.ui.repo.LanguageRepo
import com.sociomee.msgmee.custom.classes.MyViewModel
import com.sociomee.msgmee.custom.classes.ResponseStatus
import com.sociomee.msgmee.ui.model.LanguageList

class LanguageViewModel : MyViewModel() {

    var languageList = MutableLiveData<List<LanguageList>>()
    lateinit var languageRepo: LanguageRepo

    // returning LiveData
    fun observeLanguageList() = languageList

    fun getLanguageList() {
        if (!this::languageRepo.isInitialized) {
            languageRepo = LanguageRepo()
        }
        isLoading.value = true
        languageRepo.fetchLanguageList().observeForever{
            if(it.status == ResponseStatus.SUCCESS) {
                languageList.value = it.data
            } else {
                errorListener.value = it.status
            }
            isLoading.value = false
        }
    }
}