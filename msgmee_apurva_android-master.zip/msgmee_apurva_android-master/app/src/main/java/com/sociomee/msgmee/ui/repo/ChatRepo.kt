package com.sociomee.msgmee.ui.repo

import androidx.lifecycle.MutableLiveData
import com.sociomee.msgmee.custom.classes.MyResponse
import com.sociomee.msgmee.retrofit.MyCallback
import com.sociomee.msgmee.retrofit.MyRetrofit
import com.sociomee.msgmee.ui.`interface`.ApiCall
import com.sociomee.msgmee.ui.model.*
import retrofit2.Response

class ChatRepo {

    fun getChatHeadById(body: HashMap<String, Any>): MutableLiveData<MyResponse<ChatHeadInfoModel>> {
        val data = MutableLiveData<MyResponse<ChatHeadInfoModel>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.getChatHeadById(body)

        call.enqueue(object : MyCallback<ChatHeadResponse> {
            override fun success(response: Response<ChatHeadResponse>) {
                data.postValue(MyResponse.success(response.body()!!.data.successResult[0]))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }

    fun fetchChatHeadMessages(body: HashMap<String, Any>): MutableLiveData<MyResponse<ArrayList<ChatModel>>> {
        val data = MutableLiveData<MyResponse<ArrayList<ChatModel>>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.fetchChatHeadMessages(body)

        call.enqueue(object : MyCallback<ChatDataModel> {
            override fun success(response: Response<ChatDataModel>) {
                data.postValue(MyResponse.success(response.body()!!.data.chatModel))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }

    fun searchMessages(body: HashMap<String, Any>): MutableLiveData<MyResponse<SearchMessageModel.Data>> {
        val data = MutableLiveData<MyResponse<SearchMessageModel.Data>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.searchMessages(body)

        call.enqueue(object : MyCallback<SearchMessageModel> {
            override fun success(response: Response<SearchMessageModel>) {
                data.postValue(MyResponse.success(response.body()!!.data))
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }

    fun sendMessage(body: HashMap<String, Any>, isSendToUser: Boolean): MutableLiveData<MyResponse<String?>> {
        val data = MutableLiveData<MyResponse<String?>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = if(isSendToUser) retrofitService.sendMessageToUser(body) else retrofitService.sendMessageToChatHead(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if (response.body()!!.success) {
                    data.postValue(MyResponse.success(response.body()!!.messageData.messageSuccessData))
                } else {
                    data.postValue(MyResponse.success(null))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }

    fun deleteMessages(body: HashMap<String, Any>, isForMe: Boolean): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = if(isForMe) retrofitService.deleteMessagesForMe(body) else retrofitService.deleteMessagesForAll(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if (response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }

    fun forwardMessages(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.forwardMessages(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if (response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }

    fun clearChatHead(body: HashMap<String, Any>): MutableLiveData<MyResponse<Boolean>> {
        val data = MutableLiveData<MyResponse<Boolean>>()
        val retrofitService = MyRetrofit.getRetrofitService(ApiCall::class.java)
        val call = retrofitService.clearChatHead(body)

        call.enqueue(object : MyCallback<MessageResponse> {
            override fun success(response: Response<MessageResponse>) {
                if (response.body()!!.success) {
                    data.postValue(MyResponse.success(true))
                } else {
                    data.postValue(MyResponse.success(false))
                }
            }

            override fun serverError() {
                data.postValue(MyResponse.serverError())
            }

            override fun networkError() {
                data.postValue(MyResponse.internetError())
            }

            override fun authError() {
                data.postValue(MyResponse.authError(""))
            }

        })
        return data
    }

}